================================================================================
  AWS SECURITY HUB COMPLIANCE DASHBOARD — END-TO-END INTEGRATION GUIDE
  Version 1.5.9  |  Region: eu-west-1  |  September 2026
================================================================================

TABLE OF CONTENTS
-----------------
  1.  Overview & Architecture
  2.  Prerequisites
  3.  File Reference
  4.  Phase 1  — S3 Buckets
  5.  Phase 2  — Cognito User Pool (Authentication)
  6.  Phase 3  — IAM Roles & Policies
  7.  Phase 4  — Aggregator Lambda
  8.  Phase 5  — API Lambda + API Gateway
  9.  Phase 6  — Dashboard Build & CloudFront
  10. Phase 7  — First-Run Verification
  11. Environment Variables Reference
  12. Version Reference
  13. Ongoing Operations
  14. Troubleshooting
  15. Security Notes


================================================================================
1. OVERVIEW & ARCHITECTURE
================================================================================

This package delivers a multi-account AWS Security Hub compliance dashboard
consisting of three components:

  aggregator_lambda.py
    Runs daily via EventBridge. Pulls Security Hub findings from all member
    accounts (delegated admin access), computes compliance scores, writes
    per-account and combined summaries/reports to S3.
    Also fetches Trusted Advisor data from each account via cross-account role.
    Sends an HTML email digest of new Critical/High findings via SES.

  api_lambda.py
    Sits behind API Gateway (HTTP API). Serves the dashboard JSON data by
    reading from S3. Returns presigned URLs for PDF/CSV/Excel report downloads.

  securityhub-dashboard.jsx
    React single-page application. Multi-account selector with search,
    compliance score dial, severity drill-down, Trusted Advisor tab,
    PDF/CSV/Excel report download.

Architecture diagram:

  EventBridge (daily cron)
         |
         v
  aggregator_lambda  ----writes---->  S3: securityhub-dashboard-data
                                              |
                                     api_lambda  <--  API Gateway (HTTP API)
                                              |              |
                                              |        Cognito JWT authorizer
                                              |
                                      React Dashboard
                                  (S3 + CloudFront + HTTPS)
                                              |
                                       Cognito Hosted UI
                                       (sign-in / sign-out)

Deployment region: eu-west-1
  NOTE: Two AWS services must always target us-east-1 regardless of
  deployment region — they are global services:
    - SES SendEmail  (verified identity lives in a specific SES region)
    - AWS Support API  (Trusted Advisor — only exists in us-east-1)


================================================================================
2. PREREQUISITES
================================================================================

AWS Account requirements:
  - Security Hub delegated administrator account with GetFindings access
    across all 70+ member accounts
  - AWS Organizations management or delegated admin for ListAccounts
  - Business or Enterprise support plan (required for Trusted Advisor API)
  - SES out of sandbox mode (or sender + recipient both verified if in sandbox)

Tools required:
  - AWS CLI v2 configured with credentials for the delegated admin account
  - Python 3.12
  - Node.js 18+ and npm (for React dashboard build)
  - A registered domain with DNS control (for CloudFront + Cognito)

Permissions needed by the CLI user running these steps:
  - IAM: create roles, attach policies
  - Lambda: create and update functions
  - S3: create buckets, put objects
  - API Gateway: full access
  - Cognito: full access
  - CloudFront: create distributions
  - EventBridge: create rules and targets
  - SES: verify identities

Variables used throughout this guide — set these before starting:
  Replace every placeholder in angle brackets with your actual values.

  ACCOUNT_ID          = <your 12-digit AWS account ID>
  REGION              = eu-west-1
  DATA_BUCKET         = securityhub-dashboard-data
  UI_BUCKET           = securityhub-dashboard-uik to
  DOMAIN              = security.yourdomain.com
  SES_FROM            = securityhub-noreply@yourdomain.com
  SES_TO              = your-dl@yourcompany.com
  AGGREGATOR_FN       = securityhub-aggregator
  API_FN              = securityhub-api
  COGNITO_POOL_NAME   = securityhub-dashboard-users
  COGNITO_DOMAIN      = securityhub-dashboard-yourcompany


================================================================================
3. FILE REFERENCE
================================================================================

  aggregator_lambda.py      Daily aggregation Lambda — v1.5.9
  api_lambda.py             API Gateway Lambda — v1.5.2
  report_generator_lambda.py  On-demand report builder Lambda — v1.0.1
  inventory_lambda.py         On-demand inventory builder Lambda — v1.0.0
  securityhub-dashboard.jsx React dashboard component — v1.5.5
  securityhub-dashboard-dummy.jsx  Standalone POC demo (no AWS needed)
  main.jsx                  React app entry point
  CHANGELOG.md              Full version history with deploy notes
  README.txt                This file


================================================================================
4. PHASE 1 — S3 BUCKETS
================================================================================

Two S3 buckets are required:
  - Data bucket  : stores all Lambda output (summaries, reports, snapshots)
  - UI bucket    : hosts the built React dashboard

--------------------------------------------------------------------------------
4.1 Create the data bucket
--------------------------------------------------------------------------------

  aws s3api create-bucket \
    --bucket securityhub-dashboard-data \
    --region eu-west-1 \
    --create-bucket-configuration LocationConstraint=eu-west-1

  aws s3api put-public-access-block \
    --bucket securityhub-dashboard-data \
    --public-access-block-configuration \
      BlockPublicAcls=true,IgnorePublicAcls=true,\
      BlockPublicPolicy=true,RestrictPublicBuckets=true

  # Enable versioning (protects against accidental overwrites)
  aws s3api put-bucket-versioning \
    --bucket securityhub-dashboard-data \
    --versioning-configuration Status=Enabled

--------------------------------------------------------------------------------
4.2 Create the UI hosting bucket
--------------------------------------------------------------------------------

  aws s3api create-bucket \
    --bucket securityhub-dashboard-ui \
    --region eu-west-1 \
    --create-bucket-configuration LocationConstraint=eu-west-1

  aws s3api put-public-access-block \
    --bucket securityhub-dashboard-ui \
    --public-access-block-configuration \
      BlockPublicAcls=true,IgnorePublicAcls=true,\
      BlockPublicPolicy=true,RestrictPublicBuckets=true

  NOTE: The UI bucket is accessed only via CloudFront (OAC), not directly.
  Public access stays blocked. CloudFront bucket policy is added in Phase 6.

--------------------------------------------------------------------------------
4.3 S3 folder structure (written automatically by the aggregator)
--------------------------------------------------------------------------------
securityhub-dashboard.jsx
  securityhub-dashboard-data/
  ├── summaries/
  │   ├── accounts.json                   Account list for dropdown
  │   ├── version.json                    Aggregator version + last run time
  │   ├── all/
  │   │   ├── latest.json                 All-accounts combined summary
  │   │   └── findings.json              All-accounts combined findings
  │   └── {account_id}/
  │       ├── latest.json                 Per-account summary
  │       └── findings.json              Per-account findings (drill-down)
  ├── snapshots/
  │   └── {YYYY-MM-DD}/
  │       └── findings.json              Daily snapshot for delta comparison
  ├── reports/
  │   ├── all/
  │   │   ├── latest.pdf
  │   │   ├── latest.csv
  │   │   └── latest.xlsx
  │   └── {account_id}/
  │       ├── latest.pdf
  │       ├── latest.csv
  │       └── latest.xlsx
  └── trusted-advisor/
      ├── all/latest.json
      └── {account_id}/latest.json


================================================================================
5. PHASE 2 — COGNITO USER POOL (AUTHENTICATION)
================================================================================

Cognito provides JWT-based authentication. The dashboard redirects unauthenticated
users to the Cognito hosted sign-in page. API Gateway validates the JWT on every
request — no token, no data.

--------------------------------------------------------------------------------
5.1 Create the User Pool
--------------------------------------------------------------------------------

  aws cognito-idp create-user-pool \
    --pool-name securityhub-dashboard-users \
    --region eu-west-1 \
    --policies '{"PasswordPolicy":{"MinimumLength":12,"RequireUppercase":true,"RequireLowercase":true,"RequireNumbers":true,"RequireSymbols":true}}' \
    --auto-verified-attributes email \
    --username-attributes email \
    --mfa-configuration OPTIONAL \
    --query 'UserPool.Id' --output text

  --> Save the output as USER_POOL_ID

--------------------------------------------------------------------------------
5.2 Create the App Client (SPA — no client secret, uses PKCE)
--------------------------------------------------------------------------------

  aws cognito-idp create-user-pool-client \
    --user-pool-id <USER_POOL_ID> \
    --client-name securityhub-dashboard-spa \
    --region eu-west-1 \
    --no-generate-secret \
    --allowed-o-auth-flows authorization_code \
    --allowed-o-auth-scopes openid email profile \
    --allowed-o-auth-flows-user-pool-client \
    --supported-identity-providers COGNITO \
    --callback-urls '["https://security.yourdomain.com/callback"]' \
    --logout-urls '["https://security.yourdomain.com"]' \
    --explicit-auth-flows ALLOW_USER_SRP_AUTH ALLOW_REFRESH_TOKEN_AUTH \
    --query 'UserPoolClient.ClientId' --output text

  --> Save the output as APP_CLIENT_ID

--------------------------------------------------------------------------------
5.3 Create the Cognito hosted UI domain
--------------------------------------------------------------------------------

  aws cognito-idp create-user-pool-domain \
    --domain securityhub-dashboard-yourcompany \
    --user-pool-id <USER_POOL_ID> \
    --region eu-west-1

  Hosted sign-in URL will be:
  https://securityhub-dashboard-yourcompany.auth.eu-west-1.amazoncognito.com

--------------------------------------------------------------------------------
5.4 Create users
--------------------------------------------------------------------------------

  # Create a user (they receive a temporary password by email)
  aws cognito-idp admin-create-user \
    --user-pool-id <USER_POOL_ID> \
    --username analyst@yourcompany.com \
    --user-attributes Name=email,Value=analyst@yourcompany.com \
    --desired-delivery-mediums EMAIL \
    --region eu-west-1

  # Repeat for each analyst / security team member who needs access.
  # Users set their permanent password on first sign-in.

  NOTE: If you have an existing IdP (Active Directory, Okta, Azure AD),
  you can federate it into this User Pool as an external identity provider
  instead of managing users directly. This is the recommended approach for
  corporate environments.


================================================================================
6. PHASE 3 — IAM ROLES & POLICIES
================================================================================

--------------------------------------------------------------------------------
6.1 Aggregator Lambda execution role
--------------------------------------------------------------------------------

Create trust policy file aggregator-trust.json:

  {
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": { "Service": "lambda.amazonaws.com" },
      "Action": "sts:AssumeRole"
    }]
  }

  aws iam create-role \
    --role-name securityhub-aggregator-role \
    --assume-role-policy-document file://aggregator-trust.json

Create permissions policy file aggregator-policy.json:

  {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "CloudWatchLogs",
        "Effect": "Allow",
        "Action": ["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],
        "Resource": "arn:aws:logs:eu-west-1:*:*"
      },
      {
        "Sid": "SecurityHub",
        "Effect": "Allow",
        "Action": "securityhub:GetFindings",
        "Resource": "*"
      },
      {
        "Sid": "S3DataBucket",
        "Effect": "Allow",
        "Action": ["s3:PutObject","s3:GetObject"],
        "Resource": "arn:aws:s3:::securityhub-dashboard-data/*"
      },
      {
        "Sid": "SES",
        "Effect": "Allow",
        "Action": "ses:SendEmail",
        "Resource": "*"
      },
      {
        "Sid": "STSAssumeTA",
        "Effect": "Allow",
        "Action": "sts:AssumeRole",
        "Resource": "arn:aws:iam::*:role/TrustedAdvisorReadOnlyRole"
      },
      {
        "Sid": "TrustedAdvisor",
        "Effect": "Allow",
        "Action": [
          "support:DescribeTrustedAdvisorChecks",
          "support:DescribeTrustedAdvisorCheckResult"
        ],
        "Resource": "*"
      },
      {
        "Sid": "Inspector2Status",
        "Effect": "Allow",
        "Action": "inspector2:BatchGetAccountStatus",
        "Resource": "*"
      },
      {
        "Sid": "Organizations",
        "Effect": "Allow",
        "Action": "organizations:ListAccounts",
        "Resource": "*"
      }
    ]
  }

  aws iam put-role-policy \
    --role-name securityhub-aggregator-role \
    --policy-name securityhub-aggregator-policy \
    --policy-document file://aggregator-policy.json

--------------------------------------------------------------------------------
6.2 API Lambda execution role
--------------------------------------------------------------------------------

Create permissions policy file api-policy.json:

  {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "CloudWatchLogs",
        "Effect": "Allow",
        "Action": ["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],
        "Resource": "arn:aws:logs:eu-west-1:*:*"
      },
      {
        "Sid": "S3Read",
        "Effect": "Allow",
        "Action": "s3:GetObject",
        "Resource": "arn:aws:s3:::securityhub-dashboard-data/*"
      }
    ]
  }

  aws iam create-role \
    --role-name securityhub-api-role \
    --assume-role-policy-document file://aggregator-trust.json

  aws iam put-role-policy \
    --role-name securityhub-api-role \
    --policy-name securityhub-api-policy \
    --policy-document file://api-policy.json

--------------------------------------------------------------------------------
6.3 TrustedAdvisorReadOnlyRole — run in EVERY member account
--------------------------------------------------------------------------------

  This role must exist in every member account so the aggregator can
  assume it to call the Trusted Advisor API.

  Create ta-trust.json — replace DELEGATED_ADMIN_ACCOUNT_ID:

  {
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<DELEGATED_ADMIN_ACCOUNT_ID>:role/securityhub-aggregator-role"
      },
      "Action": "sts:AssumeRole"
    }]
  }

  Run in each member account:

  aws iam create-role \
    --role-name TrustedAdvisorReadOnlyRole \
    --assume-role-policy-document file://ta-trust.json

  aws iam attach-role-policy \
    --role-name TrustedAdvisorReadOnlyRole \
    --policy-arn arn:aws:iam::aws:policy/AWSSupportAccess

  TIP: Automate this with AWS Organizations + CloudFormation StackSets so
  the role is automatically deployed to new member accounts.


================================================================================
7. PHASE 4 — AGGREGATOR LAMBDA
================================================================================

--------------------------------------------------------------------------------
7.1 Package the Lambda
--------------------------------------------------------------------------------

  mkdir aggregator-build
  cd aggregator-build
  cp ../aggregator_lambda.py .
  # NOTE: fpdf2 and openpyxl are no longer required in the aggregator ZIP.
  # Report generation was moved to report_generator_lambda.
  # boto3 is provided by the Lambda runtime — no pip install needed.
  zip -r ../aggregator_lambda.zip .
  cd ..

--------------------------------------------------------------------------------
7.2 Deploy the function
--------------------------------------------------------------------------------

  aws lambda create-function \
    --function-name securityhub-aggregator \
    --runtime python3.12 \
    --role arn:aws:iam::<ACCOUNT_ID>:role/securityhub-aggregator-role \
    --handler aggregator_lambda.lambda_handler \
    --zip-file fileb://aggregator_lambda.zip \
    --region eu-west-1 \
    --timeout 840 \
    --memory-size 1024 \
    --environment Variables="{
      BUCKET=securityhub-dashboard-data,
      SES_FROM_EMAIL=<SES_FROM>,
      SES_TO_EMAIL=<SES_TO>,
      ACCOUNT_NAME_OVERRIDES=<account_id>=<name>,<account_id>=<name>
    }"

  IMPORTANT:
    timeout = 840s (14 minutes). The Lambda has a hard limit of 15 minutes.
    14 minutes gives 1 minute of margin before EventBridge retry.
    memory = 1024 MB. Required for large orgs with many findings.

  To update an existing function after code changes:

  aws lambda update-function-code \
    --function-name securityhub-aggregator \
    --zip-file fileb://aggregator_lambda.zip \
    --region eu-west-1

--------------------------------------------------------------------------------
7.3 Create the EventBridge daily schedule
--------------------------------------------------------------------------------

  # Create the rule — runs at 02:00 UTC daily (adjust to suit your timezone)
  aws events put-rule \
    --name securityhub-aggregator-daily \
    --schedule-expression "cron(0 2 * * ? *)" \
    --state ENABLED \
    --region eu-west-1

  # Allow EventBridge to invoke the Lambda
  aws lambda add-permission \
    --function-name securityhub-aggregator \
    --statement-id eventbridge-daily \
    --action lambda:InvokeFunction \
    --principal events.amazonaws.com \
    --source-arn arn:aws:events:eu-west-1:<ACCOUNT_ID>:rule/securityhub-aggregator-daily \
    --region eu-west-1

  # Point the rule at the Lambda
  aws events put-targets \
    --rule securityhub-aggregator-daily \
    --region eu-west-1 \
    --targets '[{
      "Id": "aggregator",
      "Arn": "arn:aws:lambda:eu-west-1:<ACCOUNT_ID>:function:securityhub-aggregator"
    }]'

  RECOMMENDED: Add a Dead Letter Queue so failed invocations are not silently lost.

  # Create SQS DLQ
  aws sqs create-queue \
    --queue-name securityhub-aggregator-dlq \
    --region eu-west-1 \
    --query 'QueueUrl' --output text

  # Attach DLQ to the Lambda
  aws lambda update-function-configuration \
    --function-name securityhub-aggregator \
    --dead-letter-config TargetArn=arn:aws:sqs:eu-west-1:<ACCOUNT_ID>:securityhub-aggregator-dlq \
    --region eu-west-1

--------------------------------------------------------------------------------
7.4 Verify SES sender identity
--------------------------------------------------------------------------------

  1. Open the AWS SES console in the region where you want to send from.
     (If your SES identity is in us-east-1, keep the ses client as us-east-1
      in aggregator_lambda.py. If it is in eu-west-1, update the client there.)

  2. Go to Verified identities > Create identity.
     Enter the domain or email address set as SES_FROM_EMAIL.

  3. For domain verification: add the DNS CNAME records shown to your DNS provider.
     For email verification: click the link in the verification email.

  4. If SES is in sandbox mode:
     - Also verify SES_TO_EMAIL as a recipient identity.
     - Or request production access via SES console > Account dashboard >
       Request production access. Approval typically takes 24 hours.


================================================================================
8. PHASE 5 — API LAMBDA + API GATEWAY
================================================================================

--------------------------------------------------------------------------------
8.1 Deploy the API Lambda
--------------------------------------------------------------------------------

  zip api_lambda.zip api_lambda.py

  aws lambda create-function \
    --function-name securityhub-api \
    --runtime python3.12 \
    --role arn:aws:iam::<ACCOUNT_ID>:role/securityhub-api-role \
    --handler api_lambda.lambda_handler \
    --zip-file fileb://api_lambda.zip \
    --region eu-west-1 \
    --timeout 30 \
    --memory-size 256 \
    --environment Variables="{
      BUCKET=securityhub-dashboard-data,
      CORS_ALLOW_ORIGIN=https://security.yourdomain.com
    }"

--------------------------------------------------------------------------------
8.2 Create the HTTP API Gateway
--------------------------------------------------------------------------------

  aws apigatewayv2 create-api \
    --name securityhub-dashboard-api \
    --protocol-type HTTP \
    --region eu-west-1 \
    --query 'ApiId' --output text

  --> Save the output as API_ID

--------------------------------------------------------------------------------
8.3 Create Lambda integration
--------------------------------------------------------------------------------

  aws apigatewayv2 create-integration \
    --api-id <API_ID> \
    --integration-type AWS_PROXY \
    --integration-uri arn:aws:lambda:eu-west-1:<ACCOUNT_ID>:function:securityhub-api \
    --payload-format-version 2.0 \
    --region eu-west-1 \
    --query 'IntegrationId' --output text

  --> Save the output as INTEGRATION_ID

  aws apigatewayv2 create-route \
    --api-id <API_ID> \
    --route-key 'GET /{proxy+}' \
    --target integrations/<INTEGRATION_ID> \
    --region eu-west-1

  # Also add OPTIONS route for CORS preflight
  aws apigatewayv2 create-route \
    --api-id <API_ID> \
    --route-key 'OPTIONS /{proxy+}' \
    --target integrations/<INTEGRATION_ID> \
    --region eu-west-1

  aws apigatewayv2 create-stage \
    --api-id <API_ID> \
    --stage-name '$default' \
    --auto-deploy \
    --region eu-west-1

--------------------------------------------------------------------------------
8.4 Add Cognito JWT authorizer (Item 1 — Authentication)
--------------------------------------------------------------------------------

  aws apigatewayv2 create-authorizer \
    --api-id <API_ID> \
    --authorizer-type JWT \
    --identity-source '$request.header.Authorization' \
    --name cognito-authorizer \
    --region eu-west-1 \
    --jwt-configuration \
      Audience=<APP_CLIENT_ID>,\
      Issuer=https://cognito-idp.eu-west-1.amazonaws.com/<USER_POOL_ID> \
    --query 'AuthorizerId' --output text

  --> Save the output as AUTHORIZER_ID

  # Get the GET route ID
  aws apigatewayv2 get-routes \
    --api-id <API_ID> \
    --region eu-west-1 \
    --query 'Items[?RouteKey==`GET /{proxy+}`].RouteId' \
    --output text

  --> Save the output as ROUTE_ID

  # Attach the authorizer to the GET route
  aws apigatewayv2 update-route \
    --api-id <API_ID> \
    --route-id <ROUTE_ID> \
    --authorization-type JWT \
    --authorizer-id <AUTHORIZER_ID> \
    --region eu-west-1

  NOTE: The OPTIONS route must NOT have an authorizer — browsers send the
  CORS preflight without an Authorization header. Leave it as NONE.

--------------------------------------------------------------------------------
8.5 Grant API Gateway permission to invoke the Lambda
--------------------------------------------------------------------------------

  aws lambda add-permission \
    --function-name securityhub-api \
    --statement-id apigw-invoke \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:eu-west-1:<ACCOUNT_ID>:<API_ID>/*/*/{proxy+}" \
    --region eu-west-1

  Your API invoke URL is:
  https://<API_ID>.execute-api.eu-west-1.amazonaws.com

  Update the CORS_ALLOW_ORIGIN Lambda environment variable to match the
  final dashboard domain once you have it from CloudFront.


================================================================================
9. PHASE 6 — DASHBOARD BUILD & CLOUDFRONT
================================================================================

--------------------------------------------------------------------------------
9.1 Install auth dependency
--------------------------------------------------------------------------------

  The dashboard uses Amazon Cognito for authentication. Add AWS Amplify Auth
  to your React project for the simplest integration (handles token refresh,
  hosted UI redirect, and logout automatically):

  npm install aws-amplify @aws-amplify/ui-react

  OR if you prefer a lighter dependency:

  npm install amazon-cognito-identity-js

--------------------------------------------------------------------------------
9.2 Configure Amplify in main.jsx
--------------------------------------------------------------------------------

  Add this to main.jsx before the React render call:

  ----------------------------------------------------------------
  import { Amplify } from 'aws-amplify';

  Amplify.configure({
    Auth: {
      Cognito: {
        userPoolId: import.meta.env.VITE_COGNITO_USER_POOL_ID,
        userPoolClientId: import.meta.env.VITE_COGNITO_CLIENT_ID,
        loginWith: {
          oauth: {
            domain: import.meta.env.VITE_COGNITO_DOMAIN,
            scopes: ['openid', 'email', 'profile'],
            redirectSignIn: [import.meta.env.VITE_REDIRECT_URI],
            redirectSignOut: [import.meta.env.VITE_REDIRECT_URI],
            responseType: 'code',
          }
        }
      }
    }
  });
  ----------------------------------------------------------------

  Then wrap your dashboard component with the Amplify Authenticator:

  ----------------------------------------------------------------
  import { Authenticator } from '@aws-amplify/ui-react';
  import '@aws-amplify/ui-react/styles.css';

  root.render(
    <React.StrictMode>
      <Authenticator>
        {({ signOut, user }) => (
          <SecurityHubDashboard signOut={signOut} user={user} />
        )}
      </Authenticator>
    </React.StrictMode>
  );
  ----------------------------------------------------------------

--------------------------------------------------------------------------------
9.3 Pass the auth token in API calls
--------------------------------------------------------------------------------

  Update fetchWithTimeout in securityhub-dashboard.jsx to include
  the Cognito JWT on every request:

  ----------------------------------------------------------------
  import { fetchAuthSession } from 'aws-amplify/auth';

  async function getAuthHeaders() {
    const session = await fetchAuthSession();
    const token = session.tokens?.idToken?.toString();
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  async function fetchWithTimeout(url, options = {}) {
    const controller = new AbortController();
    const timerId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    const headers = await getAuthHeaders();
    return fetch(url, {
      ...options,
      headers: { ...headers, ...(options.headers || {}) },
      signal: controller.signal,
    }).finally(() => clearTimeout(timerId));
  }
  ----------------------------------------------------------------

--------------------------------------------------------------------------------
9.4 Create .env file for the build
--------------------------------------------------------------------------------

  Create a .env file in your React project root:

  ----------------------------------------------------------------
  VITE_API_BASE=https://<API_ID>.execute-api.eu-west-1.amazonaws.com
  VITE_COGNITO_USER_POOL_ID=<USER_POOL_ID>
  VITE_COGNITO_CLIENT_ID=<APP_CLIENT_ID>
  VITE_COGNITO_DOMAIN=securityhub-dashboard-yourcompany.auth.eu-west-1.amazoncognito.com
  VITE_REDIRECT_URI=https://security.yourdomain.com
  ----------------------------------------------------------------

  IMPORTANT: Do NOT commit .env to version control.
  Add it to .gitignore.

--------------------------------------------------------------------------------
9.5 Build the dashboard
--------------------------------------------------------------------------------

  npm install
  npm run build

  The built files are output to the dist/ folder.

--------------------------------------------------------------------------------
9.6 Upload to S3
--------------------------------------------------------------------------------

  aws s3 sync dist/ s3://securityhub-dashboard-ui/ \
    --region eu-west-1 \
    --delete \
    --cache-control "max-age=31536000,immutable" \
    --exclude "index.html"

  # index.html should not be cached long-term (it references hashed asset files)
  aws s3 cp dist/index.html s3://securityhub-dashboard-ui/index.html \
    --region eu-west-1 \
    --cache-control "no-cache,no-store,must-revalidate"

--------------------------------------------------------------------------------
9.7 Create CloudFront distribution
--------------------------------------------------------------------------------

  NOTE: CloudFront distributions are always created in us-east-1 regardless
  of where your content lives.

  1. Open the AWS CloudFront console.

  2. Create distribution:
       Origin domain   : securityhub-dashboard-ui.s3.eu-west-1.amazonaws.com
       Origin access   : Origin access control (OAC) — create new OAC
       Viewer protocol : Redirect HTTP to HTTPS
       Default root    : index.html
       Price class     : Use only Europe and North America (or All)
       Alternate domain: security.yourdomain.com
       SSL certificate : Request a certificate in ACM (us-east-1 for CloudFront)

  3. After creation, copy the S3 bucket policy shown by CloudFront and
     apply it to securityhub-dashboard-ui via S3 console > Permissions > Bucket policy.
     This allows CloudFront OAC to read from the bucket.

  4. Add a CloudFront error page for SPA routing:
       HTTP error code   : 403
       Response page path: /index.html
       HTTP response code: 200
     (This ensures direct URL access and browser refresh work correctly.)

  5. Note the CloudFront domain (e.g. abc123.cloudfront.net).

  6. Create a DNS CNAME record:
       security.yourdomain.com  ->  abc123.cloudfront.net

  7. Update the Cognito callback URL to your final domain:
     aws cognito-idp update-user-pool-client \
       --user-pool-id <USER_POOL_ID> \
       --client-id <APP_CLIENT_ID> \
       --callback-urls '["https://security.yourdomain.com/callback"]' \
       --logout-urls '["https://security.yourdomain.com"]' \
       --region eu-west-1

  8. Update the API Lambda CORS_ALLOW_ORIGIN environment variable to the
     final domain:
     aws lambda update-function-configuration \
       --function-name securityhub-api \
       --region eu-west-1 \
       --environment Variables="{
         BUCKET=securityhub-dashboard-data,
         CORS_ALLOW_ORIGIN=https://security.yourdomain.com
       }"


================================================================================
10. PHASE 7 — FIRST-RUN VERIFICATION
================================================================================

Run these checks in order after completing all phases.

--------------------------------------------------------------------------------
10.1 Trigger the aggregator manually
--------------------------------------------------------------------------------

  aws lambda invoke \
    --function-name securityhub-aggregator \
    --region eu-west-1 \
    response.json

  cat response.json

  Expected response shape:
  {
    "statusCode": 200,
    "body": "{
      \"version\": \"1.5.7\",
      \"accountsProcessed\": 72,
      \"totalFindings\": 1840,
      \"newFindings\": 14,
      \"resolvedFindings\": 3,
      \"taAccountsProcessed\": 68,
      \"taAccountsSkipped\": 4,
      \"inspectorAccountsProcessed\": 72,
      \"inspectorEnabledAccounts\": 65,
      \"inspectorDisabledAccounts\": 7,
      \"inspectorTotalFindings\": 312,
      \"totalDurationSeconds\": 142.5
    }"
  }

  If statusCode is 500, check CloudWatch Logs:
  aws logs tail /aws/lambda/securityhub-aggregator --region eu-west-1 --follow

--------------------------------------------------------------------------------
10.2 Verify S3 was written
--------------------------------------------------------------------------------

  aws s3 ls s3://securityhub-dashboard-data/summaries/ --region eu-west-1
  aws s3 ls s3://securityhub-dashboard-data/reports/ --region eu-west-1
  aws s3 ls s3://securityhub-dashboard-data/snapshots/ --region eu-west-1
  aws s3 ls s3://securityhub-dashboard-data/trusted-advisor/ --region eu-west-1

--------------------------------------------------------------------------------
10.3 Test the API (before auth)
--------------------------------------------------------------------------------

  # Should return 401 (JWT authorizer blocking unauthenticated request)
  curl -i https://<API_ID>.execute-api.eu-west-1.amazonaws.com/version

  # Should return 200 with version info (version route exists, Cognito token needed)

--------------------------------------------------------------------------------
10.4 Sign in to the dashboard
--------------------------------------------------------------------------------

  1. Open https://security.yourdomain.com in a browser.
  2. You are redirected to the Cognito hosted sign-in page.
  3. Sign in with the user created in Phase 2.4.
  4. You are redirected back to the dashboard.
  5. Verify: accounts load in the selector, compliance score shows, severity cards populate.
  6. Click a severity card — findings drill-down should appear.
  7. Switch to the Trusted Advisor tab — checks should load.
  8. Select PDF / CSV / Excel and click Download report — file should download.
  9. Check the browser console — no errors should appear.

--------------------------------------------------------------------------------
10.5 Verify SES email digest
--------------------------------------------------------------------------------

  After the first run, check the SES_TO_EMAIL inbox.
  If there were new Critical/High findings, an HTML email should have arrived.
  If the inbox is empty, check CloudWatch logs for:
    "SES digest sent"       -- email was sent
    "No new Crit/High"      -- no new findings, no email (expected on re-run same day)
    "SES send_email failed" -- SES error, check identity verification

--------------------------------------------------------------------------------
10.6 Check the /version route
--------------------------------------------------------------------------------

  The dashboard footer shows:
    dashboard v1.5.5 · api v1.5.2 · aggregator v1.5.9 · last run <timestamp>

  If the aggregator version is missing, the aggregator has not completed
  a successful run yet (version.json not written).


================================================================================
11. ENVIRONMENT VARIABLES REFERENCE
================================================================================

AGGREGATOR LAMBDA (securityhub-aggregator)
-------------------------------------------
  Variable                Required   Description
  --------                --------   -----------
  BUCKET                  YES        S3 bucket name for all output
                                     (e.g. securityhub-dashboard-data)
  SES_FROM_EMAIL          YES        Verified SES sender address
                                     Must be verified in SES before deploying
  SES_TO_EMAIL            YES        Distribution list for Critical/High alerts
                                     Must be verified if SES is in sandbox mode
  ACCOUNT_NAME_OVERRIDES  no         Comma-separated accountId=name pairs
                                     e.g. 143301474150=audit,824623333855=prod
                                     Falls back to AWS Organizations names

  NOTE: The Lambda raises EnvironmentError at cold-start if any required
  variable is missing. Check CloudWatch Logs if the Lambda fails to initialize.

API LAMBDA (securityhub-api)
-----------------------------
  Variable                Required   Description
  --------                --------   -----------
  BUCKET                  YES        Same S3 bucket name as above
  CORS_ALLOW_ORIGIN       YES        Full origin URL of the dashboard
                                     e.g. https://security.yourdomain.com
                                     Must match exactly — no trailing slash

DASHBOARD BUILD (.env file)
-----------------------------
  Variable                       Description
  --------                       -----------
  VITE_API_BASE                  Full API Gateway invoke URL
                                 e.g. https://abc123.execute-api.eu-west-1.amazonaws.com
  VITE_COGNITO_USER_POOL_ID      Cognito User Pool ID (eu-west-1_xxxxxxx)
  VITE_COGNITO_CLIENT_ID         Cognito App Client ID
  VITE_COGNITO_DOMAIN            Cognito hosted UI domain
                                 e.g. securityhub-dashboard-yourcompany.auth.eu-west-1.amazoncognito.com
  VITE_REDIRECT_URI              Dashboard URL (https://security.yourdomain.com)


================================================================================
12. VERSION REFERENCE
================================================================================

  Component                Version   File
  ---------                -------   ----
  Aggregator Lambda        1.5.9     aggregator_lambda.py
  API Lambda               1.5.2     api_lambda.py
  Report Generator Lambda  1.0.1     report_generator_lambda.py
  Inventory Lambda         1.0.0     inventory_lambda.py
  Dashboard                1.5.5     securityhub-dashboard.jsx

  Full version history: CHANGELOG.md


================================================================================
13. ONGOING OPERATIONS
================================================================================

Updating the aggregator code
-----------------------------
  cd aggregator-build
  cp ../aggregator_lambda.py .
  # No pip install needed — fpdf2/openpyxl are not required in the aggregator.
  zip -r ../aggregator_lambda.zip .

  aws lambda update-function-code \
    --function-name securityhub-aggregator \
    --zip-file fileb://aggregator_lambda.zip \
    --region eu-west-1

Updating the API code
---------------------
  zip api_lambda.zip api_lambda.py

  aws lambda update-function-code \
    --function-name securityhub-api \
    --zip-file fileb://api_lambda.zip \
    --region eu-west-1

Updating the dashboard
----------------------
  npm run build
  aws s3 sync dist/ s3://securityhub-dashboard-ui/ --region eu-west-1 --delete
  aws cloudfront create-invalidation \
    --distribution-id <CLOUDFRONT_DIST_ID> \
    --paths "/*"

Adding a new user
-----------------
  aws cognito-idp admin-create-user \
    --user-pool-id <USER_POOL_ID> \
    --username newuser@yourcompany.com \
    --user-attributes Name=email,Value=newuser@yourcompany.com \
    --desired-delivery-mediums EMAIL \
    --region eu-west-1

Removing a user
---------------
  aws cognito-idp admin-delete-user \
    --user-pool-id <USER_POOL_ID> \
    --username removeduser@yourcompany.com \
    --region eu-west-1

Monitoring
----------
  Lambda errors:
  aws logs tail /aws/lambda/securityhub-aggregator --region eu-west-1 --follow
  aws logs tail /aws/lambda/securityhub-api --region eu-west-1 --follow

  DLQ check (failed Lambda invocations):
  aws sqs get-queue-attributes \
    --queue-url https://sqs.eu-west-1.amazonaws.com/<ACCOUNT_ID>/securityhub-aggregator-dlq \
    --attribute-names ApproximateNumberOfMessages \
    --region eu-west-1

  Recommended CloudWatch alarms:
  - Lambda errors > 0 on securityhub-aggregator
  - Lambda duration > 780000 ms on securityhub-aggregator (approaching timeout)
  - DLQ messages > 0


================================================================================
14. TROUBLESHOOTING
================================================================================

Problem: Lambda fails immediately with EnvironmentError
  Cause:  A required environment variable is not set.
  Fix:    Check CloudWatch logs for which variable is missing.
          Go to Lambda > Configuration > Environment variables and add it.

Problem: Lambda fails with "NoCredentialError" or "AccessDenied" on SecurityHub
  Cause:  Lambda execution role lacks securityhub:GetFindings or
          this account is not the Security Hub delegated administrator.
  Fix:    Verify the IAM role policy. Verify Security Hub delegated admin
          status in the Security Hub console > Settings > Delegated admin.

Problem: Trusted Advisor returns 0 checks for all accounts
  Cause:  Support plan is not Business/Enterprise, OR
          TrustedAdvisorReadOnlyRole does not exist in member accounts, OR
          the Lambda execution role cannot assume it.
  Fix:    Check CloudWatch logs for "fetch_trusted_advisor_checks failed".
          Verify the Support plan in each member account.
          Verify the trust policy on TrustedAdvisorReadOnlyRole.

Problem: SES email is not being sent
  Cause:  SES_TO_EMAIL or SES_FROM_EMAIL not verified, OR still in sandbox.
  Fix:    Check CloudWatch logs for "SES send_email failed".
          Open SES console > Verified identities.
          If in sandbox: request production access.

Problem: API returns 401 Unauthorized on all requests
  Cause:  JWT authorizer is active and the request has no/invalid token.
  Fix:    Ensure the dashboard is sending the Cognito ID token as a
          Bearer token in the Authorization header.
          Check the Cognito User Pool ID and Client ID in the .env file.

Problem: API returns 401 on OPTIONS preflight
  Cause:  The OPTIONS route has an authorizer attached to it.
  Fix:    OPTIONS route must have authorization-type NONE.
          aws apigatewayv2 get-routes --api-id <API_ID> --region eu-west-1
          Find the OPTIONS route ID and update it to NONE.

Problem: API returns 400 "Invalid account parameter"
  Cause:  The account query param is not a 12-digit ID or 'all'.
  Fix:    Check what the dashboard is sending. This is a security control —
          any non-numeric or non-'all' value is blocked intentionally.

Problem: Dashboard shows blank screen (no error message)
  Cause:  A React render error was caught by ErrorBoundary and replaced
          with a recovery screen, OR the JS bundle failed to load.
  Fix:    Open browser DevTools > Console.
          If you see "[ErrorBoundary] Uncaught render error", the error
          details are in the console. Fix the underlying data issue.
          If the bundle fails to load, check CloudFront and S3.

Problem: Downloads fail silently (no file, no error)
  Cause:  Popup blocker, or API returning non-200 for /report-url.
  Fix:    Check the error banner on the dashboard.
          Check that the report file exists in S3:
          aws s3 ls s3://securityhub-dashboard-data/reports/all/ --region eu-west-1

Problem: Dashboard works but shows no data after sign-in
  Cause:  Aggregator has not run yet, OR S3 bucket name mismatch.
  Fix:    Trigger the aggregator manually (see Phase 7.1).
          Verify both Lambdas use the same BUCKET env var value.

Problem: CloudFront returns 403 on direct URL access or browser refresh
  Cause:  SPA routing — CloudFront returns S3's 403 instead of index.html.
  Fix:    Add a custom error response in CloudFront:
          403 -> /index.html -> 200
          (This is noted in Phase 9.7 step 4.)


================================================================================
15. SECURITY NOTES
================================================================================

Authentication
  - API Gateway requires a valid Cognito JWT on all GET requests.
    The OPTIONS route is exempt (required for CORS preflight).
  - Tokens expire after 1 hour. Amplify handles silent refresh automatically.
  - No anonymous access is possible once the authorizer is attached.

Data bucket access
  - The data bucket is private. Only the aggregator (write) and API (read)
    Lambda execution roles have access. CloudFront has no access to this bucket.
  - Report downloads use presigned S3 URLs (15-minute TTL). The URL is
    generated by the API Lambda after JWT validation — no unauthenticated
    access to reports is possible.

API input validation
  - The account parameter is validated against ^\d{12}$|^all$ before any
    S3 key construction. Path traversal attempts are rejected with HTTP 400.
  - severity and status parameters are validated against explicit allowlists.
  - Internal errors return a generic message to callers. Real errors are
    logged to CloudWatch with a requestId for correlation.

Secrets management
  - No secrets are hardcoded in source files.
  - SES emails, S3 bucket name, and CORS origin are Lambda environment variables.
  - Cognito IDs are build-time environment variables (.env) — not secrets,
    but not committed to version control.
  - The .env file is excluded from VCS via .gitignore.

Network security
  - All traffic is HTTPS only (CloudFront enforces redirect, API Gateway
    enforces HTTPS, Cognito is HTTPS-only).
  - CORS is restricted to the specific dashboard origin.
  - CloudFront uses Origin Access Control — the S3 UI bucket is not public.

Remaining open item
  - Authentication (Item 1) is addressed in this guide via Cognito.
    Implementation in securityhub-dashboard.jsx (Amplify integration
    and passing the Bearer token) must be completed before production traffic.
    See Phase 9.2 and 9.3 for the exact code changes required.


================================================================================
END OF DOCUMENT
================================================================================
