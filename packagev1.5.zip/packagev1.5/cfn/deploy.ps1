<#
.SYNOPSIS
    End-to-end deployment script for the Security Hub Compliance Dashboard.

.DESCRIPTION
    This script performs the complete deployment sequence:
      1.  Validates prerequisites (AWS CLI, Python, Node.js, pip)
      2.  Creates the Lambda code staging bucket if it doesn't exist
      3.  Packages and uploads the Aggregator Lambda ZIP
      4.  Packages and uploads the API Lambda ZIP
      5.  Deploys (or updates) the main CloudFormation stack
      6.  Reads stack outputs and generates the dashboard .env file
      7.  Builds the React dashboard with the correct environment variables
      8.  Syncs the built dashboard to the S3 UI bucket
      9.  Invalidates the CloudFront cache
      10. Deploys the StackSet for member account TrustedAdvisor roles
      11. Prints a post-deploy summary with all endpoints

.PARAMETER StackName
    CloudFormation stack name. Default: securityhub-dashboard

.PARAMETER StackEnv
    Environment label (dev/staging/prod). Default: prod

.PARAMETER Region
    AWS deployment region. Default: eu-west-1

.PARAMETER DataBucketName
    S3 bucket for aggregator output. Default: securityhub-dashboard-data

.PARAMETER UIBucketName
    S3 bucket for the React dashboard. Default: securityhub-dashboard-ui

.PARAMETER LambdaCodeBucket
    S3 bucket to stage Lambda ZIP files. Default: securityhub-lambda-code-{accountId}

.PARAMETER SesFromEmail
    Verified SES sender address. REQUIRED.

.PARAMETER SesToEmail
    Alert distribution list email. REQUIRED.

.PARAMETER DashboardDomain
    Custom domain for the dashboard (e.g. security.yourdomain.com). REQUIRED.

.PARAMETER AcmCertificateArn
    ACM certificate ARN in us-east-1 covering DashboardDomain. REQUIRED.

.PARAMETER CognitoDomainPrefix
    Unique prefix for the Cognito hosted UI domain. REQUIRED.

.PARAMETER AdminEmail
    Email address for the first Cognito admin user. REQUIRED.

.PARAMETER AggregatorSchedule
    EventBridge cron expression (UTC). Default: cron(0 2 * * ? *)

.PARAMETER AggregatorMemory
    Aggregator Lambda memory in MB. Default: 1024

.PARAMETER AggregatorTimeout
    Aggregator Lambda timeout in seconds. Default: 840

.PARAMETER AccountNameOverrides
    Optional comma-separated accountId=name pairs. Default: empty string.

.PARAMETER OrgId
    AWS Organizations ID (o-xxxxxxxxxx) for StackSet deployment.
    If omitted, StackSet deployment step is skipped.

.PARAMETER OuIds
    Comma-separated Organizational Unit IDs for StackSet targets.
    Example: ou-xxxx-yyyyyyyy,ou-xxxx-zzzzzzzz
    If omitted alongside OrgId, StackSet step is skipped.

.PARAMETER DashboardSourceDir
    Path to the React project root containing main.jsx and package.json.
    Default: parent directory of this script (packagev1.5)

.PARAMETER SkipBuild
    Switch. If set, skips the npm install + build step (use when re-deploying
    Lambda code only).

.PARAMETER SkipStackSet
    Switch. If set, skips the member account StackSet deployment step.

.EXAMPLE
    # Full first-time deployment
    .\deploy.ps1 `
        -SesFromEmail     "securityhub-noreply@yourdomain.com" `
        -SesToEmail       "security-team@yourdomain.com" `
        -DashboardDomain  "security.yourdomain.com" `
        -AcmCertificateArn "arn:aws:acm:us-east-1:123456789012:certificate/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" `
        -CognitoDomainPrefix "securityhub-yourcompany" `
        -AdminEmail       "admin@yourdomain.com" `
        -OrgId            "o-xxxxxxxxxxxx" `
        -OuIds            "ou-xxxx-yyyyyyyy"

.EXAMPLE
    # Re-deploy Lambda code only (no npm build, no StackSet)
    .\deploy.ps1 `
        -SesFromEmail     "securityhub-noreply@yourdomain.com" `
        -SesToEmail       "security-team@yourdomain.com" `
        -DashboardDomain  "security.yourdomain.com" `
        -AcmCertificateArn "arn:aws:acm:us-east-1:123456789012:certificate/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" `
        -CognitoDomainPrefix "securityhub-yourcompany" `
        -AdminEmail       "admin@yourdomain.com" `
        -SkipBuild `
        -SkipStackSet
#>

[CmdletBinding()]
param(
    [string]  $StackName            = "securityhub-dashboard",
    [ValidateSet("dev","staging","prod")]
    [string]  $StackEnv             = "prod",
    [string]  $Region               = "eu-west-1",
    [string]  $DataBucketName       = "securityhub-dashboard-data",
    [string]  $UIBucketName         = "securityhub-dashboard-ui",
    [string]  $LambdaCodeBucket     = "",

    [Parameter(Mandatory=$true)]
    [string]  $SesFromEmail,

    [Parameter(Mandatory=$true)]
    [string]  $SesToEmail,

    [Parameter(Mandatory=$true)]
    [string]  $DashboardDomain,

    [Parameter(Mandatory=$true)]
    [string]  $AcmCertificateArn,

    [Parameter(Mandatory=$true)]
    [string]  $CognitoDomainPrefix,

    [Parameter(Mandatory=$true)]
    [string]  $AdminEmail,

    [string]  $AggregatorSchedule   = "cron(0 2 * * ? *)",
    [int]     $AggregatorMemory     = 1024,
    [int]     $AggregatorTimeout    = 840,
    [string]  $AccountNameOverrides = "",
    [string]  $OrgId                = "",
    [string]  $OuIds                = "",
    [string]  $DashboardSourceDir   = "",
    [switch]  $SkipBuild,
    [switch]  $SkipStackSet
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
function Write-Step   { param([string]$msg) Write-Host "`n===  $msg  ===" -ForegroundColor Cyan }
function Write-OK     { param([string]$msg) Write-Host "  [OK]  $msg"    -ForegroundColor Green }
function Write-Warn   { param([string]$msg) Write-Host "  [WARN] $msg"   -ForegroundColor Yellow }
function Write-Fail   { param([string]$msg) Write-Host "  [FAIL] $msg"   -ForegroundColor Red; exit 1 }
function Write-Info   { param([string]$msg) Write-Host "        $msg"    -ForegroundColor Gray }

function Invoke-AWS {
    param([string[]]$Args)
    $result = & aws @Args 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "AWS CLI command failed:`n  aws $($Args -join ' ')`n  $result"
    }
    return $result
}

function Get-StackOutput {
    param([string]$OutputKey)
    $raw = Invoke-AWS @("cloudformation","describe-stacks",
                         "--stack-name", $StackName,
                         "--region", $Region,
                         "--query", "Stacks[0].Outputs[?OutputKey=='$OutputKey'].OutputValue",
                         "--output", "text")
    return $raw.Trim()
}

# ---------------------------------------------------------------------------
# RESOLVE PATHS
# ---------------------------------------------------------------------------
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path   # cfn/

# packagev1.5 is the parent of cfn/
$PackageDir = Split-Path -Parent $ScriptDir

if ([string]::IsNullOrWhiteSpace($DashboardSourceDir)) {
    $DashboardSourceDir = $PackageDir
}

$AggregatorSrc  = Join-Path $PackageDir "aggregator_lambda.py"
$ApiSrc         = Join-Path $PackageDir "api_lambda.py"
$ReportGenSrc   = Join-Path $PackageDir "report_generator_lambda.py"
$InventorySrc   = Join-Path $PackageDir "inventory_lambda.py"
$MainTemplate   = Join-Path $ScriptDir  "securityhub-dashboard-main.yaml"
$MemberTemplate = Join-Path $ScriptDir  "securityhub-member-role.yaml"
$BuildDir       = Join-Path $PackageDir "build"
$AggBuildDir    = Join-Path $BuildDir   "aggregator"
$ApiBuildDir    = Join-Path $BuildDir   "api"
$ReportGenBuildDir = Join-Path $BuildDir "report_generator"
$InventoryBuildDir = Join-Path $BuildDir "inventory"

# ---------------------------------------------------------------------------
# STEP 0 — PREREQUISITES
# ---------------------------------------------------------------------------
Write-Step "Step 0 — Validating prerequisites"

foreach ($tool in @("aws","python","pip","node","npm")) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
        Write-Fail "'$tool' not found in PATH. Install it before running this script."
    }
    Write-OK "$tool found"
}

# Verify AWS credentials are active
$AccountId = (Invoke-AWS @("sts","get-caller-identity","--query","Account","--output","text")).Trim()
Write-OK "AWS credentials valid — Account: $AccountId"

# Resolve Lambda code bucket (default to account-scoped name if not provided)
if ([string]::IsNullOrWhiteSpace($LambdaCodeBucket)) {
    $LambdaCodeBucket = "securityhub-lambda-code-$AccountId"
}

$AggregatorCodeKey    = "lambda-code/aggregator_lambda.zip"
$ApiCodeKey           = "lambda-code/api_lambda.zip"
$ReportGeneratorCodeKey = "lambda-code/report_generator_lambda.zip"
$InventoryCodeKey     = "lambda-code/inventory_lambda.zip"

Write-Info "Stack name      : $StackName"
Write-Info "Environment     : $StackEnv"
Write-Info "Region          : $Region"
Write-Info "Data bucket     : $DataBucketName"
Write-Info "UI bucket       : $UIBucketName"
Write-Info "Lambda bucket   : $LambdaCodeBucket"
Write-Info "Dashboard dir   : $DashboardSourceDir"

# ---------------------------------------------------------------------------
# STEP 1 — LAMBDA CODE STAGING BUCKET
# ---------------------------------------------------------------------------
Write-Step "Step 1 — Lambda code staging bucket"

$bucketExists = & aws s3api head-bucket --bucket $LambdaCodeBucket --region $Region 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Info "Creating bucket $LambdaCodeBucket ..."
    Invoke-AWS @("s3api","create-bucket",
                 "--bucket", $LambdaCodeBucket,
                 "--region", $Region,
                 "--create-bucket-configuration", "LocationConstraint=$Region") | Out-Null
    Invoke-AWS @("s3api","put-public-access-block",
                 "--bucket", $LambdaCodeBucket,
                 "--public-access-block-configuration",
                 "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true") | Out-Null
    Write-OK "Bucket created: $LambdaCodeBucket"
} else {
    Write-OK "Bucket already exists: $LambdaCodeBucket"
}

# ---------------------------------------------------------------------------
# STEP 2 — PACKAGE AGGREGATOR LAMBDA
# ---------------------------------------------------------------------------
Write-Step "Step 2 — Packaging Aggregator Lambda"

if (Test-Path $AggBuildDir) { Remove-Item -Recurse -Force $AggBuildDir }
New-Item -ItemType Directory -Path $AggBuildDir -Force | Out-Null

Copy-Item $AggregatorSrc $AggBuildDir

Write-Info "Aggregator no longer requires fpdf2/openpyxl (report generation moved to report_generator_lambda)."

$AggZip = Join-Path $BuildDir "aggregator_lambda.zip"
if (Test-Path $AggZip) { Remove-Item $AggZip -Force }

Push-Location $AggBuildDir
& python -c "
import zipfile, os, sys
z = zipfile.ZipFile(sys.argv[1], 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk('.'):
    # Skip __pycache__ and .dist-info directories
    dirs[:] = [d for d in dirs if d not in ('__pycache__',) and not d.endswith('.dist-info')]
    for f in files:
        if not f.endswith('.pyc'):
            path = os.path.join(root, f)
            z.write(path, path.lstrip('./'))
z.close()
print('ZIP created:', sys.argv[1])
" $AggZip
Pop-Location

if (-not (Test-Path $AggZip)) { Write-Fail "Aggregator ZIP was not created." }
$aggSize = [math]::Round((Get-Item $AggZip).Length / 1MB, 1)
Write-OK "Aggregator ZIP: $AggZip ($aggSize MB)"

Write-Info "Uploading to s3://$LambdaCodeBucket/$AggregatorCodeKey ..."
Invoke-AWS @("s3","cp", $AggZip, "s3://$LambdaCodeBucket/$AggregatorCodeKey",
             "--region", $Region) | Out-Null
Write-OK "Aggregator ZIP uploaded"

# ---------------------------------------------------------------------------
# STEP 3 — PACKAGE API LAMBDA
# ---------------------------------------------------------------------------
Write-Step "Step 3 — Packaging API Lambda"

if (Test-Path $ApiBuildDir) { Remove-Item -Recurse -Force $ApiBuildDir }
New-Item -ItemType Directory -Path $ApiBuildDir -Force | Out-Null
Copy-Item $ApiSrc $ApiBuildDir

$ApiZip = Join-Path $BuildDir "api_lambda.zip"
if (Test-Path $ApiZip) { Remove-Item $ApiZip -Force }

Push-Location $ApiBuildDir
& python -c "
import zipfile, os, sys
z = zipfile.ZipFile(sys.argv[1], 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk('.'):
    for f in files:
        if not f.endswith('.pyc'):
            path = os.path.join(root, f)
            z.write(path, path.lstrip('./'))
z.close()
print('ZIP created:', sys.argv[1])
" $ApiZip
Pop-Location

if (-not (Test-Path $ApiZip)) { Write-Fail "API ZIP was not created." }
$apiSize = [math]::Round((Get-Item $ApiZip).Length / 1KB, 0)
Write-OK "API ZIP: $ApiZip ($apiSize KB)"

Write-Info "Uploading to s3://$LambdaCodeBucket/$ApiCodeKey ..."
Invoke-AWS @("s3","cp", $ApiZip, "s3://$LambdaCodeBucket/$ApiCodeKey",
             "--region", $Region) | Out-Null
Write-OK "API ZIP uploaded"

# ---------------------------------------------------------------------------
# STEP 3b — PACKAGE REPORT GENERATOR LAMBDA
# ---------------------------------------------------------------------------
Write-Step "Step 3b — Packaging Report Generator Lambda"

if (Test-Path $ReportGenBuildDir) { Remove-Item -Recurse -Force $ReportGenBuildDir }
New-Item -ItemType Directory -Path $ReportGenBuildDir -Force | Out-Null
Copy-Item $ReportGenSrc $ReportGenBuildDir

Write-Info "Installing Python dependencies for report generator ..."
& pip install fpdf2 openpyxl -t $ReportGenBuildDir --quiet
if ($LASTEXITCODE -ne 0) { Write-Fail "pip install failed for report_generator dependencies." }

$ReportGenZip = Join-Path $BuildDir "report_generator_lambda.zip"
if (Test-Path $ReportGenZip) { Remove-Item $ReportGenZip -Force }

Push-Location $ReportGenBuildDir
& python -c "
import zipfile, os, sys
z = zipfile.ZipFile(sys.argv[1], 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in ('__pycache__',) and not d.endswith('.dist-info')]
    for f in files:
        if not f.endswith('.pyc'):
            path = os.path.join(root, f)
            z.write(path, path.lstrip('./'))
z.close()
print('ZIP created:', sys.argv[1])
" $ReportGenZip
Pop-Location

if (-not (Test-Path $ReportGenZip)) { Write-Fail "Report Generator ZIP was not created." }
$rgSize = [math]::Round((Get-Item $ReportGenZip).Length / 1MB, 1)
Write-OK "Report Generator ZIP: $ReportGenZip ($rgSize MB)"

Write-Info "Uploading to s3://$LambdaCodeBucket/$ReportGeneratorCodeKey ..."
Invoke-AWS @("s3","cp", $ReportGenZip, "s3://$LambdaCodeBucket/$ReportGeneratorCodeKey",
             "--region", $Region) | Out-Null
Write-OK "Report Generator ZIP uploaded"

# ---------------------------------------------------------------------------
# STEP 3c — PACKAGE INVENTORY LAMBDA
# ---------------------------------------------------------------------------
Write-Step "Step 3c — Packaging Inventory Lambda"

if (Test-Path $InventoryBuildDir) { Remove-Item -Recurse -Force $InventoryBuildDir }
New-Item -ItemType Directory -Path $InventoryBuildDir -Force | Out-Null
Copy-Item $InventorySrc $InventoryBuildDir

$InventoryZip = Join-Path $BuildDir "inventory_lambda.zip"
if (Test-Path $InventoryZip) { Remove-Item $InventoryZip -Force }

Push-Location $InventoryBuildDir
& python -c "
import zipfile, os, sys
z = zipfile.ZipFile(sys.argv[1], 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk('.'):
    for f in files:
        if not f.endswith('.pyc'):
            path = os.path.join(root, f)
            z.write(path, path.lstrip('./'))
z.close()
print('ZIP created:', sys.argv[1])
" $InventoryZip
Pop-Location

if (-not (Test-Path $InventoryZip)) { Write-Fail "Inventory ZIP was not created." }
$invSize = [math]::Round((Get-Item $InventoryZip).Length / 1KB, 0)
Write-OK "Inventory ZIP: $InventoryZip ($invSize KB)"

Write-Info "Uploading to s3://$LambdaCodeBucket/$InventoryCodeKey ..."
Invoke-AWS @("s3","cp", $InventoryZip, "s3://$LambdaCodeBucket/$InventoryCodeKey",
             "--region", $Region) | Out-Null
Write-OK "Inventory ZIP uploaded"

# ---------------------------------------------------------------------------
# STEP 4 — VALIDATE CLOUDFORMATION TEMPLATES
# ---------------------------------------------------------------------------
Write-Step "Step 4 — Validating CloudFormation templates"

Invoke-AWS @("cloudformation","validate-template",
             "--template-body", "file://$MainTemplate",
             "--region", $Region) | Out-Null
Write-OK "Main template valid: $MainTemplate"

Invoke-AWS @("cloudformation","validate-template",
             "--template-body", "file://$MemberTemplate",
             "--region", $Region) | Out-Null
Write-OK "Member template valid: $MemberTemplate"

# ---------------------------------------------------------------------------
# STEP 5 — DEPLOY / UPDATE MAIN CLOUDFORMATION STACK
# ---------------------------------------------------------------------------
Write-Step "Step 5 — Deploying main CloudFormation stack: $StackName"

# Check if stack already exists
$stackStatus = & aws cloudformation describe-stacks `
    --stack-name $StackName --region $Region `
    --query "Stacks[0].StackStatus" --output text 2>&1

$stackExists = ($LASTEXITCODE -eq 0)

$cfnParams = @(
    "StackEnv=$StackEnv",
    "DataBucketName=$DataBucketName",
    "UIBucketName=$UIBucketName",
    "SesFromEmail=$SesFromEmail",
    "SesToEmail=$SesToEmail",
    "DashboardDomain=$DashboardDomain",
    "AcmCertificateArn=$AcmCertificateArn",
    "CognitoDomainPrefix=$CognitoDomainPrefix",
    "AdminEmail=$AdminEmail",
    "AggregatorSchedule=$AggregatorSchedule",
    "AggregatorMemory=$AggregatorMemory",
    "AggregatorTimeout=$AggregatorTimeout",
    "AccountNameOverrides=$AccountNameOverrides",
    "LambdaCodeBucket=$LambdaCodeBucket",
    "AggregatorCodeKey=$AggregatorCodeKey",
    "ApiCodeKey=$ApiCodeKey",
    "ReportGeneratorCodeKey=$ReportGeneratorCodeKey",
    "InventoryCodeKey=$InventoryCodeKey"
)

# Build --parameter-overrides string
$paramOverrides = ($cfnParams | ForEach-Object { $_ }) -join " "

Write-Info "Deploying stack (this can take 10-20 minutes for first deploy)..."

Invoke-AWS @("cloudformation","deploy",
             "--stack-name",        $StackName,
             "--template-file",     $MainTemplate,
             "--region",            $Region,
             "--capabilities",      "CAPABILITY_NAMED_IAM",
             "--no-fail-on-empty-changeset",
             "--parameter-overrides") + $cfnParams | Out-Null

Write-OK "Stack deployed: $StackName"

# ---------------------------------------------------------------------------
# STEP 6 — READ STACK OUTPUTS & GENERATE .env
# ---------------------------------------------------------------------------
Write-Step "Step 6 — Reading stack outputs"

$ApiGatewayUrl       = Get-StackOutput "ApiGatewayUrl"
$UserPoolId          = Get-StackOutput "UserPoolId"
$UserPoolClientId    = Get-StackOutput "UserPoolClientId"
$CognitoHostedDomain = Get-StackOutput "CognitoHostedUIDomain"
$CloudFrontDistId    = Get-StackOutput "CloudFrontDistributionId"
$CloudFrontDomain    = Get-StackOutput "CloudFrontDomain"
$AggregatorRoleArn   = Get-StackOutput "AggregatorRoleArn"
$UIBucketOut         = Get-StackOutput "UIBucketName"

Write-OK "API Gateway URL      : $ApiGatewayUrl"
Write-OK "Cognito User Pool ID : $UserPoolId"
Write-OK "Cognito Client ID    : $UserPoolClientId"
Write-OK "CloudFront Domain    : $CloudFrontDomain"
Write-OK "Aggregator Role ARN  : $AggregatorRoleArn"

# Write .env file into the dashboard source directory
$EnvFile = Join-Path $DashboardSourceDir ".env"
@"
# Auto-generated by deploy.ps1 on $(Get-Date -Format "yyyy-MM-dd HH:mm:ss UTC")
# DO NOT COMMIT THIS FILE TO VERSION CONTROL

VITE_API_BASE=$ApiGatewayUrl
VITE_COGNITO_USER_POOL_ID=$UserPoolId
VITE_COGNITO_CLIENT_ID=$UserPoolClientId
VITE_COGNITO_DOMAIN=$CognitoDomainPrefix.auth.$Region.amazoncognito.com
VITE_REDIRECT_URI=https://$DashboardDomain
"@ | Set-Content -Path $EnvFile -Encoding UTF8

Write-OK ".env written: $EnvFile"
Write-Warn "Ensure .env is in .gitignore — it contains environment-specific config."

# ---------------------------------------------------------------------------
# STEP 7 — BUILD REACT DASHBOARD
# ---------------------------------------------------------------------------
if (-not $SkipBuild) {
    Write-Step "Step 7 — Building React dashboard"

    if (-not (Test-Path (Join-Path $DashboardSourceDir "package.json"))) {
        Write-Fail "package.json not found in $DashboardSourceDir. Is -DashboardSourceDir correct?"
    }

    Write-Info "Running npm install ..."
    Push-Location $DashboardSourceDir
    & npm install --silent
    if ($LASTEXITCODE -ne 0) { Pop-Location; Write-Fail "npm install failed." }

    Write-Info "Running npm run build ..."
    & npm run build
    if ($LASTEXITCODE -ne 0) { Pop-Location; Write-Fail "npm run build failed." }
    Pop-Location

    $DistDir = Join-Path $DashboardSourceDir "dist"
    if (-not (Test-Path $DistDir)) {
        Write-Fail "dist/ folder not found after build. Check your Vite config."
    }
    Write-OK "Dashboard built: $DistDir"
} else {
    Write-Warn "Step 7 skipped — -SkipBuild flag set."
    $DistDir = Join-Path $DashboardSourceDir "dist"
}

# ---------------------------------------------------------------------------
# STEP 8 — SYNC DASHBOARD TO S3
# ---------------------------------------------------------------------------
Write-Step "Step 8 — Syncing dashboard to S3"

if (-not (Test-Path $DistDir)) {
    Write-Fail "dist/ directory not found at $DistDir. Run without -SkipBuild first."
}

# Sync all assets except index.html with long-lived cache
Write-Info "Uploading hashed assets (1 year cache) ..."
Invoke-AWS @("s3","sync", $DistDir, "s3://$UIBucketOut/",
             "--region", $Region,
             "--delete",
             "--cache-control", "max-age=31536000,immutable",
             "--exclude", "index.html") | Out-Null

# index.html must not be cached (it references hashed asset filenames)
Write-Info "Uploading index.html (no-cache) ..."
Invoke-AWS @("s3","cp",
             (Join-Path $DistDir "index.html"),
             "s3://$UIBucketOut/index.html",
             "--region", $Region,
             "--cache-control", "no-cache,no-store,must-revalidate",
             "--content-type", "text/html") | Out-Null

Write-OK "Dashboard synced to s3://$UIBucketOut/"

# ---------------------------------------------------------------------------
# STEP 9 — CLOUDFRONT CACHE INVALIDATION
# ---------------------------------------------------------------------------
Write-Step "Step 9 — CloudFront cache invalidation"

Invoke-AWS @("cloudfront","create-invalidation",
             "--distribution-id", $CloudFrontDistId,
             "--paths", "/*") | Out-Null

Write-OK "Invalidation created for CloudFront distribution: $CloudFrontDistId"
Write-Info "Cache invalidation takes 1-5 minutes to propagate globally."

# ---------------------------------------------------------------------------
# STEP 10 — STACKSET FOR MEMBER ACCOUNT ROLES
# ---------------------------------------------------------------------------
if (-not $SkipStackSet) {
    Write-Step "Step 10 — Deploying member account StackSet"

    if ([string]::IsNullOrWhiteSpace($OrgId) -or [string]::IsNullOrWhiteSpace($OuIds)) {
        Write-Warn "OrgId or OuIds not provided — skipping StackSet deployment."
        Write-Warn "Run manually or re-run with -OrgId and -OuIds to deploy TrustedAdvisorReadOnlyRole."
    } else {
        $StackSetName    = "$StackName-member-roles"
        $OuIdList        = $OuIds -split "," | ForEach-Object { $_.Trim() }
        $MemberRegions   = @("eu-west-1")   # StackSet deploys IAM (global) — any region works

        # Check if StackSet exists
        $ssExists = & aws cloudformation describe-stack-set `
            --stack-set-name $StackSetName --region $Region 2>&1
        $ssAlreadyExists = ($LASTEXITCODE -eq 0)

        $memberParams = @(
            "ParameterKey=AggregatorRoleArn,ParameterValue=$AggregatorRoleArn",
            "ParameterKey=RoleName,ParameterValue=TrustedAdvisorReadOnlyRole",
            "ParameterKey=StackEnv,ParameterValue=$StackEnv"
        )

        if (-not $ssAlreadyExists) {
            Write-Info "Creating StackSet: $StackSetName ..."
            Invoke-AWS @("cloudformation","create-stack-set",
                         "--stack-set-name",   $StackSetName,
                         "--template-body",    "file://$MemberTemplate",
                         "--region",           $Region,
                         "--permission-model", "SERVICE_MANAGED",
                         "--auto-deployment",  "Enabled=true,RetainStacksOnAccountRemoval=false",
                         "--capabilities",     "CAPABILITY_NAMED_IAM",
                         "--parameters")       + $memberParams | Out-Null
            Write-OK "StackSet created: $StackSetName"
        } else {
            Write-Info "Updating existing StackSet: $StackSetName ..."
            Invoke-AWS @("cloudformation","update-stack-set",
                         "--stack-set-name",   $StackSetName,
                         "--template-body",    "file://$MemberTemplate",
                         "--region",           $Region,
                         "--capabilities",     "CAPABILITY_NAMED_IAM",
                         "--parameters")       + $memberParams | Out-Null
            Write-OK "StackSet updated: $StackSetName"
        }

        # Deploy to target OUs
        $ouTargets = ($OuIdList | ForEach-Object { "Id=$_" }) -join ","

        Write-Info "Creating stack instances in OUs: $($OuIdList -join ', ') ..."
        Invoke-AWS @("cloudformation","create-stack-instances",
                     "--stack-set-name",             $StackSetName,
                     "--region",                     $Region,
                     "--deployment-targets",          "OrganizationalUnitIds=$($OuIdList -join ',')",
                     "--regions",                     ($MemberRegions -join " "),
                     "--operation-preferences",
                     "FailureToleranceCount=5,MaxConcurrentCount=10") | Out-Null

        Write-OK "StackSet instances initiated — deploying to all accounts in specified OUs."
        Write-Info "Monitor progress: AWS Console > CloudFormation > StackSets > $StackSetName"
    }
} else {
    Write-Warn "Step 10 skipped — -SkipStackSet flag set."
}

# ---------------------------------------------------------------------------
# STEP 11 — TRIGGER FIRST AGGREGATOR RUN
# ---------------------------------------------------------------------------
Write-Step "Step 11 — Triggering first aggregator run"

$AggFnName = "securityhub-aggregator-$StackEnv"
$InvokeOut = Join-Path $BuildDir "aggregator-first-run-response.json"

New-Item -ItemType Directory -Path $BuildDir -Force | Out-Null

Write-Info "Invoking Lambda: $AggFnName ..."
Invoke-AWS @("lambda","invoke",
             "--function-name", $AggFnName,
             "--region",        $Region,
             "--log-type",      "Tail",
             $InvokeOut) | Out-Null

if (Test-Path $InvokeOut) {
    $response = Get-Content $InvokeOut -Raw
    Write-OK "Aggregator invoked. Response: $response"
} else {
    Write-Warn "Could not read aggregator response. Check CloudWatch logs."
}

# ---------------------------------------------------------------------------
# POST-DEPLOY SUMMARY
# ---------------------------------------------------------------------------
Write-Step "Deployment Complete"

Write-Host ""
Write-Host "  Dashboard URL        : https://$DashboardDomain" -ForegroundColor White
Write-Host "  CloudFront Domain    : $CloudFrontDomain"         -ForegroundColor Gray
Write-Host "  API Gateway URL      : $ApiGatewayUrl"            -ForegroundColor Gray
Write-Host "  Cognito User Pool    : $UserPoolId"               -ForegroundColor Gray
Write-Host "  Cognito Hosted UI    : $CognitoHostedDomain"      -ForegroundColor Gray
Write-Host "  CloudFront Dist ID   : $CloudFrontDistId"         -ForegroundColor Gray
Write-Host ""
Write-Host "  NEXT STEPS:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  1. Create a DNS CNAME record:" -ForegroundColor White
Write-Host "       $DashboardDomain  ->  $CloudFrontDomain"
Write-Host ""
Write-Host "  2. Verify SES sender identity in the AWS console (if not already done):" -ForegroundColor White
Write-Host "       SES > Verified identities > $SesFromEmail"
Write-Host ""
Write-Host "  3. Sign in to the dashboard with your admin user:" -ForegroundColor White
Write-Host "       Email: $AdminEmail"
Write-Host "       (Temporary password sent to this address by Cognito)"
Write-Host ""
Write-Host "  4. Check aggregator output in CloudWatch:" -ForegroundColor White
Write-Host "       /aws/lambda/securityhub-aggregator-$StackEnv"
Write-Host ""
Write-Host "  5. If StackSet was skipped, deploy member roles manually:" -ForegroundColor White
Write-Host "       Re-run with -OrgId <o-xxx> -OuIds <ou-xxx>"
Write-Host ""
Write-Host "  Aggregator Role ARN (for member role trust policies):" -ForegroundColor White
Write-Host "       $AggregatorRoleArn"
Write-Host ""
