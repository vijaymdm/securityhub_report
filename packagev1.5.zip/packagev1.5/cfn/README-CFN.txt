================================================================================
  AWS SECURITY HUB COMPLIANCE DASHBOARD
  CloudFormation Deployment Guide
  Version 1.5.9  |  Region: eu-west-1  |  September 2026
================================================================================

TABLE OF CONTENTS
-----------------
  1.  Overview
  2.  Package Contents
  3.  What CloudFormation Creates
  4.  What Requires Manual Action
  5.  Prerequisites
  6.  Quick Start — Automated Deploy (deploy.ps1)
  7.  Manual Deploy — Step by Step
  8.  StackSet — Member Account Roles
  9.  Dashboard Build & Auth Integration
  10. Stack Parameters Reference
  11. Stack Outputs Reference
  12. Post-Deploy Checklist
  13. Updating the Stack
  14. Stack Teardown
  15. Troubleshooting


================================================================================
1. OVERVIEW
================================================================================

This CloudFormation package deploys the entire Security Hub Compliance
Dashboard infrastructure in a single stack command. The deploy.ps1 script
automates all steps end-to-end including Lambda packaging, dashboard build,
S3 upload, and CloudFront invalidation.

Two CloudFormation templates are provided:

  securityhub-dashboard-main.yaml
    Deploys all infrastructure in the Security Hub delegated admin account
    in eu-west-1. This is the primary template.

  securityhub-member-role.yaml
    Deploys TrustedAdvisorReadOnlyRole in each AWS member account.
    Designed for AWS CloudFormation StackSets with SERVICE_MANAGED permissions.
    Handles 70+ member accounts in one operation.

One deployment script:

  deploy.ps1
    PowerShell script that runs the full 11-step deployment sequence
    automatically. Can also be used for code-only updates.


================================================================================
2. PACKAGE CONTENTS
================================================================================

  cfn/
  ├── securityhub-dashboard-main.yaml   Main infrastructure stack template
  ├── securityhub-member-role.yaml      Member account StackSet template
  ├── deploy.ps1                        End-to-end deployment script
  └── README-CFN.txt                    This file

  aggregator_lambda.py                  Aggregator Lambda source (v1.5.9)
  api_lambda.py                         API Lambda source (v1.5.2)
  report_generator_lambda.py            Report Generator Lambda source (v1.0.1)
  inventory_lambda.py                   Inventory Lambda source (v1.0.0)
  securityhub-dashboard.jsx             React dashboard component (v1.5.5)
  main.jsx                              React app entry point
  CHANGELOG.md                          Full version history
  README.txt                            Manual (non-CFN) deployment guide


================================================================================
3. WHAT CLOUDFORMATION CREATES
================================================================================

The main stack (securityhub-dashboard-main.yaml) creates these resources:

  STORAGE
  -------
  AWS::S3::Bucket           DataBucket
    S3 data bucket for all aggregator output (summaries, reports, snapshots).
    Versioning enabled. Server-side encryption (AES256). Public access blocked.
    Lifecycle rules: snapshots expire after 90 days, old report versions after
    30 days. Bucket policy enforces HTTPS-only and encrypted uploads.

  AWS::S3::Bucket           UIBucket
    S3 hosting bucket for the React dashboard. Private — accessed only via
    CloudFront OAC. Bucket policy grants read access to CloudFront only.

  AUTHENTICATION
  --------------
  AWS::Cognito::UserPool              User pool with email sign-in, MFA
                                      (optional TOTP), 12-char password policy,
                                      and admin-only user creation.
  AWS::Cognito::UserPoolDomain        Hosted UI domain for sign-in/sign-out.
  AWS::Cognito::UserPoolClient        SPA app client — no secret, PKCE/auth
                                      code flow, 1h token validity.
  AWS::Cognito::UserPoolUser          First admin user (temporary password
                                      emailed to AdminEmail).

  IAM
  ---
  AWS::IAM::Role            AggregatorRole
    Lambda execution role for the aggregator. Grants:
    - securityhub:GetFindings
    - s3:PutObject + s3:GetObject on data bucket
    - ses:SendEmail on the verified SES identity
    - sts:GetCallerIdentity + sts:AssumeRole (TrustedAdvisorReadOnlyRole)
    - support:DescribeTrustedAdvisorChecks + DescribeTrustedAdvisorCheckResult
    - organizations:ListAccounts
    - inspector2:BatchGetAccountStatus

  AWS::IAM::Role            ApiRole
    Lambda execution role for the API. Grants:
    - s3:GetObject + s3:HeadObject on summaries/*, trusted-advisor/*,
      reports/*, inspector/*, inventory/*
    - s3:PutObject on reports/*/status.json and inventory/*/status.json
    - lambda:InvokeFunction on ReportGeneratorLambda and InventoryLambda

  AWS::IAM::Role            ReportGeneratorRole
    Lambda execution role for the report generator. Grants:
    - s3:GetObject on summaries/*, snapshots/*
    - s3:PutObject + s3:GetObject on reports/*

  AWS::IAM::Role            InventoryRole
    Lambda execution role for the inventory builder. Grants:
    - s3:GetObject on summaries/*
    - s3:PutObject + s3:GetObject on inventory/*

  COMPUTE
  -------
  AWS::Lambda::Function     AggregatorLambda
    Python 3.12, 1024 MB, 840s timeout, DLQ attached.
    Environment variables: BUCKET, SES_FROM_EMAIL, SES_TO_EMAIL,
    ACCOUNT_NAME_OVERRIDES.

  AWS::Lambda::Function     ApiLambda
    Python 3.12, 256 MB, 30s timeout.
    Environment variables: BUCKET, CORS_ALLOW_ORIGIN,
    REPORT_GENERATOR_FUNCTION_NAME, INVENTORY_FUNCTION_NAME.

  AWS::Lambda::Function     ReportGeneratorLambda
    Python 3.12, 1024 MB, 840s timeout. Invoked async by API Lambda.
    Builds PDF/CSV/XLSX reports from S3 summaries on demand.
    Environment variable: BUCKET.

  AWS::Lambda::Function     InventoryLambda
    Python 3.12, 512 MB, 300s timeout. Invoked async by API Lambda.
    Derives per-account service/resource inventory from S3 findings.
    Environment variable: BUCKET.

  AWS::Logs::LogGroup       AggregatorLogGroup    90-day retention
  AWS::Logs::LogGroup       ApiLogGroup           90-day retention
  AWS::Logs::LogGroup       ApiAccessLogGroup     90-day retention (API GW)

  AWS::SQS::Queue           AggregatorDLQ
    Dead Letter Queue for failed aggregator invocations. 14-day retention.

  SCHEDULING
  ----------
  AWS::Events::Rule         AggregatorScheduleRule
    EventBridge cron rule (default: 02:00 UTC daily).
    Triggers AggregatorLambda.

  API
  ---
  AWS::ApiGatewayV2::Api            HTTP API with CORS configured.
  AWS::ApiGatewayV2::Integration    Lambda proxy integration.
  AWS::ApiGatewayV2::Route          GET /{proxy+}    — JWT auth required.
  AWS::ApiGatewayV2::Route          POST /{proxy+}   — JWT auth (generate-report, generate-inventory).
  AWS::ApiGatewayV2::Route          OPTIONS /{proxy+} — no auth (CORS).
  AWS::ApiGatewayV2::Stage          $default, auto-deploy, throttling 50 rps.
  AWS::ApiGatewayV2::Authorizer     Cognito JWT authorizer.

  EMAIL
  -----
  AWS::SES::EmailIdentity   SesEmailIdentity
    Registers SesFromEmail in SES. Verification email/DNS record is sent
    automatically — must be actioned before the email digest will send.

  CDN
  ---
  AWS::CloudFront::OriginAccessControl  OAC for UI bucket.
  AWS::CloudFront::Distribution
    HTTPS only, TLSv1.2_2021, HTTP/2, IPv6. Custom domain with ACM cert.
    SPA error pages: 403/404 → /index.html → 200.
    Cache policy: CachingOptimized. CloudFront access logs to UI bucket.

  MONITORING
  ----------
  AWS::CloudWatch::Alarm    AggregatorErrorAlarm
    Fires when aggregator Lambda has >= 1 error in a 24h period.

  AWS::CloudWatch::Alarm    AggregatorDurationAlarm
    Fires when aggregator duration exceeds 13 minutes (warns before timeout).

  AWS::CloudWatch::Alarm    DLQDepthAlarm
    Fires when the DLQ has >= 1 message (failed invocation not retried).


================================================================================
4. WHAT REQUIRES MANUAL ACTION
================================================================================

Four things cannot be fully automated by CloudFormation:

  A. SES SENDER VERIFICATION
     CloudFormation creates the SES identity resource, but the domain/email
     must be actively verified before SES will send emails:
     - Email identity: click the verification link sent to SesFromEmail.
     - Domain identity: add DKIM CNAME records shown in the SES console.
     - If SES is in sandbox: also verify SesToEmail as a recipient, or
       request SES production access (AWS Support case, ~24h).

  B. DNS CNAME RECORD
     After the stack deploys, CloudFront issues a distribution domain
     (e.g. abc123.cloudfront.net). You must create a CNAME record in
     your DNS provider:
       DashboardDomain  ->  <CloudFrontDomain from stack output>
     This step is outside AWS — done in your DNS registrar or Route 53.

  C. ACM CERTIFICATE (pre-requisite)
     The AcmCertificateArn parameter must reference an existing ACM
     certificate in us-east-1 (CloudFront requirement) that covers
     DashboardDomain. Request the certificate before running the stack:
       AWS Console > Certificate Manager > us-east-1 > Request certificate
     Or via CLI:
       aws acm request-certificate \
         --domain-name security.yourdomain.com \
         --validation-method DNS \
         --region us-east-1

  D. SECURITY HUB DELEGATED ADMIN (pre-requisite)
     The account where this stack is deployed must already be the Security
     Hub delegated administrator for your AWS Organization. This is a
     one-time setup not covered by CloudFormation:
       aws securityhub enable-delegated-admin-account \
         --admin-account-id <delegated-admin-account-id> \
         --region eu-west-1
     Run from the AWS Organizations management account.


================================================================================
5. PREREQUISITES
================================================================================

  TOOLS (must be in PATH)
  -----------------------
  - AWS CLI v2        https://aws.amazon.com/cli/
  - Python 3.12+      https://python.org
  - pip               (bundled with Python)
  - Node.js 18+       https://nodejs.org
  - npm               (bundled with Node.js)

  AWS ACCOUNT STATE
  -----------------
  - AWS CLI configured with credentials for the delegated admin account
  - Security Hub delegated admin enabled (see Section 4D)
  - ACM certificate requested and validated in us-east-1 (see Section 4C)
  - Business or Enterprise support plan (required for Trusted Advisor API)
  - AWS Organizations with SERVICE_MANAGED StackSets enabled
    (required for member role StackSet — see Section 8)

  PERMISSIONS REQUIRED BY THE DEPLOYING USER/ROLE
  ------------------------------------------------
  The IAM principal running deploy.ps1 needs:
    iam:CreateRole, iam:PutRolePolicy, iam:AttachRolePolicy
    iam:PassRole (to assign roles to Lambda)
    lambda:CreateFunction, lambda:UpdateFunctionCode
    lambda:UpdateFunctionConfiguration, lambda:AddPermission
    s3:CreateBucket, s3:PutBucketPolicy, s3:PutObject, s3:GetObject
    cloudformation:CreateStack, cloudformation:UpdateStack
    cloudformation:DescribeStacks, cloudformation:ValidateTemplate
    cloudformation:CreateStackSet, cloudformation:UpdateStackSet
    cloudformation:CreateStackInstances
    apigatewayv2:* (HTTP API creation)
    cognito-idp:* (User Pool creation)
    ses:CreateEmailIdentity, ses:GetEmailIdentity
    cloudfront:CreateDistribution, cloudfront:CreateInvalidation
    events:PutRule, events:PutTargets
    sqs:CreateQueue, sqs:SetQueueAttributes
    logs:CreateLogGroup, logs:PutRetentionPolicy
    cloudwatch:PutMetricAlarm


================================================================================
6. QUICK START — AUTOMATED DEPLOY (deploy.ps1)
================================================================================

This is the recommended deployment method. The script handles all 11 steps.

Step 1 — Request an ACM certificate (one-time, before stack deploy):

  aws acm request-certificate \
    --domain-name security.yourdomain.com \
    --validation-method DNS \
    --region us-east-1

  Add the DNS validation CNAME shown in the ACM console, wait for "Issued"
  status. Note the certificate ARN — you need it in the next step.

Step 2 — Open PowerShell and run deploy.ps1 from the cfn/ directory:

  cd packagev1.5\cfn

  .\deploy.ps1 `
    -SesFromEmail       "securityhub-noreply@yourdomain.com" `
    -SesToEmail         "security-team@yourdomain.com" `
    -DashboardDomain    "security.yourdomain.com" `
    -AcmCertificateArn  "arn:aws:acm:us-east-1:123456789012:certificate/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" `
    -CognitoDomainPrefix "securityhub-yourcompany" `
    -AdminEmail         "admin@yourdomain.com" `
    -OrgId              "o-xxxxxxxxxxxx" `
    -OuIds              "ou-xxxx-yyyyyyyy"

  The script takes approximately 15-25 minutes on first run (CloudFront
  distribution creation is the slowest step at 10-15 minutes).

Step 3 — After the script completes:

  a. Create the DNS CNAME record printed in the summary.
  b. Verify the SES sender identity in the SES console.
  c. Sign in to https://security.yourdomain.com with the AdminEmail address.
     Cognito sends a temporary password to that email automatically.

  That's it — the dashboard is live.

COMMON RE-DEPLOY SCENARIOS
---------------------------

  Update Lambda code only (no CFN changes, no npm build):
  .\deploy.ps1 [required params] -SkipBuild -SkipStackSet

  Update Lambda code + rebuild dashboard (no CFN changes):
  .\deploy.ps1 [required params] -SkipStackSet

  Full redeploy including CFN changes:
  .\deploy.ps1 [all params]

  Different environment (dev):
  .\deploy.ps1 [params] -StackEnv dev -DataBucketName securityhub-dashboard-data-dev


================================================================================
7. MANUAL DEPLOY — STEP BY STEP
================================================================================

Use this section if you prefer not to use deploy.ps1, or if you need to
deploy in a CI/CD pipeline using shell scripts.

Step 1 — Create Lambda code staging bucket (one-time)

  ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
  CODE_BUCKET="securityhub-lambda-code-${ACCOUNT_ID}"

  aws s3api create-bucket \
    --bucket $CODE_BUCKET \
    --region eu-west-1 \
    --create-bucket-configuration LocationConstraint=eu-west-1

Step 2 — Package and upload Aggregator Lambda

  mkdir -p build/aggregator
  cp aggregator_lambda.py build/aggregator/
  # No pip install needed — fpdf2/openpyxl were removed in v1.5.6
  # (report generation moved to report_generator_lambda)
  cd build/aggregator && zip aggregator_lambda.zip aggregator_lambda.py && cd ../..

  aws s3 cp build/aggregator_lambda.zip \
    s3://${CODE_BUCKET}/lambda-code/aggregator_lambda.zip \
    --region eu-west-1

Step 3 — Package and upload API Lambda

  mkdir -p build/api
  cp api_lambda.py build/api/
  cd build/api && zip api_lambda.zip api_lambda.py && cd ../..

  aws s3 cp build/api/api_lambda.zip \
    s3://${CODE_BUCKET}/lambda-code/api_lambda.zip \
    --region eu-west-1

Step 3b — Package and upload Report Generator Lambda

  mkdir -p build/report_generator
  cp report_generator_lambda.py build/report_generator/
  pip install fpdf2 openpyxl -t build/report_generator/
  cd build/report_generator && zip -r ../../build/report_generator_lambda.zip . && cd ../..

  aws s3 cp build/report_generator_lambda.zip \
    s3://${CODE_BUCKET}/lambda-code/report_generator_lambda.zip \
    --region eu-west-1

Step 3c — Package and upload Inventory Lambda

  mkdir -p build/inventory
  cp inventory_lambda.py build/inventory/
  cd build/inventory && zip inventory_lambda.zip inventory_lambda.py && cd ../..

  aws s3 cp build/inventory_lambda.zip \
    s3://${CODE_BUCKET}/lambda-code/inventory_lambda.zip \
    --region eu-west-1

Step 4 — Validate templates

  aws cloudformation validate-template \
    --template-body file://cfn/securityhub-dashboard-main.yaml \
    --region eu-west-1

  aws cloudformation validate-template \
    --template-body file://cfn/securityhub-member-role.yaml \
    --region eu-west-1

Step 5 — Deploy the main stack

  aws cloudformation deploy \
    --stack-name securityhub-dashboard \
    --template-file cfn/securityhub-dashboard-main.yaml \
    --region eu-west-1 \
    --capabilities CAPABILITY_NAMED_IAM \
    --parameter-overrides \
      StackEnv=prod \
      DataBucketName=securityhub-dashboard-data \
      UIBucketName=securityhub-dashboard-ui \
      SesFromEmail=securityhub-noreply@yourdomain.com \
      SesToEmail=security-team@yourdomain.com \
      DashboardDomain=security.yourdomain.com \
      AcmCertificateArn=arn:aws:acm:us-east-1:123456789012:certificate/xxxx \
      CognitoDomainPrefix=securityhub-yourcompany \
      AdminEmail=admin@yourdomain.com \
      LambdaCodeBucket=${CODE_BUCKET} \
      AggregatorCodeKey=lambda-code/aggregator_lambda.zip \
      ApiCodeKey=lambda-code/api_lambda.zip

Step 6 — Read stack outputs

  aws cloudformation describe-stacks \
    --stack-name securityhub-dashboard \
    --region eu-west-1 \
    --query "Stacks[0].Outputs" \
    --output table

Step 7 — Create dashboard .env from outputs

  API_URL=$(aws cloudformation describe-stacks \
    --stack-name securityhub-dashboard --region eu-west-1 \
    --query "Stacks[0].Outputs[?OutputKey=='ApiGatewayUrl'].OutputValue" \
    --output text)

  USER_POOL_ID=$(aws cloudformation describe-stacks \
    --stack-name securityhub-dashboard --region eu-west-1 \
    --query "Stacks[0].Outputs[?OutputKey=='UserPoolId'].OutputValue" \
    --output text)

  CLIENT_ID=$(aws cloudformation describe-stacks \
    --stack-name securityhub-dashboard --region eu-west-1 \
    --query "Stacks[0].Outputs[?OutputKey=='UserPoolClientId'].OutputValue" \
    --output text)

  cat > .env <<EOF
  VITE_API_BASE=${API_URL}
  VITE_COGNITO_USER_POOL_ID=${USER_POOL_ID}
  VITE_COGNITO_CLIENT_ID=${CLIENT_ID}
  VITE_COGNITO_DOMAIN=securityhub-yourcompany.auth.eu-west-1.amazoncognito.com
  VITE_REDIRECT_URI=https://security.yourdomain.com
  EOF

Step 8 — Build and deploy dashboard

  npm install && npm run build

  aws s3 sync dist/ s3://securityhub-dashboard-ui/ \
    --region eu-west-1 --delete \
    --cache-control "max-age=31536000,immutable" \
    --exclude "index.html"

  aws s3 cp dist/index.html s3://securityhub-dashboard-ui/index.html \
    --region eu-west-1 \
    --cache-control "no-cache,no-store,must-revalidate"

Step 9 — Invalidate CloudFront

  DIST_ID=$(aws cloudformation describe-stacks \
    --stack-name securityhub-dashboard --region eu-west-1 \
    --query "Stacks[0].Outputs[?OutputKey=='CloudFrontDistributionId'].OutputValue" \
    --output text)

  aws cloudfront create-invalidation \
    --distribution-id $DIST_ID \
    --paths "/*"

Step 10 — Trigger first aggregator run

  aws lambda invoke \
    --function-name securityhub-aggregator-prod \
    --region eu-west-1 \
    response.json && cat response.json


================================================================================
8. STACKSET — MEMBER ACCOUNT ROLES
================================================================================

The TrustedAdvisorReadOnlyRole must exist in every member account so the
aggregator can fetch Trusted Advisor data. The StackSet deploys this role
across all accounts in your AWS Organization automatically.

PREREQUISITES FOR STACKSETS
----------------------------
StackSets with SERVICE_MANAGED permissions require:
  1. AWS Organizations is enabled and has member accounts.
  2. Trusted access for CloudFormation StackSets is enabled in Organizations.

Enable trusted access (run once from the management account):

  aws organizations enable-aws-service-access \
    --service-principal stacksets.cloudformation.amazonaws.com

  aws cloudformation activate-organizations-access --region eu-west-1

HOW THE TRUST POLICY WORKS
---------------------------
The role trust policy in securityhub-member-role.yaml has two security layers:

  1. Principal lock: only the specific AggregatorRoleArn from the main stack
     can assume the role — not any role in the delegated admin account.

  2. ExternalId condition: the trust requires ExternalId={accountId}-ta-reader.
     This prevents confused deputy attacks — even if the Principal condition
     were somehow bypassed, a caller without the correct ExternalId is denied.
     The aggregator_lambda.py passes this ExternalId in every assume_role call.

WHAT THE DEPLOY SCRIPT DOES (Step 10)
--------------------------------------
  - Creates the StackSet with SERVICE_MANAGED permissions (uses Organizations
    for automatic deployment to new accounts as they join).
  - AutoDeployment=true — new accounts added to targeted OUs automatically
    get the role without a re-run.
  - Creates stack instances across specified OUs with:
    FailureToleranceCount=5  (5 accounts can fail before the operation stops)
    MaxConcurrentCount=10    (deploys to 10 accounts simultaneously)

MANUAL STACKSET COMMANDS
------------------------
If you need to deploy the StackSet manually or add new OUs later:

  # Create StackSet (first time)
  aws cloudformation create-stack-set \
    --stack-set-name securityhub-dashboard-member-roles \
    --template-body file://cfn/securityhub-member-role.yaml \
    --region eu-west-1 \
    --permission-model SERVICE_MANAGED \
    --auto-deployment "Enabled=true,RetainStacksOnAccountRemoval=false" \
    --capabilities CAPABILITY_NAMED_IAM \
    --parameters \
      ParameterKey=AggregatorRoleArn,ParameterValue=<AggregatorRoleArn> \
      ParameterKey=RoleName,ParameterValue=TrustedAdvisorReadOnlyRole \
      ParameterKey=StackEnv,ParameterValue=prod

  # Deploy to OUs
  aws cloudformation create-stack-instances \
    --stack-set-name securityhub-dashboard-member-roles \
    --region eu-west-1 \
    --deployment-targets OrganizationalUnitIds=ou-xxxx-yyyyyyyy \
    --regions eu-west-1 \
    --operation-preferences FailureToleranceCount=5,MaxConcurrentCount=10

  # Check deployment status
  aws cloudformation list-stack-instances \
    --stack-set-name securityhub-dashboard-member-roles \
    --region eu-west-1 \
    --query "Summaries[*].{Account:Account,Status:Status,Reason:StatusReason}" \
    --output table

  # Add a new OU later
  aws cloudformation create-stack-instances \
    --stack-set-name securityhub-dashboard-member-roles \
    --region eu-west-1 \
    --deployment-targets OrganizationalUnitIds=ou-xxxx-newouhere \
    --regions eu-west-1


================================================================================
9. DASHBOARD BUILD & AUTH INTEGRATION
================================================================================

The deploy.ps1 script handles the build step automatically, but if you are
integrating into an existing CI/CD pipeline, here is what the build requires.

AMPLIFY AUTH SETUP (main.jsx)
------------------------------
Add this to main.jsx before the ReactDOM.render call:

  import { Amplify } from 'aws-amplify';

  Amplify.configure({
    Auth: {
      Cognito: {
        userPoolId:       import.meta.env.VITE_COGNITO_USER_POOL_ID,
        userPoolClientId: import.meta.env.VITE_COGNITO_CLIENT_ID,
        loginWith: {
          oauth: {
            domain:          import.meta.env.VITE_COGNITO_DOMAIN,
            scopes:          ['openid', 'email', 'profile'],
            redirectSignIn:  [import.meta.env.VITE_REDIRECT_URI],
            redirectSignOut: [import.meta.env.VITE_REDIRECT_URI],
            responseType:    'code',
          }
        }
      }
    }
  });

PASSING THE JWT IN FETCH CALLS (securityhub-dashboard.jsx)
-----------------------------------------------------------
Replace the fetchWithTimeout function with this version to include the
Cognito ID token on every API request:

  import { fetchAuthSession } from 'aws-amplify/auth';

  async function getAuthHeaders() {
    try {
      const session = await fetchAuthSession();
      const token   = session.tokens?.idToken?.toString();
      return token ? { Authorization: `Bearer ${token}` } : {};
    } catch {
      return {};
    }
  }

  async function fetchWithTimeout(url, options = {}) {
    const controller = new AbortController();
    const timerId    = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    const authHdrs   = await getAuthHeaders();
    return fetch(url, {
      ...options,
      headers: { ...authHdrs, ...(options.headers || {}) },
      signal:  controller.signal,
    }).finally(() => clearTimeout(timerId));
  }

WRAPPING WITH AUTHENTICATOR (main.jsx)
---------------------------------------
  import { Authenticator } from '@aws-amplify/ui-react';
  import '@aws-amplify/ui-react/styles.css';

  root.render(
    <React.StrictMode>
      <Authenticator>
        {({ signOut }) => <SecurityHubDashboard signOut={signOut} />}
      </Authenticator>
    </React.StrictMode>
  );

REQUIRED NPM PACKAGES
---------------------
  npm install aws-amplify @aws-amplify/ui-react


================================================================================
10. STACK PARAMETERS REFERENCE
================================================================================

  Parameter              Required  Default                    Description
  ---------              --------  -------                    -----------
  StackEnv               no        prod                       dev / staging / prod
                                                              Used in resource names
                                                              and tags.

  DataBucketName         no        securityhub-dashboard-data S3 bucket for all
                                                              aggregator output.
                                                              Must be globally unique.

  UIBucketName           no        securityhub-dashboard-ui   S3 bucket for the
                                                              React app. Must be
                                                              globally unique.

  SesFromEmail           YES       —                          Verified SES sender.
                                                              Must be verified in SES
                                                              before emails will send.

  SesToEmail             YES       —                          Alert DL / recipient.
                                                              Must be verified if SES
                                                              is in sandbox mode.

  DashboardDomain        YES       —                          Custom domain for the
                                                              dashboard. DNS CNAME to
                                                              CloudFront required after
                                                              deploy.

  AcmCertificateArn      YES       —                          ACM certificate ARN.
                                                              MUST be in us-east-1.
                                                              Must cover DashboardDomain.

  CognitoDomainPrefix    YES       —                          Unique prefix for Cognito
                                                              hosted UI domain. Globally
                                                              unique, lowercase only.

  AdminEmail             YES       —                          First Cognito admin user.
                                                              Temporary password emailed
                                                              automatically.

  AggregatorSchedule     no        cron(0 2 * * ? *)          EventBridge schedule (UTC).
                                                              Adjust for your timezone.

  AggregatorMemory       no        1024                       Lambda memory in MB.
                                                              512-10240. 1024 recommended
                                                              for large orgs.

  AggregatorTimeout      no        840                        Lambda timeout in seconds.
                                                              Max 900. 840 = 14 minutes.

  AccountNameOverrides   no        (empty)                    Comma-separated id=name pairs.
                                                              e.g. 123456789012=audit

  LambdaCodeBucket       YES       —                          S3 bucket holding Lambda
                                                              ZIP files. Set by deploy.ps1.

  AggregatorCodeKey      no        lambda-code/               S3 key for aggregator ZIP.
                                   aggregator_lambda.zip

  ApiCodeKey             no        lambda-code/               S3 key for API Lambda ZIP.
                                   api_lambda.zip

  ReportGeneratorCodeKey no        lambda-code/               S3 key for Report Generator ZIP.
                                   report_generator_lambda.zip

  InventoryCodeKey       no        lambda-code/               S3 key for Inventory Lambda ZIP.
                                   inventory_lambda.zip


================================================================================
11. STACK OUTPUTS REFERENCE
================================================================================

  Output Key               Description                         Use
  ----------               -----------                         ---
  DataBucketName           S3 data bucket name                 Confirm correct bucket
  UIBucketName             S3 UI hosting bucket name           S3 sync target
  UserPoolId               Cognito User Pool ID                VITE_COGNITO_USER_POOL_ID
  UserPoolClientId         Cognito App Client ID               VITE_COGNITO_CLIENT_ID
  CognitoHostedUIDomain    Cognito Hosted UI URL               VITE_COGNITO_DOMAIN
  ApiGatewayUrl            API Gateway invoke URL              VITE_API_BASE
  AggregatorFunctionArn    Aggregator Lambda ARN               Manual invocation / monitoring
  AggregatorRoleArn        Aggregator execution role ARN       StackSet AggregatorRoleArn param
  ReportGeneratorFunctionArn  Report Generator Lambda ARN      Monitoring / IAM reference
  InventoryFunctionArn     Inventory Lambda ARN                Monitoring / IAM reference
  CloudFrontDistributionId CloudFront distribution ID          Cache invalidation
  CloudFrontDomain         CloudFront domain name              DNS CNAME target
  SesIdentityArn           SES email identity ARN              IAM policy reference
  AggregatorDLQUrl         Dead Letter Queue URL               Monitoring / alarm config
  DashboardEnvVars         All 5 .env variables pre-formatted  Copy into .env file


================================================================================
12. POST-DEPLOY CHECKLIST
================================================================================

Run through this list after every first-time deployment:

  [ ] DNS CNAME created:
        <DashboardDomain>  ->  <CloudFrontDomain output>
        Propagation can take up to 48 hours depending on your DNS provider.
        Test with: nslookup security.yourdomain.com

  [ ] SES sender verified:
        SES console > Verified identities > <SesFromEmail>
        Status must show "Verified" before email digest will send.

  [ ] SES production access (if needed):
        SES console > Account dashboard > Request production access.
        While in sandbox, only verified addresses receive emails.

  [ ] First aggregator run completed:
        Lambda > securityhub-aggregator-prod > Monitor > Invocations > 0 errors.
        CloudWatch Logs: search for "Aggregator version: 1.5.9" to confirm.

  [ ] S3 data written:
        s3://securityhub-dashboard-data/summaries/accounts.json exists.
        s3://securityhub-dashboard-data/summaries/version.json exists.

  [ ] Dashboard accessible:
        https://<DashboardDomain> loads sign-in page.

  [ ] Admin user sign-in works:
        Check inbox of AdminEmail for temporary password from Cognito.
        Sign in and confirm data loads (accounts, scores, findings).

  [ ] Trusted Advisor tab loads:
        StackSet instances are in SUCCEEDED status.
        TrustedAdvisorReadOnlyRole exists in member accounts.

  [ ] Report download works:
        Click Download report (PDF, CSV, and Excel).
        File downloads without popup blocker issues.

  [ ] CloudWatch alarms in OK state:
        securityhub-aggregator-errors-prod     -> OK
        securityhub-aggregator-duration-prod   -> OK
        securityhub-aggregator-dlq-depth-prod  -> OK

  [ ] DLQ is empty:
        SQS > securityhub-aggregator-dlq-prod >
        Messages available = 0.


================================================================================
13. UPDATING THE STACK
================================================================================

LAMBDA CODE UPDATE (most common)
---------------------------------
Re-run deploy.ps1 — it detects the existing stack and runs cloudformation
deploy with --no-fail-on-empty-changeset, so it only updates what changed.
The Lambda update-function-code is handled by CFN when the S3 key content
changes (deploy.ps1 always re-uploads the ZIP).

  # Lambda + dashboard update
  .\deploy.ps1 [required params] -SkipStackSet

  # Lambda only (no dashboard rebuild)
  .\deploy.ps1 [required params] -SkipBuild -SkipStackSet

CFN TEMPLATE CHANGES
---------------------
Any changes to securityhub-dashboard-main.yaml are applied by re-running
deploy.ps1 or by running cloudformation deploy directly. CloudFormation
calculates the changeset and applies only the difference.

ADDING NEW COGNITO USERS
------------------------
  aws cognito-idp admin-create-user \
    --user-pool-id <UserPoolId output> \
    --username newuser@yourcompany.com \
    --user-attributes Name=email,Value=newuser@yourcompany.com \
    --desired-delivery-mediums EMAIL \
    --region eu-west-1

UPDATING LAMBDA ENVIRONMENT VARIABLES
--------------------------------------
Update the parameter-overrides in deploy.ps1 or use:

  aws lambda update-function-configuration \
    --function-name securityhub-aggregator-prod \
    --region eu-west-1 \
    --environment Variables="{BUCKET=...,SES_FROM_EMAIL=...,SES_TO_EMAIL=...}"

  NOTE: Updating env vars via CLI bypasses CloudFormation state. Prefer
  updating the CFN parameter and re-running deploy.ps1 to keep state in sync.


================================================================================
14. STACK TEARDOWN
================================================================================

WARNING: Deleting the stack does NOT delete the S3 buckets (DeletionPolicy:
Retain). This is intentional to prevent accidental data loss. You must empty
and delete the buckets manually if desired.

  # Delete the main stack
  aws cloudformation delete-stack \
    --stack-name securityhub-dashboard \
    --region eu-west-1

  # Monitor deletion
  aws cloudformation wait stack-delete-complete \
    --stack-name securityhub-dashboard \
    --region eu-west-1

  # Delete StackSet instances first (required before deleting the StackSet)
  aws cloudformation delete-stack-instances \
    --stack-set-name securityhub-dashboard-member-roles \
    --region eu-west-1 \
    --deployment-targets OrganizationalUnitIds=<ou-id> \
    --regions eu-west-1 \
    --no-retain-stacks

  # Then delete the StackSet
  aws cloudformation delete-stack-set \
    --stack-set-name securityhub-dashboard-member-roles \
    --region eu-west-1

  # Empty and delete S3 buckets (if desired)
  aws s3 rm s3://securityhub-dashboard-data --recursive --region eu-west-1
  aws s3api delete-bucket --bucket securityhub-dashboard-data --region eu-west-1

  aws s3 rm s3://securityhub-dashboard-ui --recursive --region eu-west-1
  aws s3api delete-bucket --bucket securityhub-dashboard-ui --region eu-west-1

  # Delete Lambda code staging bucket
  aws s3 rm s3://securityhub-lambda-code-<accountId> --recursive --region eu-west-1
  aws s3api delete-bucket --bucket securityhub-lambda-code-<accountId> --region eu-west-1


================================================================================
15. TROUBLESHOOTING
================================================================================

DEPLOYMENT ERRORS
-----------------

Problem: deploy.ps1 fails at Step 5 with "ROLLBACK_COMPLETE"
  Check:  AWS Console > CloudFormation > securityhub-dashboard > Events tab
  Common causes:
  - AcmCertificateArn is not in us-east-1 (CloudFront hard requirement)
  - CognitoDomainPrefix already taken globally — try a more unique prefix
  - DataBucketName or UIBucketName already exists in another account
  - LambdaCodeBucket does not exist or Lambda ZIPs are not uploaded yet
  Fix:    Delete the ROLLBACK_COMPLETE stack, correct the parameter,
          and re-run deploy.ps1.

Problem: "S3 bucket already exists" error during stack create
  Cause:  S3 bucket names are globally unique. The default names may be
          taken by another account.
  Fix:    Pass custom bucket names:
          -DataBucketName securityhub-data-<yourcompany>
          -UIBucketName   securityhub-ui-<yourcompany>

Problem: CloudFront distribution creation times out (>30 min)
  Cause:  Normal — CloudFront distributions can take up to 30 min.
  Fix:    Wait. deploy.ps1 waits for cloudformation deploy to complete,
          which waits for CloudFront. No action needed.

Problem: "Parameter 'AcmCertificateArn' failed to satisfy constraint"
  Cause:  Certificate ARN format is wrong or region is not us-east-1.
  Fix:    Certificate must be: arn:aws:acm:us-east-1:{accountId}:certificate/{uuid}
          Request the certificate in us-east-1, not eu-west-1.

RUNTIME ERRORS
--------------

Problem: Aggregator Lambda errors on first run
  Check:  CloudWatch Logs > /aws/lambda/securityhub-aggregator-prod
  Common causes:
  - "EnvironmentError: BUCKET not set" — env var missing in Lambda config
  - "AccessDenied on securityhub:GetFindings" — account is not delegated admin
  - "NoCredentialError on organizations:ListAccounts" — role missing permission
  - "SES send_email failed" — SES identity not verified yet
  All of these are logged clearly with the error cause.

Problem: StackSet instances stuck in RUNNING or FAILED
  Check:  CFN Console > StackSets > securityhub-dashboard-member-roles >
          Stack instances tab
  Common causes:
  - Trusted access for StackSets not enabled in Organizations
  - Service-managed StackSets permissions not configured in management account
  Fix:    See Section 8 — run enable-aws-service-access + activate-organizations-access
          from the management account.

Problem: Dashboard shows "Request timed out" for all routes
  Cause:  API Gateway URL in VITE_API_BASE is wrong, or CORS_ALLOW_ORIGIN
          on the API Lambda does not match the dashboard domain.
  Check:  Browser DevTools > Network > check request URL and CORS headers.
  Fix:    Verify VITE_API_BASE matches ApiGatewayUrl stack output exactly.
          Verify CORS_ALLOW_ORIGIN Lambda env var matches DashboardDomain.

Problem: Sign-in redirects to Cognito but comes back with an error
  Cause:  Callback URL mismatch — Cognito app client callback URL must
          exactly match VITE_REDIRECT_URI including protocol and path.
  Fix:    Check Cognito app client > Allowed callback URLs.
          Must be: https://<DashboardDomain>/callback

Problem: DLQ has messages after aggregator run
  Cause:  Lambda invocation failed and was not retried successfully.
  Check:  CloudWatch Logs for the failed run.
          SQS > securityhub-aggregator-dlq-prod > Send and receive messages
          > Receive messages — inspect the message body for error details.
  Fix:    Address the root cause from logs, then purge the DLQ and trigger
          the Lambda manually to confirm it runs cleanly.


================================================================================
END OF DOCUMENT
================================================================================
