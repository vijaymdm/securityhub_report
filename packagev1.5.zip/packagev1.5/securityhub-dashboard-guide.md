# AWS Security Hub Compliance Dashboard — Implementation Guide

**Version:** v1.5.9 / API v1.5.2 / Report Generator v1.0.1 / Inventory v1.0.0 / Dashboard v1.5.5  
**Author:** Vijay, AWS Infrastructure & Security  
**Domain:** security.customersite.co.uk (CloudFront + S3, Live)  
**Region:** eu-west-1 (Lambda, API Gateway, S3, EventBridge) · us-east-1 (ACM, SES)  
**Last Updated:** September 2026 — updated for Inventory tab (on-demand service/resource breakdown)

---

## 1. Overview

Three main components work together:

1. **Aggregator Lambda** (`aggregator_lambda.py`) — runs on a daily EventBridge schedule, pulls Security Hub findings, AWS Inspector v2 findings, and Trusted Advisor checks from all member accounts, generates PDF / CSV / Excel reports, writes JSON summaries to S3, and sends an SES email digest of new Critical/High findings.

2. **API Lambda + API Gateway** (`api_lambda.py`) — read-only HTTP API that serves pre-computed JSON summaries and generates presigned S3 URLs for report downloads.

3. **React Dashboard + CloudFront** (`securityhub-dashboard.jsx`) — static SPA hosted on S3, distributed via CloudFront with a custom domain, Cognito authentication, and OAC (Origin Access Control). Four tabs: Security Hub · Trusted Advisor · Inspector · Inventory.

**Data flow:**

```
EventBridge (daily 02:00 UTC)
  → Aggregator Lambda
    → S3 (summaries/, reports/, snapshots/, trusted-advisor/, inspector/)
    → SES (new Critical/High digest email)
      → API Lambda (reads S3, generates presigned URLs)
        → API Gateway (HTTP API)
          → CloudFront + Cognito
            → React Dashboard (browser)
```

**AWS services used:** Security Hub, Inspector v2, Lambda (Python 3.12), S3 (2 buckets), API Gateway (HTTP API), CloudFront (OAC + Cognito), EventBridge, AWS Organizations, Trusted Advisor (Business/Enterprise Support required), SES, Cognito User Pool, ACM, SQS (DLQ).

**Estimated cost:** Under $2–3/month at 70+ accounts.

---

## 2. Prerequisites

### AWS
- Security Hub delegated administrator account
- AWS Organizations with 70+ member accounts
- Business or Enterprise Support plan (required for Trusted Advisor API)
- AWS Inspector v2 enabled and Security Hub integration active in each member account (required for Inspector tab)
- A verified domain name with DNS control
- SES sending identity verified in us-east-1 (for email digest)
- ACM certificate covering the dashboard domain, **issued in us-east-1** (CloudFront requirement)

### Local
- Node.js v20.19+ or v22.12+ (LTS)
- npm v10+
- AWS CLI configured with delegated admin credentials
- VS Code or similar editor

---

## 3. Deployment Options

### Option A — CloudFormation (Recommended)

The `cfn/` directory contains a complete CloudFormation template that provisions all resources in one stack:

```powershell
cd cfn
.\deploy.ps1
```

Parameters set by the template:

| Parameter | Default | Description |
|---|---|---|
| `StackEnv` | `prod` | Environment tag appended to resource names |
| `DataBucketName` | `securityhub-dashboard-data` | S3 data bucket (globally unique) |
| `UIBucketName` | `securityhub-dashboard-site` | S3 site bucket (globally unique) |
| `SesFromEmail` | *(required)* | Verified SES sender address |
| `SesToEmail` | *(required)* | Distribution list for Critical/High alerts |
| `DashboardDomain` | *(required)* | Custom domain (e.g. security.yourdomain.com) |
| `AcmCertificateArn` | *(required)* | ACM cert ARN — must be in us-east-1 |
| `CognitoDomainPrefix` | *(required)* | Unique prefix for Cognito hosted UI |
| `AdminEmail` | *(required)* | First Cognito admin user — receives temp password |
| `AggregatorMemory` | `1024` | Lambda memory in MB |
| `AggregatorTimeout` | `840` | Lambda timeout in seconds (max 900) |
| `AggregatorSchedule` | `cron(0 2 * * ? *)` | EventBridge schedule (02:00 UTC daily) |
| `LambdaCodeBucket` | *(required)* | S3 bucket holding the Lambda ZIP files |

After stack creation, create a CNAME DNS record pointing `DashboardDomain` → CloudFront distribution domain.

### Option B — Manual Setup

Follow Sections 4–9 below for manual step-by-step deployment.

---

## 4. S3 Bucket Setup (Manual)

Create two S3 buckets in **eu-west-1**:

### Data bucket — `securityhub-dashboard-data`
- Block all public access: **ON**
- Versioning: Enabled
- Encryption: SSE-S3 (AES256)
- No static website hosting

Stores the following paths written by the Aggregator Lambda:

```
summaries/accounts.json
summaries/{account_id}/latest.json
summaries/{account_id}/findings.json
summaries/all/latest.json
summaries/all/findings.json
summaries/version.json
snapshots/{YYYY-MM-DD}/findings.json        ← daily snapshot for delta tracking
trusted-advisor/{account_id}/latest.json
trusted-advisor/all/latest.json
inspector/{account_id}/latest.json          ← per-account Inspector v2 summary
inspector/all/latest.json                   ← all-accounts Inspector v2 summary
reports/{account_id}/latest.pdf
reports/{account_id}/latest.csv
reports/{account_id}/latest.xlsx            ← 3-tab Excel per account
reports/all/latest.pdf
reports/all/latest.csv
reports/all/latest.xlsx                     ← combined 3-tab Excel
```

### Site bucket — `securityhub-dashboard-site`
- Block all public access: **ON**
- **Do NOT** enable static website hosting — use CloudFront OAC with the S3 REST endpoint

---

## 5. IAM Permissions (Manual)

### Aggregator Lambda execution role

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SecurityHub",
      "Effect": "Allow",
      "Action": "securityhub:GetFindings",
      "Resource": "*"
    },
    {
      "Sid": "Organizations",
      "Effect": "Allow",
      "Action": "organizations:ListAccounts",
      "Resource": "*"
    },
    {
      "Sid": "S3DataBucket",
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject"],
      "Resource": "arn:aws:s3:::securityhub-dashboard-data/*"
    },
    {
      "Sid": "TrustedAdvisor",
      "Effect": "Allow",
      "Action": [
        "support:DescribeTrustedAdvisorChecks",
        "support:DescribeTrustedAdvisorCheckResult"
      ],
      "Resource": "*"
    },
    {
      "Sid": "STSAssumeRole",
      "Effect": "Allow",
      "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/TrustedAdvisorReadOnlyRole"
    },
    {
      "Sid": "SES",
      "Effect": "Allow",
      "Action": "ses:SendEmail",
      "Resource": "*"
    },
    {
      "Sid": "Inspector2Status",
      "Effect": "Allow",
      "Action": "inspector2:BatchGetAccountStatus",
      "Resource": "*"
    }
  ]
}
```

> **Inspector v2 note:** No additional IAM permission is required for Inspector findings. The aggregator uses `securityhub:GetFindings` with a `ProductArn CONTAINS arn:aws:inspector` filter — Inspector findings flow through Security Hub when the Inspector → Security Hub integration is active.

**Lambda configuration:**
- Runtime: Python 3.12, x86_64
- Memory: **1024 MB** minimum — increase if Max Memory Used exceeds ~90% in CloudWatch
- Timeout: **840 seconds** (14 minutes)
- Dead Letter Queue: attach an SQS queue to catch failed invocations

### API Lambda execution role

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:HeadObject"],
      "Resource": [
        "arn:aws:s3:::securityhub-dashboard-data/summaries/*",
        "arn:aws:s3:::securityhub-dashboard-data/trusted-advisor/*",
        "arn:aws:s3:::securityhub-dashboard-data/inspector/*",
        "arn:aws:s3:::securityhub-dashboard-data/reports/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::securityhub-dashboard-data"
    }
  ]
}
```

> **Important changes from previous versions:**
> - `s3:HeadObject` is now required alongside `s3:GetObject` — the `/report-url` route checks the report key exists before generating a presigned URL, preventing raw S3 XML errors in the browser.
> - `inspector/*` prefix added to the `s3:GetObject` / `s3:HeadObject` resource list for the new `/inspector` route.
> - `s3:GetObject` uses `/prefix/*` ARN; `s3:ListBucket` uses the plain bucket ARN (no trailing `/*`). Mixing these up causes AccessDenied.

### Trusted Advisor cross-account role (in every member account)

Create a role named `TrustedAdvisorReadOnlyRole` in every member account:

**Permissions policy:**
```json
{
  "Effect": "Allow",
  "Action": [
    "support:DescribeTrustedAdvisorChecks",
    "support:DescribeTrustedAdvisorCheckResult"
  ],
  "Resource": "*"
}
```

**Trust policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {
      "AWS": "arn:aws:iam::{DELEGATED_ADMIN_ACCOUNT_ID}:role/{AGGREGATOR_LAMBDA_ROLE_NAME}"
    },
    "Action": "sts:AssumeRole",
    "Condition": {
      "StringEquals": {
        "sts:ExternalId": "{MEMBER_ACCOUNT_ID}-ta-reader"
      }
    }
  }]
}
```

Use CloudFormation StackSets to deploy this role across all 70+ accounts in one operation. The CFN template `cfn/securityhub-member-role.yaml` does this automatically.

---

## 6. Aggregator Lambda Setup (Manual)

The Lambda must be deployed as a **ZIP file** because it uses `fpdf2` and `openpyxl`, which are not part of the default Lambda Python runtime.

### Step 1 — Build the deployment package

The aggregator no longer requires `fpdf2` or `openpyxl` — report generation was moved to `report_generator_lambda`. The aggregator ZIP only needs `boto3`, which is already provided by the Lambda runtime.

```bash
mkdir aggregator_package
cd aggregator_package

# No extra pip installs needed — boto3 is provided by the Lambda runtime
cp /path/to/aggregator_lambda.py .

# Package
zip -r ../aggregator_lambda.zip .
```

> **Note:** If `openpyxl` is not installed, Excel report generation is gracefully disabled with a warning log — PDF and CSV still work. The dashboard will show a friendly error message if an Excel download is attempted.

### Step 2 — Create or update the Lambda function

```bash
# Create (first time)
aws lambda create-function \
  --function-name securityhub-aggregator \
  --runtime python3.12 \
  --role arn:aws:iam::{ACCOUNT_ID}:role/{AGGREGATOR_ROLE_NAME} \
  --handler aggregator_lambda.lambda_handler \
  --zip-file fileb://aggregator_lambda.zip \
  --timeout 840 \
  --memory-size 1024 \
  --region eu-west-1

# Update (subsequent deploys)
aws lambda update-function-code \
  --function-name securityhub-aggregator \
  --zip-file fileb://aggregator_lambda.zip \
  --region eu-west-1
```

### Step 3 — Set environment variables

Set these in **Lambda → Configuration → Environment variables**:

| Variable | Required | Description |
|---|---|---|
| `BUCKET` | ✅ | S3 data bucket name (e.g. `securityhub-dashboard-data`) |
| `SES_FROM_EMAIL` | ✅ | Verified SES sender address |
| `SES_TO_EMAIL` | ✅ | Distribution list for Critical/High alerts |
| `ACCOUNT_NAME_OVERRIDES` | optional | Comma-separated `accountId=name` pairs, e.g. `143301474150=audit,824623333855=prod` |

> The Lambda raises a clear `EnvironmentError` at cold-start if any required variable is missing — no silent misconfiguration.

### Step 4 — Verify SES sender

Before the email digest will send:
1. Open SES console in **us-east-1**
2. Verified identities → verify the `SES_FROM_EMAIL` domain or address
3. If SES is still in sandbox mode, also verify `SES_TO_EMAIL`

### Step 5 — Enable Inspector → Security Hub integration

For the Inspector tab to show data, Inspector v2 must forward findings to Security Hub in each member account:

1. Open **AWS Inspector** console in each member account (or use the delegated admin account)
2. Go to **Settings → Integrations → AWS Security Hub**
3. Confirm Status is **Active**

Inspector findings are identified by `ProductArn` starting with `arn:aws:inspector` and are collected separately from Security Hub native control findings. They do not affect the Security Hub compliance score or reports.

### Step 6 — Create EventBridge schedule

Create a rule with schedule `cron(0 2 * * ? *)` (02:00 UTC daily) targeting the aggregator Lambda.

Adjust the cron expression for your preferred time — the CFN parameter `AggregatorSchedule` controls this.

### Step 7 — First run and verification

1. Go to Lambda → Test, use an empty `{}` event
2. Check CloudWatch Logs for timing entries and completion:
   - `TIMING phase=fetch_all_findings duration_s=XX.XX`
   - `TIMING phase=generate_and_upload_reports duration_s=XX.XX`
   - `TIMING lambda_handler_total duration_s=XX.XX`
   - `Security Hub: wrote summaries/reports for X accounts`
   - `Inspector: wrote data for X accounts (Y findings)` — or `no active findings` if Inspector is not enabled
3. Verify S3: `summaries/accounts.json` must exist before proceeding to the API Lambda setup

> **Do not proceed to the API Lambda** until `summaries/accounts.json` exists in S3.

### Performance tuning

These constants control parallelism and timeout behaviour. All are defined in `aggregator_lambda.py`:

| Constant | Default | Description | When to change |
|---|---|---|---|
| `REPORT_MAX_WORKERS` | `10` | Parallel accounts for PDF+CSV+XLSX generation | Lower if Lambda Max Memory Used exceeds ~90% |
| `S3_WRITE_MAX_WORKERS` | `20` | Parallel S3 puts in `write_to_s3()` | Lower if S3 rate errors appear in logs |
| `TA_MAX_WORKERS` | `10` | Parallel Trusted Advisor account fetches | Lower if Support API throttling appears |
| `REPORT_TIME_GUARD_MS` | `120_000` | Skip reports if less than this many ms remain | Increase if reports are frequently skipped near timeout |

#### Using CloudWatch Logs Insights to diagnose timing

Run this query on the aggregator Lambda's log group to see where time is being spent:

```
filter @message like /TIMING/
| parse @message "TIMING phase=* duration_s=*" as phase, duration_s
| stats avg(duration_s), max(duration_s) by phase
| sort max(duration_s) desc
```

Per-account report timing is also logged individually:

```
filter @message like /TIMING report/
| parse @message "TIMING report account=* findings=* pdf_s=* pdf_s3_s=* csv_s=* csv_s3_s=* xlsx_s=* total_s=*" as account, findings, pdf_s, pdf_s3_s, csv_s, csv_s3_s, xlsx_s, total_s
| stats avg(float(total_s)), max(float(xlsx_s)) by account
| sort max(float(xlsx_s)) desc
```

If the log shows `TIMING skipping report generation — only N ms remaining`, the Lambda timed out before writing reports. Increase `AggregatorTimeout` in the CFN parameter or Lambda configuration.

---

## 7. API Lambda + API Gateway Setup (Manual)

### API Lambda

Create a Lambda function named `securityhub-api`:
- Runtime: Python 3.12
- Paste `api_lambda.py` directly in the console editor — **no ZIP needed**
- Timeout: 30 seconds
- Memory: 256 MB

**Environment variables:**

| Variable | Required | Description |
|---|---|---|
| `BUCKET` | ✅ | S3 data bucket name |
| `CORS_ALLOW_ORIGIN` | ✅ | Exact CloudFront domain, e.g. `https://security.yourdomain.com` |
| `REPORT_GENERATOR_FUNCTION_NAME` | ✅ | Name or ARN of the report_generator_lambda |
| `INVENTORY_FUNCTION_NAME` | ✅ | Name or ARN of the inventory_lambda |

> Both variable names are case-sensitive. `CORS_ALLOW_ORIGIN` (not `Access-Control-Allow-Origin`) is the environment variable name.

### API Gateway (HTTP API)

1. Create an HTTP API with Lambda proxy integration pointing to `securityhub-api`
2. Add these routes:

| Method | Route | Description |
|---|---|---|
| GET | `/accounts` | Account list for the dropdown |
| GET | `/summary` | Per-account or all-accounts compliance summary |
| GET | `/findings` | Condensed findings list with optional severity filter |
| GET | `/trusted-advisor` | Trusted Advisor checks with optional status filter |
| GET | `/inspector` | Inspector v2 findings with optional severity filter |
| POST | `/generate-inventory` | Trigger on-demand inventory build |
| GET | `/inventory-status` | Poll inventory generation status |
| GET | `/inventory` | Retrieve generated inventory (services + resources) |
| GET | `/report-url` | Presigned S3 URL for PDF / CSV / Excel download |
| GET | `/version` | API and aggregator version info |

3. CORS configuration: set allowed origin to your CloudFront domain (use `*` temporarily during testing only)
4. Deploy to `$default` stage — note the Invoke URL

**Smoke test** (paste in browser):
- `{InvokeURL}/accounts` — returns JSON array of accounts
- `{InvokeURL}/summary?account=all` — returns aggregated summary
- `{InvokeURL}/inspector?account=all` — returns Inspector summary (or 404 if not yet run)
- `{InvokeURL}/version` — returns `{ "apiVersion": "1.5.2", "aggregatorVersion": "1.5.9", ... }`

`{"message":"Not Found"}` means the route is missing or not deployed to the `$default` stage.

---

## 8. Frontend Build and Deploy

### Step 1 — Scaffold the project

```bash
npm create vite@latest securityhub-dashboard -- --template react
cd securityhub-dashboard
npm install
npm install lucide-react
npm install -D tailwindcss@3 postcss autoprefixer   # must be v3, NOT v4
npx tailwindcss init -p
```

> **Tailwind v4 warning:** If you accidentally install Tailwind v4, all styles will be missing. Always specify `tailwindcss@3` explicitly.

### Step 2 — Configure Tailwind

Edit `tailwind.config.js`:
```js
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: { extend: {} },
  plugins: [],
}
```

Replace `src/index.css` with:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Step 3 — Copy source files

Copy `securityhub-dashboard.jsx` into `src/` and ensure `src/main.jsx` imports it.

### Step 4 — Set the API base URL

Create a `.env` file in the project root:
```
VITE_API_BASE=https://{your-api-id}.execute-api.eu-west-1.amazonaws.com
```

> The dashboard reads `import.meta.env.VITE_API_BASE` at build time. Do not hardcode the API Gateway URL in the source file.

### Step 5 — Test locally

```bash
npm run dev
```

Open the local dev URL, confirm accounts load and the score dial appears. Switch to the Inspector tab — it will show an error if Inspector is not yet enabled, which is expected.

### Step 6 — Build and upload to S3

```bash
npm run build
```

Upload the **contents of `dist/`** (not the `dist/` folder itself) to the UI S3 bucket:

```bash
aws s3 sync dist/ s3://securityhub-dashboard-site/ --delete --region eu-west-1
```

> **Critical:** `index.html` must be at the bucket root (`s3://bucket/index.html`), not inside a `dist/` prefix. If it ends up at `s3://bucket/dist/index.html`, CloudFront returns AccessDenied.

---

## 9. CloudFront Distribution Setup (Manual)

### Create the distribution

1. Origin domain: select the `securityhub-dashboard-site` bucket from the dropdown — **not** the website endpoint
2. Origin access: **Origin Access Control (OAC)** — create a new OAC if prompted
3. Viewer protocol policy: Redirect HTTP to HTTPS
4. Default root object: `index.html`
5. Alternate domain (CNAME): your dashboard domain (e.g. `security.yourdomain.com`)
6. Custom SSL certificate: select the ACM certificate — **must be in us-east-1**

### Apply the bucket policy

After the distribution is created, CloudFront shows a banner with a generated bucket policy. Copy it and paste it into the site bucket's **Bucket policy** (S3 → Permissions → Bucket policy).

### Add custom error pages

Add two custom error responses:
- Error code 403 → Response path `/index.html` → HTTP 200
- Error code 404 → Response path `/index.html` → HTTP 200

### DNS

Create a CNAME record in your DNS provider:
```
security.yourdomain.com  →  {distribution-id}.cloudfront.net
```

### Invalidate cache after every redeployment

```bash
aws cloudfront create-invalidation \
  --distribution-id {DISTRIBUTION_ID} \
  --paths "/*"
```

---

## 10. Tighten CORS After Deployment

Once the CloudFront domain is confirmed working:

1. Update `CORS_ALLOW_ORIGIN` environment variable in the API Lambda to the exact CloudFront domain: `https://security.yourdomain.com`
2. Update the API Gateway CORS settings to the same specific origin (remove `*`)
3. Deploy the API Gateway changes

---

## 11. Version Reference

| Component | Version | File |
|---|---|---|
| Aggregator Lambda | **1.5.9** | `aggregator_lambda.py` |
| API Lambda | **1.5.2** | `api_lambda.py` |
| Report Generator Lambda | **1.0.1** | `report_generator_lambda.py` |
| Inventory Lambda | **1.0.0** | `inventory_lambda.py` |
| Dashboard | **1.5.5** | `securityhub-dashboard.jsx` |

The dashboard footer shows live version info once the aggregator has run at least once:

```
dashboard v1.5.5 · api v1.5.2 · aggregator v1.5.9 · last run 2026-09-10 02:14 UTC
```

If the footer shows only the dashboard version (no api/aggregator), trigger the aggregator manually and wait for `summaries/version.json` to be written to S3.

---

## 12. Troubleshooting

### 1. "Could not load account list" in the dashboard
- **CORS error** — `VITE_API_BASE` is pointing to the wrong URL; check browser DevTools → Network for the actual CORS header
- **`{"message":"Not Found"}`** — route missing in API Gateway or not deployed to `$default` stage

### 2. S3 AccessDenied on CloudFront
- `index.html` uploaded inside a `dist/` folder prefix instead of at the bucket root
- Bucket policy references generic `cloudfront.amazonaws.com` without the distribution ARN — use the policy CloudFront generates
- Wrong origin domain — must use the S3 REST endpoint, not the S3 website endpoint

### 3. "No summary available" for an account
- Aggregator hasn't run, or ran before this account had findings
- Check S3 for `summaries/{account_id}/latest.json`
- Accounts with zero findings are included since v1.3.0

### 4. Report download shows friendly error instead of file
- Since v1.4.2 the API checks the report key exists before presigning — the error message in the dashboard tells you the exact cause
- If message mentions **timeout**: check CloudWatch Logs for `TIMING skipping report generation` — increase `AggregatorTimeout` or `REPORT_TIME_GUARD_MS`
- If message mentions **openpyxl** (Excel only): add `pip install openpyxl -t .` to the Lambda ZIP and redeploy
- If message mentions **aggregator has not run**: trigger the Lambda manually and wait for completion

### 5. Excel download previously showed raw S3 XML (`NoSuchKey`)
- This was fixed in API v1.4.2. Update `api_lambda.py` and ensure the API Lambda role includes `s3:HeadObject` on the `reports/*` prefix.

### 6. Inspector tab shows error / no data
- Confirm AWS Inspector v2 is enabled in each member account
- Confirm the Inspector → Security Hub integration is **Active** (Inspector console → Settings → Integrations → AWS Security Hub)
- If integration was just enabled, trigger the aggregator manually — Inspector data only appears after the first run following enablement
- `SubscriptionRequiredException` in logs: the account lacks Business/Enterprise Support — Inspector checks for that account are skipped, all other data still works

### 7. `SubscriptionRequiredException` for Trusted Advisor
- Account lacks Business or Enterprise Support plan
- Error is caught per-account and logged as a warning — Security Hub data and all other functionality still works

### 8. Lambda `EnvironmentError` at cold-start
- A required environment variable is missing: `BUCKET`, `SES_FROM_EMAIL`, or `SES_TO_EMAIL`
- Set all three in Lambda → Configuration → Environment variables before invoking

### 9. Lambda timeout / reports skipped
- Check CloudWatch Logs Insights (see Section 6 — Performance tuning) to identify the slow phase
- `TIMING skipping report generation — only N ms remaining` means the time guard fired: summaries were written but reports were not
- Common causes: large finding volume causing slow paginator or slow Excel generation
- Fix options: increase `AggregatorTimeout` toward 900 s; lower `REPORT_MAX_WORKERS` to reduce memory pressure; check per-account `xlsx_s` timing to identify accounts with huge finding sets

### 10. SES digest not sending
- Verify `SES_FROM_EMAIL` in SES console (us-east-1) → Verified identities
- If SES sandbox mode is active, also verify `SES_TO_EMAIL`
- Digest is only sent when there are new Critical/High findings — no email on clean runs is expected behaviour

### 11. Excel reports not generated at all
- `openpyxl` is not in the Lambda ZIP
- Add it: `pip install openpyxl -t .` inside the package directory, rezip and redeploy
- Check Lambda logs for `openpyxl not installed — Excel reports disabled`

### 12. Lambda Hash Mismatch
- Caused by mixing console inline edits with ZIP deployments
- Always use ZIP for the aggregator Lambda (it has binary dependencies)
- If stuck, delete and recreate the Lambda function

### 13. Tailwind styles missing
- Almost always `tailwindcss@4` was installed accidentally
- Fix: `npm uninstall tailwindcss && npm install -D tailwindcss@3 postcss autoprefixer && npx tailwindcss init -p`

---

## 13. Maintenance and Updates

### Redeploy Aggregator Lambda
```bash
cd aggregator_package
cp /path/to/aggregator_lambda.py .
cd ..
zip -r aggregator_lambda.zip aggregator_package/

aws lambda update-function-code \
  --function-name securityhub-aggregator \
  --zip-file fileb://aggregator_lambda.zip \
  --region eu-west-1
```

Trigger manually to verify. Check CloudWatch Logs for `TIMING lambda_handler_total` to confirm the run completed within the timeout.

### Redeploy API Lambda
Paste updated `api_lambda.py` directly in the Lambda console → Deploy. No ZIP needed.

### Redeploy Frontend
```bash
npm run build
aws s3 sync dist/ s3://securityhub-dashboard-site/ --delete --region eu-west-1
aws cloudfront create-invalidation --distribution-id {ID} --paths "/*"
```

### Add new accounts
New accounts added to AWS Organizations are picked up automatically on the next aggregator run — no code changes needed. Add friendly names via the `ACCOUNT_NAME_OVERRIDES` environment variable if desired.

### Enable Inspector for additional accounts
1. Enable Inspector v2 in the account
2. Activate the Inspector → Security Hub integration
3. Trigger the aggregator manually — Inspector data appears on the next successful run

### Change the schedule
EventBridge → Rules → edit the aggregator rule → change the cron or rate expression.

---

*Prepared by: Vijay | AWS Infrastructure & Security | Version 1.5.9 + Inventory v1.0.0 | September 2026*
