# backup_before_edit.ps1
# Called by the PreToolUse Kiro hook before fs_write or str_replace touches
# one of the three versioned source files.
#
# Reads JSON from stdin: { "tool": "...", "parameters": { "path": "..." } }
# Extracts the current version from the file ON DISK (before the edit lands),
# then copies it to backups/<name>_v<version>.<ext>.
#
# Version constants detected:
#   aggregator_lambda.py      -> AGGREGATOR_VERSION = '1.5.6'
#   api_lambda.py             -> API_VERSION = '1.4.2'
#   securityhub-dashboard.jsx -> const DASHBOARD_VERSION = '1.5.2';
#   report_generator_lambda.py -> REPORT_GENERATOR_VERSION = '1.0.0'

param()

$WORKSPACE  = "c:\Users\SYSTCSD32\Documents\platform\security-hub-dashboard-package\packagev1.5"
$BACKUP_DIR = Join-Path $WORKSPACE "backups"

if (-not (Test-Path $BACKUP_DIR)) {
    New-Item -ItemType Directory -Path $BACKUP_DIR -Force | Out-Null
}

# Read JSON from stdin
$inputJson = $input | Out-String
$filePath  = $null

try {
    $data     = $inputJson | ConvertFrom-Json
    # Try parameters.path first (fs_write), then parameters.targetFile (delete)
    $filePath = $data.parameters.path
    if (-not $filePath) { $filePath = $data.parameters.targetFile }
} catch {
    # Fallback: raw path string
    $filePath = $inputJson.Trim().Trim('"')
}

if (-not $filePath -or -not (Test-Path $filePath)) {
    exit 0   # File doesn't exist yet (new file creation) — nothing to back up
}

$baseName  = [System.IO.Path]::GetFileName($filePath)
$fileName  = [System.IO.Path]::GetFileNameWithoutExtension($filePath)
$extension = [System.IO.Path]::GetExtension($filePath)

# Only act on the four target files
$targets = @(
    "aggregator_lambda.py",
    "api_lambda.py",
    "securityhub-dashboard.jsx",
    "report_generator_lambda.py"
)
if ($baseName -notin $targets) {
    exit 0
}

$content = Get-Content $filePath -Raw -ErrorAction SilentlyContinue
if (-not $content) {
    exit 0
}

# Extract version based on file
$version = $null
switch ($baseName) {
    "aggregator_lambda.py" {
        if ($content -match "AGGREGATOR_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
    "api_lambda.py" {
        if ($content -match "API_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
    "securityhub-dashboard.jsx" {
        if ($content -match "DASHBOARD_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
    "report_generator_lambda.py" {
        if ($content -match "REPORT_GENERATOR_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
}

if (-not $version) {
    Write-Host "backup_before_edit: could not extract version from $baseName — skipping backup"
    exit 0
}

$destName = "${fileName}_v${version}${extension}"
$destPath = Join-Path $BACKUP_DIR $destName

# Skip if backup already exists with identical content
if (Test-Path $destPath) {
    $existing = Get-Content $destPath -Raw -ErrorAction SilentlyContinue
    if ($existing -eq $content) {
        Write-Host "backup_before_edit: $destName already up-to-date — no backup needed"
        exit 0
    }
}

Copy-Item $filePath $destPath -Force
Write-Host "backup_before_edit: backed up $baseName -> backups/$destName (pre-edit snapshot)"
