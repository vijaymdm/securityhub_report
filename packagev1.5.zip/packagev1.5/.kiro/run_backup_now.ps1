$base   = "c:\Users\SYSTCSD32\Documents\platform\security-hub-dashboard-package\packagev1.5"
$backup = "$base\backups"

$targets = @(
    @{ name = "api_lambda.py";              pattern = "API_VERSION\s*=\s*'([^']+)'" },
    @{ name = "report_generator_lambda.py"; pattern = "REPORT_GENERATOR_VERSION\s*=\s*'([^']+)'" },
    @{ name = "securityhub-dashboard.jsx";  pattern = "DASHBOARD_VERSION\s*=\s*'([^']+)'" }
)

foreach ($t in $targets) {
    $src = Join-Path $base $t.name
    if (-not (Test-Path $src)) { Write-Output "SKIP (not found): $($t.name)"; continue }
    $content = Get-Content $src -Raw
    if ($content -match $t.pattern) {
        $ver  = $Matches[1]
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($t.name)
        $ext  = [System.IO.Path]::GetExtension($t.name)
        $dest = "$backup\${stem}_v${ver}${ext}"
        if ((Test-Path $dest) -and ((Get-Content $dest -Raw) -eq $content)) {
            Write-Output "UP-TO-DATE: ${stem}_v${ver}${ext}"
        } else {
            Copy-Item $src $dest -Force
            Write-Output "BACKED UP:  ${stem}_v${ver}${ext}"
        }
    } else {
        Write-Output "NO VERSION: $($t.name)"
    }
}
