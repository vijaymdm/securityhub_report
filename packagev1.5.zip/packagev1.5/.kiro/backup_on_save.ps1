# backup_on_save.ps1
# Called by the PostFileSave Kiro hook.
# Reads the saved file path from stdin (JSON: {"file": "..."}),
# extracts the version string from the file content, and copies
# the file to backups/<basename>_v<version>.<ext>
#
# Supported version patterns:
#   aggregator_lambda.py  -> AGGREGATOR_VERSION = '1.5.4'
#   api_lambda.py         -> API_VERSION = '1.4.2'
#   securityhub-dashboard.jsx -> const DASHBOARD_VERSION = '1.5.1';

param()

$BACKUP_DIR = Join-Path $PSScriptRoot "backups"
if (-not (Test-Path $BACKUP_DIR)) {
    New-Item -ItemType Directory -Path $BACKUP_DIR -Force | Out-Null
}

# Read JSON from stdin
$inputJson = $input | Out-String
try {
    $data = $inputJson | ConvertFrom-Json
    $filePath = $data.file
} catch {
    # Fallback: try reading raw path
    $filePath = $inputJson.Trim()
}

if (-not $filePath -or -not (Test-Path $filePath)) {
    exit 0
}

$fileName  = [System.IO.Path]::GetFileNameWithoutExtension($filePath)
$extension = [System.IO.Path]::GetExtension($filePath)
$baseName  = "$fileName$extension"

# Only act on the three target files
$targets = @("aggregator_lambda.py", "api_lambda.py", "securityhub-dashboard.jsx")
if ($baseName -notin $targets) {
    exit 0
}

$content = Get-Content $filePath -Raw

# Extract version based on file
$version = $null
switch ($baseName) {
    "aggregator_lambda.py" {
        if ($content -match "AGGREGATOR_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
    "api_lambda.py" {
        if ($content -match "API_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
    "securityhub-dashboard.jsx" {
        if ($content -match "DASHBOARD_VERSION\s*=\s*['""]([^'""]+)['""]") {
            $version = $Matches[1]
        }
    }
}

if (-not $version) {
    Write-Host "backup_on_save: could not extract version from $baseName — skipping backup"
    exit 0
}

# Destination: backups/aggregator_lambda_v1.5.4.py
$destName = "${fileName}_v${version}${extension}"
$destPath = Join-Path $BACKUP_DIR $destName

# Only write if the backup doesn't already exist OR the content differs
if (Test-Path $destPath) {
    $existing = Get-Content $destPath -Raw
    if ($existing -eq $content) {
        Write-Host "backup_on_save: $destName already up-to-date — no backup needed"
        exit 0
    }
    # Content changed for the same version — overwrite
}

Copy-Item $filePath $destPath -Force
Write-Host "backup_on_save: backed up $baseName -> backups/$destName"
