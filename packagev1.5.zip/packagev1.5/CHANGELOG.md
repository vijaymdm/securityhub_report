# AWS Security Hub Compliance Dashboard — Changelog

---

## v1.0.0 (Inventory Lambda) / v1.5.2 (API) / v1.5.5 (Dashboard) — Account Inventory Tab
*September 2026 · inventory_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

A new **Inventory** tab shows a breakdown of every AWS service type and resource that has open Security Hub findings — account-aware, searchable, and filterable. The inventory is built on-demand by a new standalone Lambda (same pattern as `report_generator_lambda`) so it never adds time to the aggregator run.

---

### inventory_lambda.py — v1.0.0 (new file)

Standalone Lambda that builds inventory from condensed findings already written to S3 by the aggregator. No Security Hub API calls — purely S3 read + write.

**S3 paths read:**
- `summaries/accounts.json` — account list
- `summaries/{account_id}/findings.json` — condensed findings per account

**S3 paths written:**
- `inventory/{account_id}/latest.json` — per-account inventory
- `inventory/all/latest.json` — org-wide rollup
- `inventory/{account}/status.json` — `{ status: pending|done|failed, requestId, generatedAt, error }`

**Inventory data shape per account:**
```json
{
  "accountId": "123456789012",
  "accountName": "production",
  "lastGenerated": "2026-09-10 02:14 UTC",
  "totalFindings": 84,
  "totalResources": 42,
  "services": [
    { "resourceType": "AwsEc2Instance", "displayName": "EC2 — Instances",
      "resourceCount": 12, "findingCount": 22,
      "critical": 3, "high": 8, "medium": 7, "low": 4,
      "regions": ["eu-west-1"] }
  ],
  "resources": [
    { "resourceId": "arn:aws:ec2:...", "resourceType": "AwsEc2Instance",
      "region": "eu-west-1", "findingCount": 3, "worstSeverity": "HIGH" }
  ]
}
```

**Org-wide rollup** (`inventory/all/latest.json`) additionally includes: `accountsIncluded`, `accountId` and `accountName` on each resource row.

**Service display names** — 70+ AWS resource types mapped to human-readable names (e.g. `AwsS3Bucket` → `S3 — Buckets`). Unknown types fall back to the raw ASFF type string.

**Resource type inference** — when `resourceType` is absent in condensed findings (older aggregator versions), the resource ID ARN prefix is used to infer the type.

**Environment variables required:**
- `BUCKET` — same S3 data bucket as aggregator and API Lambda

**Lambda ZIP:** no extra dependencies — only `boto3` (provided by Lambda runtime).

---

### api_lambda.py — v1.5.2

Three new routes:

**`POST /generate-inventory`**
- Body: `{"account": "123456789012"|"all"}`
- Invokes `INVENTORY_FUNCTION_NAME` Lambda asynchronously (`InvocationType=Event`) — returns HTTP 202 immediately
- Dashboard polls `/inventory-status` until `status === 'done'`

**`GET /inventory-status?account={id}`**
- Reads `inventory/{account}/status.json`
- Returns `{ status: not_started|pending|done|failed, ... }`
- Returns `{ status: "not_started" }` if never triggered — no 404

**`GET /inventory?account={id}&service={type}`**
- Reads `inventory/{account}/latest.json`
- Optional `?service=AwsEc2Instance` query param filters `services[]` and `resources[]` arrays in the response

**New environment variable required:**
```
INVENTORY_FUNCTION_NAME=securityhub-inventory
```

---

### securityhub-dashboard.jsx — v1.5.5

**New `InventoryTab` component:**
- On mount, tries to load existing inventory silently (`GET /inventory`)
- "Generate inventory" / "Refresh inventory" button triggers `POST /generate-inventory` → polls `/inventory-status` → loads result
- Generate progress bar with elapsed-time counter (same pattern as report generation)
- **Service cards** — one row per AWS service type; click to filter the resource table below
- **Resource table** — all affected resources with worst severity badge, finding count, region, account name; full-text search across resource ID / type / region
- Account change resets state automatically
- `onSummaryChange` prop surfaces loaded inventory to parent for CSV export

**Tab switcher** — four tabs: Security Hub · Trusted Advisor · Inspector · Inventory

**Report section** — Inventory tab shows "Inventory export" with "Download CSV" button. CSV columns: Resource ID · Resource Type · Service · Worst Severity · Finding Count · Region · Account ID · Account Name.

---

### New API Gateway routes

Add to the HTTP API:
```
POST /generate-inventory
GET  /inventory-status
GET  /inventory
```

### New IAM permission required — API Lambda execution role

```json
{
  "Effect": "Allow",
  "Action": "lambda:InvokeFunction",
  "Resource": "arn:aws:lambda:eu-west-1:{ACCOUNT_ID}:function:securityhub-inventory"
}
```

### New IAM permission required — Inventory Lambda execution role

```json
{
  "Effect": "Allow",
  "Action": ["s3:GetObject", "s3:PutObject"],
  "Resource": "arn:aws:s3:::securityhub-dashboard-data/*"
}
```

### Deploy checklist

1. **Deploy `inventory_lambda`** as a new Lambda function:
   - Runtime: Python 3.12, ZIP package (no extra pip installs needed)
   - Memory: 512 MB, Timeout: 300 s (5 min) for all-accounts run
   - Environment: `BUCKET=securityhub-dashboard-data`
   - IAM: `s3:GetObject` + `s3:PutObject` on data bucket

2. **Update API Lambda** (`api_lambda.py`):
   - Paste updated file in console → Deploy
   - Add env var: `INVENTORY_FUNCTION_NAME=<function-name>`
   - Add IAM permission: `lambda:InvokeFunction` on the inventory Lambda

3. **Add API Gateway routes**: `POST /generate-inventory`, `GET /inventory-status`, `GET /inventory` — same Lambda integration

4. **Rebuild and redeploy dashboard**: `npm run build` → S3 sync → CloudFront invalidation `/*`

### Files Changed
| File | Version | Change |
|---|---|---|
| `inventory_lambda.py` | *(new)* → **1.0.0** | On-demand inventory from S3 condensed findings; 70+ service display names; per-account + org-wide output |
| `api_lambda.py` | 1.5.1 → **1.5.2** | `POST /generate-inventory`, `GET /inventory-status`, `GET /inventory`, `INVENTORY_FUNCTION_NAME` env var |
| `securityhub-dashboard.jsx` | 1.5.4 → **1.5.5** | `InventoryTab` component, Inventory tab in switcher, inventory CSV export |

---

## v1.5.9 (Aggregator) — Control ID Extraction Fix
*September 2026 · aggregator_lambda.py*

### Problem (regression from v1.5.8)
v1.5.8 removed the `GeneratorId` fallback entirely from `summarize_by_account()` and `condense_finding()`. This broke two things:

1. **Top failing controls always empty** — Security Hub findings from older standard-specific controls (CIS, NIST, PCI) use `GeneratorId` in the format `security-control/EC2.1` rather than setting `ProductFields.ControlId`. Without the fallback, these findings had no `controlId` and were excluded from the top-controls table.

2. **Reports missing most findings** — `report_generator_lambda` filters out rows with empty `controlId`. Since most findings lost their `controlId`, CSV and Excel reports were nearly empty.

### Fix

**New `_extract_control_id(f)` helper:**

```python
def _extract_control_id(f: dict) -> str:
    # 1. ProductFields.ControlId  → 'EC2.1'          (consolidated controls)
    # 2. GeneratorId 'security-control/EC2.1' → 'EC2.1'  (older standards)
    # 3. ARN-style GeneratorId (GuardDuty, Macie) → ''   excluded
```

The helper accepts both valid sources of a Security Hub control ID and returns the short form (e.g. `EC2.1`). Third-party product GeneratorIds that are full ARNs continue to return `''` and are excluded from top-controls and reports.

Used in `summarize_by_account()` and `condense_finding()`.

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.8 → **1.5.9** | `_extract_control_id()` helper; used in `summarize_by_account` and `condense_finding` |

---

## v1.5.8 (Aggregator) / v1.0.1 (Report Generator) / v1.5.1 (API) — Control ID & PDF Download Fixes
*September 2026 · aggregator_lambda.py · report_generator_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

### aggregator_lambda.py — v1.5.8

**`summarize_by_account()`** — top-controls table now only includes findings with a real `ProductFields.ControlId`. Findings from integrated third-party products (GuardDuty, Macie etc.) still count toward severity totals but are excluded from the top-controls table. GeneratorId fallback removed from control aggregation.

**`condense_finding()`** — `controlId` is now set strictly from `ProductFields.ControlId.strip()`. Empty string when absent. GeneratorId fallback removed from display/export path. `_finding_fingerprint()` retains GeneratorId fallback only for stable de-duplication (not shown to users).

### report_generator_lambda.py — v1.0.1

`build_csv_report()`, `build_excel_report()` Tab 1 and Tab 2 — rows with empty `controlId` are skipped. Reports now contain only genuine Security Hub security-standard control findings.

### api_lambda.py — v1.5.1

`/report-url` presigned URL now includes `ResponseContentDisposition: attachment; filename="securityhub-report-{account}.{fmt}"`. This instructs all browsers to save the file rather than preview it, fixing the issue where PDFs opened in the same CloudFront page instead of downloading.

### securityhub-dashboard.jsx

`_triggerDownload` anchor element now has `target="_blank"` as a fallback — if a browser still navigates rather than downloads, it opens in a new tab instead of replacing the dashboard.

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.7 → **1.5.8** | `controlId` from ControlId only; GeneratorId removed from display/export |
| `report_generator_lambda.py` | 1.0.0 → **1.0.1** | CSV + Excel skip rows with empty controlId |
| `api_lambda.py` | 1.5.0 → **1.5.1** | `ResponseContentDisposition: attachment` on presigned URL |
| `securityhub-dashboard.jsx` | — | `target="_blank"` on download anchor |

---

## v1.5.4 (Dashboard) — Tab-Aware Report Download
*September 2026 · securityhub-dashboard.jsx*

The report section now adapts to whichever tab is active. Each tab downloads only its own relevant data.

| Active tab | Section title | Button | What downloads |
|---|---|---|---|
| Security Hub | "Full compliance report" | "Generate report" | PDF / CSV / Excel via `POST /generate-report` (unchanged) |
| Trusted Advisor | "Trusted Advisor export" | "Download CSV" | Instant browser-side CSV of all TA checks for selected account |
| Inspector | "Inspector findings export" | "Download CSV" | Instant browser-side CSV of all Inspector findings for selected account |

**`_downloadTabCSV(tab, accountId)`** — new client-side CSV builder. Uses data already in memory (loaded when the tab was opened). Builds a CSV string, creates a `Blob`, and fires an anchor click. No Lambda, no API call — instant download.

**`TrustedAdvisorTab` and `InspectorTab`** — gained `onSummaryChange` callback prop. Called when data loads or when account changes (passes `null` to clear stale data). Parent stores the result in `taSummary` / `inspectorSummary` state.

**Button disabled** until the tab's data has finished loading. A "Waiting for data to load…" hint is shown.

**TA CSV columns:** Check Name · Status · Category · Resources Flagged · Est. Monthly Savings (USD) · Account

**Inspector CSV columns:** Severity · Title · Resource ID · Resource Type · Region · CVE IDs · First Observed · Account

### Files Changed
| File | Version | Change |
|---|---|---|
| `securityhub-dashboard.jsx` | 1.5.3 → **1.5.4** | `_downloadTabCSV`, `onSummaryChange` prop on tab components, tab-aware report section JSX |

---

## v1.5.3 (Dashboard) — UI Fixes: Report Section Visibility & Controls Layout
*September 2026 · securityhub-dashboard.jsx*

### Changes

#### Full compliance report visible across all tabs
The report generation section was previously inside the Security Hub tab block only. It has been moved outside all tab blocks so it appears permanently at the bottom of the page regardless of which tab (Security Hub, Trusted Advisor, or Inspector) is active.

#### Top failing controls — overlap fix
The control row was a single `flex` row with ID, title, severity badge, and count all competing for horizontal space. Long control titles caused visual overlap with the badge and count. Restructured to two stacked lines:
- Line 1: full-width title (wraps freely)
- Line 2: control ID · severity badge · count — always on one clean line

#### Status polling — resilient to transient errors
The `GET /report-status` poll previously treated any network error as fatal, showing "Could not check report status: failed to fetch" and stopping the flow. Updated to:
- Retry up to 5 consecutive network errors with 5 s back-off before giving up
- Per-poll timeout raised from 10 s → 15 s to tolerate Lambda cold-start latency
- `POST /generate-report` timeout raised from 10 s → 30 s

### Files Changed
| File | Version | Change |
|---|---|---|
| `securityhub-dashboard.jsx` | 1.5.2 → **1.5.3** | Report section always visible; controls row 2-line layout; resilient poll retry; timeouts increased |

---

## v1.5.7 (Aggregator) — Inspector v2 Finding Classification Fix + Account Status
*September 2026 · aggregator_lambda.py*

### Problem
Inspector v2 findings forwarded into Security Hub carry a `ProductArn` of the form:

```
arn:aws:securityhub:{region}::product/aws/inspector
```

The previous `is_inspector_finding()` check used `arn:aws:inspector` as a prefix, which never matched because the actual ARN starts with `arn:aws:securityhub`. This caused **all Inspector findings to be treated as Security Hub native controls**, inflating severity counts and polluting the top-controls table.

### Changes

#### `is_inspector_finding()` — corrected classification logic
- Primary check now uses `::product/aws/inspector` as a **suffix** on the full ProductArn string (case-insensitive), which correctly matches the Security Hub ASFF wrapping
- Secondary check: `ProductFields['aws/inspector/ProductVersion'] == '2'`
- Tertiary fallback: `ProductName == 'inspector' AND CompanyName == 'amazon' AND GeneratorId == 'awsinspector'`
- Any one signal is sufficient — triple-check prevents mis-classification on edge cases

#### `fetch_inspector_account_status()` — new function
- Calls `inspector2.BatchGetAccountStatus` (up to 100 accounts per batch) to retrieve Inspector enablement state per account
- Returns a dict keyed by account ID with: `status`, `enabled`, `enabledScanTypes`, `resourceState`, `errorCode`, `errorMessage`
- Accounts that fail the status check get `{ status: STATUS_CHECK_FAILED, enabled: false }` — failure is isolated and logged, never crashes the run
- Module-level `inspector2 = boto3.client('inspector2', region_name='eu-west-1')` client added

#### `summarize_inspector_by_account()` — updated signature
- Now accepts `inspector_findings`, `inspector_statuses`, `account_ids`
- Every account in `account_ids` is included in the output — even accounts with zero active findings
- New `displayStatus` field per account: `ENABLED_WITH_FINDINGS` | `ENABLED_NO_FINDINGS` | `NOT_ENABLED` | `STATUS_CHECK_FAILED` | `UNKNOWN`
- New `statusMessage` field: human-readable description for the dashboard
- New fields: `inspectorEnabled`, `inspectorStatus`, `enabledScanTypes`, `resourceState`, `statusErrorCode`, `statusErrorMessage`
- All-accounts summary now includes `accountsChecked`, `enabledAccounts`, `disabledAccounts`, `unknownAccounts`

#### `lambda_handler` — Inspector stats in return payload
- `inspectorEnabledAccounts` and `inspectorDisabledAccounts` added to the return body for observability

#### New IAM permission required
Add to the **Aggregator Lambda execution role** before deploying:
```json
{
  "Sid": "Inspector2Status",
  "Effect": "Allow",
  "Action": "inspector2:BatchGetAccountStatus",
  "Resource": "*"
}
```

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.6 → **1.5.7** | `is_inspector_finding()` suffix fix, `fetch_inspector_account_status()`, updated `summarize_inspector_by_account()`, `inspector2` client, IAM note |

---

## v1.5.6 (Aggregator) / v1.5.0 (API) / v1.0.0 (Report Generator) / v1.5.2 (Dashboard) — On-Demand Report Generation
*September 2026 · aggregator_lambda.py · api_lambda.py · report_generator_lambda.py · securityhub-dashboard.jsx*

Reports are no longer pre-built during the aggregator run. They are generated on-demand when the user clicks **Generate report** in the dashboard. This eliminates the aggregator timeout caused by building PDF/CSV/Excel for 70+ accounts inside a 15-minute Lambda.

---

### aggregator_lambda.py — v1.5.6

**Removed all report-building code:**
- `build_pdf_report()`, `build_csv_report()`, `build_excel_report()`, `_pdf_safe()` — no longer needed in aggregator
- `_build_and_upload_account_report()`, `generate_and_upload_reports()`, `REPORT_MAX_WORKERS` — parallel report worker and orchestrator removed
- `REPORT_TIME_GUARD_MS` timing guard block and `passed_raw` variable removed from `lambda_handler`
- `is_new_finding()`, `get_resource_type()`, `NEW_FINDING_WINDOW_HOURS` removed — only used by report builders
- `fpdf`, `openpyxl`, `csv`, `io` imports removed — no longer needed

**Aggregator now writes only:**
- S3 summaries (`summaries/`, `snapshots/`, `trusted-advisor/`, `inspector/`)
- SES email digest

**v1.5.5 changes also included** (single open-findings query + Python-side split):
- `fetch_open_findings()` replaces the separate `fetch_all_findings()` and `fetch_inspector_findings()`
- `is_inspector_finding()` dual-signal check (ProductArn prefix + absence of ControlId)
- `fetch_all_compliance_findings()` has no ProductArn filter

**Lambda ZIP no longer needs `fpdf2` or `openpyxl`** — only `boto3` (provided by Lambda runtime).

---

### report_generator_lambda.py — v1.0.0 (new file)

Standalone Lambda that generates PDF, CSV, and Excel reports **on demand** by reading pre-computed data from S3. No Security Hub API calls are made.

**Data sources (all read from S3):**
- `summaries/{account}/latest.json` — summary dict (score, severity counts, top controls)
- `summaries/{account}/findings.json` — condensed findings list
- `summaries/accounts.json` — account name lookup
- `snapshots/{yesterday}/findings.json` and `snapshots/{today}/findings.json` — resolved-findings delta for Excel tab

**Output written to S3:**
- `reports/{account}/status.json` — `{ status: pending|done|failed, requestId, generatedAt, formats, error }`
- `reports/{account}/latest.pdf`
- `reports/{account}/latest.csv`
- `reports/{account}/latest.xlsx`

**Invocation event shape:**
```json
{ "account": "123456789012|all", "format": "pdf|csv|xlsx|all", "requestId": "<string>" }
```

**Status lifecycle:**
1. `pending` — written immediately on Lambda start so the dashboard stops showing "not started"
2. `done` — written after all requested formats are uploaded
3. `failed` — written if an unhandled exception occurs; `error` field contains the message

**Environment variables required:**
- `BUCKET` — same S3 data bucket as the aggregator and API Lambda

**Lambda ZIP must include:** `fpdf2`, `openpyxl`

---

### api_lambda.py — v1.5.0

**New route: `POST /generate-report`**
- Invokes `report_generator_lambda` asynchronously (`InvocationType=Event`) — returns HTTP 202 immediately
- Body: `{ "account": "{id}", "format": "pdf|csv|xlsx|all" }`
- Response: `{ message, account, format, requestId }`
- Account validated against `^\d{12}$|^all$`; format validated against `VALID_GENERATE_FORMATS = {pdf, csv, xlsx, all}`

**New route: `GET /report-status?account={id}`**
- Reads `reports/{account}/status.json` written by `report_generator_lambda`
- Returns `{ status: not_started|pending|done|failed, formats, error, ... }`
- If the key does not exist (generation never triggered), returns `{ status: "not_started" }` — no 404

**Other changes:**
- `REPORT_GENERATOR_FUNCTION_NAME` added as required environment variable
- `lambda` boto3 client added at module level
- `CORS_HEADERS` `Access-Control-Allow-Methods` updated to include `POST`
- `/report-url` 404 error message updated to direct users to use `/generate-report` instead
- `s3:HeadObject` call in `/report-url` unchanged — still verifies key exists before presigning

**New environment variable required:**
```
REPORT_GENERATOR_FUNCTION_NAME=securityhub-report-generator
```

---

### securityhub-dashboard.jsx — v1.5.2

**Download section replaced with generate→poll→download flow:**

`reportPhase` state machine replaces the old `downloading` boolean:

| Phase | Meaning |
|---|---|
| `idle` | Ready to generate |
| `generating` | Waiting for report_generator_lambda to complete |
| `downloading` | Fetching presigned URL and triggering browser download |
| `done` | Download triggered successfully |
| `error` | Generation or download failed — error shown in banner |

**`handleGenerate()` flow:**
1. `POST /generate-report` → server returns 202 immediately
2. Poll `GET /report-status?account={id}` every 3 seconds
3. On `status === 'done'`: call `_triggerDownload()` which fetches `/report-url` and triggers anchor click
4. On `status === 'failed'`: surface `status.error` in the error banner
5. Poll timeout: 100 polls × 3 s = 5 minutes max; shows timeout error if exceeded

**UI changes:**
- Button label: `Generate report` → `Generating…` → `Downloading…`
- Indeterminate progress bar shown during generation and download
- Elapsed-time counter (`X s elapsed`) shown alongside status text
- Radio buttons disabled during active generation/download
- `✓ Download started — Generate again` success line shown on completion
- Format change resets phase to `idle`

---

### New IAM permission required — API Lambda execution role

```json
{
  "Effect": "Allow",
  "Action": "lambda:InvokeFunction",
  "Resource": "arn:aws:lambda:eu-west-1:{ACCOUNT_ID}:function:securityhub-report-generator"
}
```

### New IAM permission required — Report Generator Lambda execution role

```json
{
  "Effect": "Allow",
  "Action": ["s3:GetObject", "s3:PutObject"],
  "Resource": "arn:aws:s3:::securityhub-dashboard-data/*"
}
```

### New API Gateway route

Add `POST /generate-report` to the HTTP API routes (same Lambda integration as all other routes).

### Deploy checklist

1. **Deploy `report_generator_lambda`** as a new Lambda function:
   - Runtime: Python 3.12, ZIP package with `fpdf2` + `openpyxl`
   - Memory: 1024 MB (2048 MB for large orgs), Timeout: 840 s
   - Environment: `BUCKET=securityhub-dashboard-data`
   - IAM: `s3:GetObject` + `s3:PutObject` on data bucket

2. **Update API Lambda** (`api_lambda.py`):
   - Paste updated file in console → Deploy (no ZIP needed)
   - Add env var: `REPORT_GENERATOR_FUNCTION_NAME=<function-name>`
   - Add IAM permission: `lambda:InvokeFunction` on the report generator

3. **Add API Gateway route**: `POST /generate-report` → same Lambda integration

4. **Rebuild and redeploy dashboard**: `npm run build` → S3 sync → CloudFront invalidation

5. **Redeploy Aggregator Lambda** (v1.5.6 ZIP no longer needs fpdf2/openpyxl):
   ```bash
   cd aggregator_package
   pip install boto3 -t .   # boto3 is provided by runtime; no fpdf2/openpyxl needed
   cp aggregator_lambda.py .
   zip -r ../aggregator_lambda.zip .
   aws lambda update-function-code --function-name securityhub-aggregator \
     --zip-file fileb://aggregator_lambda.zip --region eu-west-1
   ```

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.5 → **1.5.6** | All report-builder code removed; v1.5.5 single-query split retained |
| `api_lambda.py` | 1.4.2 → **1.5.0** | `POST /generate-report`, `GET /report-status`, new env var, CORS POST |
| `report_generator_lambda.py` | *(new)* → **1.0.0** | On-demand PDF/CSV/XLSX from S3 data; status file polling |
| `securityhub-dashboard.jsx` | 1.5.1 → **1.5.2** | `reportPhase` state machine, `handleGenerate()`, progress UI |

---

## v1.5.5 (Aggregator) — Robust Inspector Separation, Single Open-Findings Query
*September 2026 · aggregator_lambda.py*

### Problem
The `ProductArn` filters added in v1.5.4 used `NOT_CONTAINS` and `CONTAINS` as `Comparison` values, which the Security Hub `GetFindings` API rejects with `InvalidInputException`. The previous fix in v1.5.4-patch changed these to `PREFIX_NOT_EQUALS` / `PREFIX`, but using any `ProductArn` filter for Inspector separation is fragile — it depends on the API accepting the exact comparison type and on Inspector `ProductArn` values being consistently prefixed, which can vary across regions and Inspector versions.

### Solution
Replace all `ProductArn` API filters with a single query + Python-side split:

**`fetch_open_findings()`** (replaces `fetch_all_findings()` and `fetch_inspector_findings()`)
- Fetches all `ACTIVE` `NEW/NOTIFIED` findings with no `ProductArn` filter — the simplest valid query
- Returns all products combined (Security Hub native controls + Inspector + any other integrated products)

**`is_inspector_finding()`** — strengthened with dual-signal check
- Primary: `ProductArn` starts with `arn:aws:inspector`
- Secondary: `ProductFields.ControlId` is absent (Inspector never sets this; Security Hub controls always do)
- Both conditions must be true — prevents misclassifying third-party products that happen to lack a ControlId

**Python split in `lambda_handler`**
```python
findings           = [f for f in all_open_findings if not is_inspector_finding(f)]
inspector_findings = [f for f in all_open_findings if     is_inspector_finding(f)]
```
- One API call instead of two, with the split handled entirely in memory
- Inspector `fetch_inspector_findings()` function removed — no longer needed
- Log line emitted with both counts for easy verification in CloudWatch

**`fetch_all_compliance_findings()`** — simplified
- Retains `RecordState=ACTIVE` only, no `ProductArn` filter
- Inspector findings that appear here have no `Compliance.Status` field, so `compute_control_scores()` naturally ignores them when building the per-account control-status map — no filter needed

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.4 → **1.5.5** | `fetch_open_findings()` replaces `fetch_all_findings()` + `fetch_inspector_findings()`; dual-signal `is_inspector_finding()`; Python-side split in `lambda_handler`; `fetch_all_compliance_findings()` stripped of `ProductArn` filter |

---

## v1.4.2 (API) / v1.5.1 (Dashboard) — Excel download NoSuchKey fix
*September 2026 · api_lambda.py · securityhub-dashboard.jsx*

### Problem
Downloading an Excel (or any) report returned a raw S3 XML `NoSuchKey` error page in the browser instead of a friendly message. Root cause: `generate_presigned_url()` succeeds even when the S3 key does not exist — it generates a valid signed URL, but the browser's GET request against that URL hits S3 directly and receives XML. The report key is absent when:
- The aggregator's timing guard skipped report generation (insufficient Lambda time remaining)
- `openpyxl` is not installed in the Lambda ZIP (Excel only)
- The aggregator has never successfully run

### api_lambda.py — v1.4.2

**`/report-url` — existence check before presigning**
- Added `s3.head_object()` call before `generate_presigned_url()`
- If the key does not exist (HTTP 404 / `NoSuchKey`), returns a clean JSON 404 with a diagnostic error message explaining the likely causes
- Any other S3 error is re-raised and caught by the global exception handler
- Added `import botocore.exceptions` for `ClientError` detection

### securityhub-dashboard.jsx — v1.5.1

**`handleDownload` — parse JSON error body on non-OK responses**
- Changed from `if (!r.ok) throw new Error('Server returned N')` to parsing the JSON body regardless of status
- Extracts `body.error` from the API response and surfaces it directly in the dashboard error banner
- Users now see: *"Excel report not found for this account. This usually means the aggregator has not run yet, openpyxl is missing from the Lambda ZIP…"* instead of a blank XML page

### Files Changed
| File | Version | Change |
|---|---|---|
| `api_lambda.py` | 1.4.1 → **1.4.2** | `head_object` existence check in `/report-url`, `botocore.exceptions` import |
| `securityhub-dashboard.jsx` | 1.5.0 → **1.5.1** | `handleDownload` extracts JSON error body from non-OK API responses |

---

## v1.5.4 (Aggregator) / v1.4.1 (API) / v1.5.0 (Dashboard) — AWS Inspector Separate Tab
*September 2026 · aggregator_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

AWS Inspector v2 findings are now separated from Security Hub data end-to-end: collected independently by the aggregator, stored at a dedicated S3 path, served via a new API route, and displayed in their own dashboard tab. Security Hub severity counts, compliance score, top controls, and PDF/CSV/Excel reports no longer include Inspector findings.

---

### aggregator_lambda.py — v1.5.4

#### Inspector findings separated from Security Hub data

**Identification** — Inspector v2 findings are identified by `ProductArn` starting with `arn:aws:inspector`. A new module-level constant `_INSPECTOR_PRODUCT_ARN_PREFIX` and helper `is_inspector_finding()` encapsulate this check.

**Exclusion from Security Hub fetches** — Both `fetch_all_findings()` and `fetch_all_compliance_findings()` now include a `ProductArn NOT_CONTAINS` filter so Inspector findings are excluded from severity counts, compliance score calculation, top controls, and all PDF/CSV/Excel reports.

**New `fetch_inspector_findings()`** — Dedicated paginator with `ProductArn CONTAINS` filter. Fetches only ACTIVE, NEW/NOTIFIED Inspector findings. Logs the total count on completion.

**New `summarize_inspector_by_account()`** — Groups Inspector findings by `AwsAccountId` and computes per-account:
- Severity counts (CRITICAL / HIGH / MEDIUM / LOW) and total
- Finding type breakdown from the `Types[]` array (e.g. `CVE`, `NETWORK_REACHABILITY`)
- Top 10 most-affected resources (by finding count, last 60 chars of ARN)
- Top 10 most-common CVE / rule titles (by count)
- Condensed findings list sorted by severity, capped at 500 per account, each entry includes `cveIds[]` (up to 3 CVE IDs from `Vulnerabilities[]`)
- All-accounts combined summary aggregated across all member accounts

**New `write_inspector_to_s3()`** — Writes to:
```
inspector/{account_id}/latest.json    ← per-account Inspector summary + findings
inspector/all/latest.json             ← all-accounts Inspector summary
```

**`lambda_handler` wiring** — Inspector fetch/summarise/write runs after the Trusted Advisor block. Return payload now includes `inspectorAccountsProcessed` and `inspectorTotalFindings`. If Inspector is not enabled, logs an info message and skips gracefully without error.

**Module docstring** — Updated S3 path listing to include the two new `inspector/` paths.

#### Version bump
`AGGREGATOR_VERSION` bumped from `1.5.3` → `1.5.4`.

---

### api_lambda.py — v1.4.1

#### New `/inspector` route

```
GET /inspector?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW
```

- Reads `inspector/{account}/latest.json` written by aggregator v1.5.4+
- `account` validated against `^\d{12}$|^all$` (same as all other routes)
- Optional `severity` filter narrows the `findings[]` array in the response; validated against `VALID_INSPECTOR_SEVERITIES = {'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'}`
- Returns the full summary object (severity counts, `byType`, `topResources`, `topFindings`, filtered `findings[]`)
- Logs account, severity, and findings count at INFO level
- `NoSuchKey` (Inspector not yet run / not enabled) returns 404 via the global exception handler — no per-route try/except needed

Added `VALID_INSPECTOR_SEVERITIES` constant alongside the existing `VALID_SEVERITIES` and `VALID_TA_STATUSES`. Route documented in module docstring routes list.

#### Version bump
`API_VERSION` bumped from `1.4.0` → `1.4.1`.

---

### securityhub-dashboard.jsx — v1.5.0

#### New `InspectorTab` component

Fetches `GET /inspector?account={accountId}` with a 10-second `fetchWithTimeout` and re-fetches on account change. Follows the same loading / error / null-guard pattern as `TrustedAdvisorTab`.

**Layout:**
- **Severity cards** (CRITICAL / HIGH / MEDIUM / LOW + Total) — clickable to filter the findings list; clicking the active severity again clears the filter. Clicking any card also switches the sub-tab to Findings automatically.
- **Finding type breakdown** — pill badges showing each Inspector finding type (e.g. `CVE`, `NETWORK REACHABILITY`) with its count, sorted by count descending. Hidden when no type data is available.
- **Last refreshed** timestamp from `summary.lastScan`
- **Three sub-tabs** (nested within the Inspector tab):
  - **Findings** — scrollable list (max-height 480 px), each row shows title, severity badge, resource ID (truncated), resource type, region, and up to 3 CVE IDs. Empty state message when no findings match the active severity filter.
  - **Top Resources** — top 10 resources by finding count, resource ARN + count
  - **Top CVEs / Rules** — top 10 CVE/rule titles by count, title + count
- **Clear filter** button appears in sub-tab bar when a severity is active

#### Tab switcher
Added `{ id: 'inspector', label: 'Inspector' }` to the tab array. Now three tabs: Security Hub · Trusted Advisor · Inspector.

#### Inspector render block
```jsx
{activeTab === 'inspector' && (
  <InspectorTab
    apiBase={API_BASE}
    accountId={apiAccountId === 'multi' ? 'all' : apiAccountId}
  />
)}
```

#### Footer
Updated footer text from `"…Security Hub & Trusted Advisor APIs…"` to `"…Security Hub, Trusted Advisor & Inspector APIs…"`.

#### Version bump
`DASHBOARD_VERSION` bumped from `1.4.1` → `1.5.0`.

---

### New S3 Paths Written
```
inspector/{account_id}/latest.json    ← per-account Inspector summary + condensed findings
inspector/all/latest.json             ← all-accounts Inspector summary
```

### New API Route
```
GET /inspector?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW
```

### Deploy Checklist
1. **Redeploy Aggregator Lambda** — rebuild ZIP, `aws lambda update-function-code`. No new environment variables or IAM permissions required (uses the existing `securityhub:GetFindings` permission — Inspector findings flow through Security Hub when Inspector → Security Hub integration is enabled).
2. **Verify Inspector → Security Hub integration is enabled** — AWS Inspector console → Integrations → Security Hub → Status must be Active in each member account.
3. **Redeploy API Lambda** — paste updated `api_lambda.py` in console → Deploy. Add the new `GET /inspector` route in API Gateway → Routes.
4. **Rebuild and redeploy frontend** — `npm run build`, sync to S3, CloudFront invalidation `/*`.

### Files Changed
| File | Version | Change summary |
|---|---|---|
| `aggregator_lambda.py` | 1.5.3 → **1.5.4** | `_INSPECTOR_PRODUCT_ARN_PREFIX`, `is_inspector_finding()`, `fetch_inspector_findings()`, `summarize_inspector_by_account()`, `write_inspector_to_s3()`, NOT_CONTAINS filter on both existing fetch functions, lambda_handler wired |
| `api_lambda.py` | 1.4.0 → **1.4.1** | `/inspector` route, `VALID_INSPECTOR_SEVERITIES`, docstring updated |
| `securityhub-dashboard.jsx` | 1.4.1 → **1.5.0** | `InspectorTab` component, Inspector tab in switcher, render block, footer text updated |

---

## v1.5.3 — Performance: Parallel Report Generation & S3 Writes
*August 2026 · aggregator_lambda.py*

### What's New

#### 1. Day-over-Day Snapshot Comparison
- Aggregator now writes a dated snapshot to S3 each run:
  `snapshots/{YYYY-MM-DD}/findings.json`
- On every run, yesterday's snapshot is loaded and compared to today's
- **New findings** = appeared today, not in yesterday's snapshot
- **Resolved findings** = were in yesterday's snapshot, gone today (remediated or suppressed)
- Comparison is fingerprint-based: `accountId | controlId | resourceId` — stable across runs
- Lambda return payload now includes `newFindings` and `resolvedFindings` counts

#### 2. Multi-Tab Excel Report (3 Sheets)
- Every account now gets a `reports/{account_id}/latest.xlsx` alongside PDF and CSV
- **Tab 1 — Failed Checks**: all currently open/failing findings, sorted Critical → High → Medium → Low, color-coded by severity
- **Tab 2 — Passed Checks**: controls currently in PASSED state (de-duplicated by account + control + resource)
- **Tab 3 — Previously Failed, Now Passed**: findings that were open yesterday but resolved today — tracks remediation progress
- All tabs have frozen header rows, auto-sized columns, and Calibri font for Windows compatibility
- Requires `openpyxl` in the Lambda ZIP — gracefully skips Excel generation if not installed (logs a warning)

#### 3. SES Email Digest
- After each daily run, an HTML email is sent via SES listing all **new Critical and High** findings
- Email includes: severity badge, control ID, finding title, account name, and affected resource
- Only fires if there are new Critical/High findings — no noise on clean days
- **Before deploying**: update `SES_FROM_EMAIL` (must be a verified SES sender) and `SES_TO_EMAIL` (your distribution list) at the top of `aggregator_lambda.py`
- Email silently skips if `SES_TO_EMAIL` still contains the placeholder value `UPDATE_YOUR_DL`

---

### Files Changed
| File | Change |
|---|---|
| `aggregator_lambda.py` | Version bumped 1.4.0 → 1.5.0. Added snapshot helpers, Excel builder, SES digest, updated `generate_and_upload_reports()` and `lambda_handler()` |
| `api_lambda.py` | Version bumped to **1.3.1**. Fixed `/report-url` validation guard to accept `xlsx` (was returning 400) |
| `securityhub-dashboard.jsx` | No change — v1.4.0. Excel radio button already present, now functional end-to-end |

---

### New IAM Permissions Required

Add these to the **Aggregator Lambda's execution role** before deploying:

```json
{
  "Effect": "Allow",
  "Action": [
    "s3:PutObject",
    "s3:GetObject"
  ],
  "Resource": "arn:aws:s3:::securityhub-dashboard-data/snapshots/*"
},
{
  "Effect": "Allow",
  "Action": "ses:SendEmail",
  "Resource": "*"
}
```

---

### New S3 Paths Written
```
snapshots/{YYYY-MM-DD}/findings.json     ← daily snapshot for delta tracking
reports/{account_id}/latest.xlsx         ← 3-tab Excel per account
reports/all/latest.xlsx                  ← combined 3-tab Excel
```

---

### Deploy Steps

#### 1. Add openpyxl to the Lambda ZIP
```bash
cd ~/Documents/securityhub-aggregator-package
python3 -m pip install openpyxl -t .
# replace aggregator_lambda.py with the new v1.5.0 file
zip -r aggregator_lambda.zip .
aws lambda update-function-code \
  --function-name securityhub-aggregator \
  --zip-file fileb://aggregator_lambda.zip
```

#### 2. Set Lambda environment variables
All runtime config is now driven by environment variables — no editing source files.
Set these in **Lambda → Configuration → Environment variables** before deploying:

| Variable | Required | Description |
|---|---|---|
| `BUCKET` | ✅ | S3 bucket name (e.g. `securityhub-dashboard-data`) |
| `SES_FROM_EMAIL` | ✅ | Verified SES sender address |
| `SES_TO_EMAIL` | ✅ | Distribution list for Critical/High alerts |
| `ACCOUNT_NAME_OVERRIDES` | optional | Comma-separated `accountId=name` pairs, e.g. `143301474150=audit,824623333855=prod` |

> **Note:** The Lambda will fail at cold-start with a clear `EnvironmentError` if any required variable is missing — this is intentional to prevent silent misconfiguration.

#### 3. Verify SES sender in AWS console
- SES console → Verified identities → verify `SES_FROM_EMAIL` domain or address
- If SES is still in sandbox mode, also verify `SES_TO_EMAIL`

#### 4. Update Lambda IAM role
- Add `s3:PutObject` and `s3:GetObject` on `snapshots/*` prefix
- Add `ses:SendEmail` (resource: `*`)

#### 5. Trigger manually and verify
```bash
# After deploy, trigger once and check:
# - S3: snapshots/YYYY-MM-DD/findings.json exists
# - S3: reports/{account}/latest.xlsx exists with 3 tabs
# - CloudWatch logs: "SES digest sent" or "No new Crit/High findings"
# - Lambda response includes newFindings and resolvedFindings counts
```

---

### Version Reference

| Component | Version | Key file |
|---|---|---|
| Aggregator Lambda | **1.5.2** | `aggregator_lambda.py` |
| API Lambda | **1.4.0** | `api_lambda.py` |
| Dashboard | **1.4.1** | `securityhub-dashboard.jsx` |

---

## v1.5.3 — Performance: Parallel Report Generation & S3 Writes
*September 2026 · aggregator_lambda.py*

### What Changed

Addresses Lambda timeout errors on environments with 70+ member accounts.
All changes are internal — no behaviour, output format, or API contract is altered.

#### `generate_and_upload_reports()` — parallel per-account report builds
- Replaced the serial `for account_id, summary in summaries.items()` loop with a `ThreadPoolExecutor(max_workers=10)`
- Extracted `_build_and_upload_account_report()` as the per-account worker — builds PDF + CSV + XLSX in-process then uploads all three to S3
- boto3 S3 clients are thread-safe; fpdf2 and openpyxl create independent in-memory objects so there is no shared mutable state between workers
- One worker failure still logs the full traceback and returns `False`; all other accounts continue unaffected
- Combined "all accounts" reports are still built serially after the pool completes (they depend on all per-account data)
- Expected wall-clock reduction for 70 accounts: ~70× serial cost → ~7× (10 workers)
- Tune `REPORT_MAX_WORKERS` down if Lambda Max Memory Used exceeds ~90%

#### `write_to_s3()` — parallel per-account S3 summary puts
- All condensed finding lists are now built in-memory first (pure Python, no I/O) before any S3 call
- Per-account `summaries/{account_id}/latest.json` and `summaries/{account_id}/findings.json` puts fan out across a `ThreadPoolExecutor(max_workers=20)`
- Individual put failures are caught per-account and logged as warnings without aborting the rest
- Combined `summaries/all/*` and `summaries/version.json` are written serially after the pool, as before
- Expected wall-clock reduction for 70 accounts: ~140 blocking serial puts → ~7 sequential batches of 20

#### `TA_MAX_WORKERS` — increased from 5 to 10
- Trusted Advisor concurrent account fetch increased from 5 to 10 workers
- For 70 accounts: reduces fetch from ~14 sequential batches to ~7
- Tune back to 5 if AWS Support API throttling (`TooManyRequestsException`) appears in logs

### Time Budget Impact (estimated for 70 accounts)

| Section | Before | After |
|---|---|---|
| `write_to_s3()` ~140 S3 puts | ~35 s | ~4 s |
| `generate_and_upload_reports()` 70× (PDF+CSV+XLSX+3 puts) | ~210 s | ~25 s |
| Trusted Advisor fetch (70 accounts × ~116 calls) | ~140 s | ~70 s |
| **Total saving** | | **~290 s (~5 min)** |

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.2 → **1.5.3** | Parallel report generation (`REPORT_MAX_WORKERS=10`), parallel S3 summary writes (`S3_WRITE_MAX_WORKERS=20`), `TA_MAX_WORKERS` 5→10 |

---

## v1.5.2 — PDF Unicode Fix
*September 2026 · aggregator_lambda.py*

### Bug Fixed

#### `FPDFUnicodeEncodingException` crash during PDF report generation
- The aggregator crashed when generating PDF reports for any account whose data contained characters outside the latin-1 range (e.g. em-dash `—` in the "Since Last Scan" summary line, or non-ASCII characters in finding titles, resource IDs, or account names sourced from AWS)
- Root cause: fpdf2's built-in Helvetica font only supports latin-1; the "Since Last Scan" cell was hardcoded with a `\u2014` em-dash, and no sanitisation was applied to external AWS data before rendering
- Fixed by adding a `_pdf_safe()` helper that replaces common Unicode typography characters (em-dash, en-dash, smart quotes, ellipsis, NBSP) with ASCII equivalents, then drops anything else still outside latin-1 via `encode('latin-1', errors='replace')`
- Applied to: the "Since Last Scan" cell (direct cause), and defensively to account name, finding titles, control IDs, resource IDs, and top-control titles

### Files Changed
| File | Version | Change |
|---|---|---|
| `aggregator_lambda.py` | 1.5.1 → **1.5.2** | Added `_pdf_safe()` helper; applied to all PDF cells that render external AWS data |

---

## v1.5.1 / v1.4.0 (API) / v1.4.1 (Dashboard) — Production Hardening
*September 2026 · aggregator_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

All three components hardened for production. No new features — behaviour is unchanged for valid requests.

---

### aggregator_lambda.py — v1.5.1

#### Environment variables replace all hardcoded config (breaking change for existing deploys)
Three values that were previously hardcoded must now be set as Lambda environment variables.
The Lambda raises a clear `EnvironmentError` at cold-start if any are missing — no silent misconfiguration.

| Variable | Was | Now |
|---|---|---|
| `BUCKET` | `'securityhub-dashboard-data'` (line 73) | `os.environ['BUCKET']` |
| `SES_FROM_EMAIL` | `'securityhub-noreply@vijaymdm.click'` (line 72) | `os.environ['SES_FROM_EMAIL']` |
| `SES_TO_EMAIL` | `'UPDATE_YOUR_DL@yourcompany.com'` (line 73) | `os.environ['SES_TO_EMAIL']` |
| `ACCOUNT_NAME_OVERRIDES` | hardcoded dict with real account IDs (lines 108–111) | `os.environ.get('ACCOUNT_NAME_OVERRIDES', '')` parsed as `key=value` pairs |

#### Trusted Advisor — concurrent fetch replaces serial loop
- Replaced the serial `for account_id in sorted(all_account_ids)` loop with `ThreadPoolExecutor(max_workers=5)`
- For 70 accounts, this reduces TA fetch time from ~70× per-account latency to ~14× (5 parallel batches)
- `as_completed()` collects results as they arrive — failed accounts don't block others
- `TA_MAX_WORKERS = 5` is a tunable constant at the top of the loop comment

#### STS session name uniqueness fix
- `fetch_trusted_advisor_checks()` used a static `RoleSessionName='TAReader'` for all accounts
- Fixed to `RoleSessionName=f'TAReader-{account_id}'` — concurrent executions for different accounts no longer risk credential collisions

#### Per-account report generation isolated with try/except
- `generate_and_upload_reports()` inner loop now wraps each account in `try/except`
- A crash in PDF/CSV/Excel generation for one account (e.g. encoding error, font issue) logs the full traceback via `logger.exception()` and continues to the next account
- Previously, one bad account silently killed all subsequent reports

#### Module-level `SEVERITY_RANK` constant
- `SEVERITY_RANK` dict is now computed once at module level from `SEVERITY_ORDER`
- Removes repeated inline `{sev: i for i, sev in enumerate(SEVERITY_ORDER)}` comprehensions in `build_csv_report` and `build_excel_report`

---

### api_lambda.py — v1.4.0

#### Environment variables replace hardcoded config (breaking change for existing deploys)

| Variable | Was | Now |
|---|---|---|
| `BUCKET` | `'securityhub-dashboard-data'` | `os.environ['BUCKET']` |
| `CORS_ALLOW_ORIGIN` | `'https://security.vijaymdm.click'` | `os.environ['CORS_ALLOW_ORIGIN']` |

Set these in **Lambda → Configuration → Environment variables**.

#### account parameter validated against strict allowlist
- All routes that accept an `account` query param now validate it against `^\d{12}$|^all$` before using it in S3 key construction
- Invalid values return HTTP 400 with a descriptive error message
- Prevents S3 path traversal attempts (e.g. `account=../version`)

#### severity and status params validated against allowlists
- `/findings` route: `severity` validated against `{CRITICAL, HIGH, MEDIUM, LOW}` — invalid value returns 400
- `/trusted-advisor` route: `status` validated against `{error, warning, ok}` — invalid value returns 400
- Previously, unrecognised values silently returned empty results

#### Internal errors no longer leaked to callers
- `except Exception as e: return respond(500, {'error': str(e)})` replaced with a safe generic message
- Real exception is logged via `logger.exception()` with the request ID for CloudWatch lookup
- Every response now includes `requestId` (from `context.aws_request_id`) for correlation

#### CORS preflight includes `Access-Control-Max-Age: 600`
- Browsers cache the preflight response for 10 minutes
- Halves API call volume from browser clients (no preflight on every request)

---

### securityhub-dashboard.jsx — v1.4.1

#### ErrorBoundary wraps the full dashboard tree
- New `ErrorBoundary` class component catches any render-time exception anywhere in the component tree
- Shows a friendly "Something went wrong · Reload dashboard" screen instead of a blank white page
- Logs error + component stack to the console for debugging

#### All fetch() calls have a 10-second AbortController timeout
- New `fetchWithTimeout(url)` helper wraps every `fetch()` call with an `AbortController` that fires after `FETCH_TIMEOUT_MS = 10_000`
- Timeout is cleared on completion to avoid memory leaks
- `formatFetchError(err)` maps `AbortError` → "Request timed out" and other errors → their message
- Applies to: `/accounts`, `/version`, `/summary` (single + multi), `/findings`, `/trusted-advisor`, `/report-url`

#### Report download no longer uses window.open()
- `handleDownload` previously called `window.open(url, '_blank')` after an async `fetch()` — most browsers block this as a popup because it runs after the user gesture frame
- Fixed: creates a hidden `<a>` element, sets `href` + `download` + `rel`, appends to body, clicks it, then removes it
- The download now triggers reliably regardless of popup blocker settings

#### ScoreDial NaN guard
- `score` prop is now coerced to `0` if it is `undefined`, `null`, or `NaN` before computing `strokeDashoffset`
- Prevents a broken SVG ring on first render before data loads

#### CountCard null guard
- `value` prop now renders as `value ?? 0` — shows `0` instead of blank when data is loading

#### Error banner dismiss button
- The error banner now includes an `✕` dismiss button so users can clear stale error messages without refreshing

#### API_BASE from build-time environment variable
- `API_BASE` is now read from `import.meta.env.VITE_API_BASE` (Vite) with a fallback placeholder
- Set `VITE_API_BASE=https://your-api-id.execute-api.region.amazonaws.com` in your `.env` file
- The hardcoded API Gateway URL is no longer in source

---

### New environment variables — deploy checklist

#### Aggregator Lambda
```
BUCKET=securityhub-dashboard-data
SES_FROM_EMAIL=securityhub-noreply@yourdomain.com
SES_TO_EMAIL=your-dl@yourcompany.com
ACCOUNT_NAME_OVERRIDES=143301474150=audit,824623333855=prod   # optional
```

#### API Lambda
```
BUCKET=securityhub-dashboard-data
CORS_ALLOW_ORIGIN=https://security.yourdomain.com
```

#### Dashboard build (.env file)
```
VITE_API_BASE=https://your-api-id.execute-api.eu-west-1.amazonaws.com
```

### Files Changed
| File | Version | Change summary |
|---|---|---|
| `aggregator_lambda.py` | 1.5.0 → **1.5.1** | Env vars for BUCKET/SES, ACCOUNT_NAME_OVERRIDES from env, ThreadPoolExecutor for TA, per-account report try/except, STS session name fix, SEVERITY_RANK constant |
| `api_lambda.py` | 1.3.1 → **1.4.0** | Env vars for BUCKET/CORS, account param regex validation, severity/status allowlists, safe 500 responses with request ID, CORS preflight max-age |
| `securityhub-dashboard.jsx` | 1.4.0 → **1.4.1** | ErrorBoundary, fetchWithTimeout on all fetches, anchor-click download, NaN/null guards, error dismiss, API_BASE from env |

---

## v1.3.1 — API Lambda: xlsx Format Fix + Critical Aggregator Bug Fixes
*September 2026 · api_lambda.py · aggregator_lambda.py · securityhub-dashboard.jsx*

### What Changed

#### api_lambda.py — xlsx validation fix
- `/report-url` endpoint now correctly accepts `&format=xlsx`
- The v1.3.0 release documented xlsx support but the input validation guard was never updated — requests with `format=xlsx` were silently rejected with HTTP 400
- No logic changes; only the allowed-format check was widened from `('pdf', 'csv')` to `('pdf', 'csv', 'xlsx')`
- Excel download on the dashboard is now fully functional end-to-end

#### aggregator_lambda.py — missing function definitions restored
Four functions were called in `lambda_handler` but not defined in the file, which would cause a `NameError` crash on every Lambda invocation:
- **`write_to_s3()`** — writes `summaries/accounts.json`, `summaries/{account_id}/latest.json`, `summaries/{account_id}/findings.json`, `summaries/all/*.json`, and `summaries/version.json`
- **`fetch_trusted_advisor_checks()`** — fetches TA checks per account (own credentials for admin, STS role assumption for members)
- **`summarize_ta_by_account()`** — aggregates error/warning/ok counts per account and all-accounts
- **`write_ta_to_s3()`** — writes `trusted-advisor/{account_id}/latest.json` and `trusted-advisor/all/latest.json`

#### securityhub-dashboard.jsx — undefined variable fix
- `TrustedAdvisorTab` was passed `accountId={accountId}` but `accountId` is not a variable in the parent component — this caused a React runtime error when switching to the Trusted Advisor tab
- Fixed to `accountId={apiAccountId === 'multi' ? 'all' : apiAccountId}`, consistent with how all other API calls in the component resolve the account

### Files Changed
| File | Change |
|---|---|
| `api_lambda.py` | Version bumped 1.3.0 → 1.3.1. Fixed `/report-url` validation guard to accept `xlsx`. |
| `aggregator_lambda.py` | Added missing `write_to_s3`, `fetch_trusted_advisor_checks`, `summarize_ta_by_account`, `write_ta_to_s3` function definitions. No version bump (bug fix for existing v1.5.0 logic). |
| `securityhub-dashboard.jsx` | Fixed `TrustedAdvisorTab` `accountId` prop — was passing undefined `accountId`, now passes `apiAccountId` (or `'all'` for multi-select). No version bump (bug fix for existing v1.4.0 logic). |

---

## v1.4.0 (Dashboard) — Search + Multi-Select Account Picker
*August 2026 · securityhub-dashboard.jsx*

### What's New
- **Search input** at the top of the account dropdown — filters by account name or ID as you type
- **Multi-select checkboxes** — select one, many, or all accounts simultaneously
- **Client-side aggregation** — when 2+ accounts selected, severity counts (Critical/High/Medium/Low) and compliance score are aggregated across selected accounts
- **Summary cache** — already-fetched account summaries are cached in memory; switching between selections doesn't re-fetch data already loaded
- **"X accounts selected"** label in the selector button when multiple are chosen
- **Clear all** button to reset to All Accounts in one click
- **Apply button** closes the dropdown and applies selection
- Severity drill-down (`/findings` API call) uses `all` when multiple accounts selected, specific account when one is selected
- Report download uses `all` when multiple accounts selected
- Excel (xlsx) format radio button added to report download section

### Files Changed
| File | Change |
|---|---|
| `securityhub-dashboard.jsx` | Version 1.3.0 → 1.4.0. Full account selector rewrite. Added xlsx radio option in download section. |

---

## v1.4.0 (Aggregator) — Executive Summary PDF, NEW Badges, Resource-Type Grouping
*aggregator_lambda.py*

- PDF opens with executive summary page: score, severity bar chart, new-vs-existing delta, top 3 controls
- Findings tagged NEW if first observed within ~26h window (uses AWS `FirstObservedAt`)
- New final PDF page: findings grouped by AWS resource type
- CSV: added `IsNew` and `ResourceType` columns

---

## v1.3.0 — Real AWS-Formula Compliance Score
*aggregator_lambda.py · securityhub-dashboard.jsx*

- Score now matches AWS Security Hub console exactly: `passed ÷ (passed+failed+warning) × 100`
- `NOT_AVAILABLE` controls excluded from both numerator and denominator
- 100%-passing accounts now appear in the dashboard (previously missing)
- Fixed-height PDF table rows (no more row misalignment on long titles)
- Dashboard: added compliance-score transparency line (passed/enabled controls), Trusted Advisor tab, click-to-drill-down severity cards

---

## v1.2.0 — Trusted Advisor + CSV Export
*aggregator_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

- Trusted Advisor integration (cross-account role assumption per member account)
- CSV export added alongside PDF
- `findings.json` per account for click-to-drill-down severity cards
- API: added `/trusted-advisor` and `/version` routes; `/report-url` extended to `pdf|csv`
- Dashboard: added CSV/PDF format radio selector for report download

---

## v1.1.0 — PDF Reports
*aggregator_lambda.py · securityhub-dashboard.jsx*

- PDF generation using `fpdf2`, findings grouped and ordered Critical → High → Medium → Low
- Dashboard: click-to-drill-down severity cards showing matching findings

---

## v1.0.0 — Initial Release
*aggregator_lambda.py · api_lambda.py · securityhub-dashboard.jsx*

- Security Hub findings aggregation via delegated admin `GetFindings`
- Per-account JSON summaries written to S3
- Account index for dashboard dropdown
- API routes: `/accounts`, `/summary`, `/report-url` (PDF only)
- Dashboard: account selector, compliance score dial, severity cards, top controls, PDF download

