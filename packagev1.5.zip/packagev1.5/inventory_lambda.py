"""
On-demand Account Inventory Lambda  —  v2.0.0
Invoked asynchronously by the API Lambda (InvocationType='Event') when the
user opens the Inventory tab or clicks 'Refresh inventory' in the dashboard.

WHAT'S NEW IN v2.0.0
  Unlike v1.x which derived inventory from Security Hub findings.json (only
  resources with open findings were visible), this version performs LIVE
  resource discovery across ALL regions using AWS Config
  ListDiscoveredResources.  Resources with no Security Hub findings are now
  included.  Global services (IAM, CloudFront, Route 53, WAF, etc.) are
  handled by querying the us-east-1 Config recorder, which is the only region
  that records them.

CROSS-ACCOUNT ACCESS
  The lambda assumes INVENTORY_READER_ROLE_NAME (default:
  'InventoryReadOnlyRole') in each member account using STS AssumeRole, then
  calls the Config API from that assumed-role session.  The delegated-admin
  account itself is queried using its own execution-role credentials (no
  assumption needed).

  Member-account role requirements:
    config:ListDiscoveredResources    (allow: *)
    config:DescribeConfigurationRecorders
    Trust policy must allow the aggregator/inventory Lambda execution role
    ARN to assume it.

PAGINATION
  Every ListDiscoveredResources call is fully paginated via NextToken until
  the API returns no more pages.  There is no hard cap on resources returned.

GLOBAL SERVICES
  AWS Config records global (region-independent) resource types against the
  us-east-1 recorder.  The GLOBAL_RESOURCE_TYPES set lists every type that
  Config treats as global.  The lambda always includes 'us-east-1' in the
  region list for this purpose, even if it is not in the AWS Organizations
  region list.

CSV EXPORT
  After building the inventory the lambda writes a flat CSV to:
    inventory/{account}/latest.csv
  Columns: service, resourceType, resourceName, resourceId, region, accountId,
           accountName
  The api_lambda GET /inventory-csv route returns a 15-minute presigned S3
  GET URL for this file.

DEPLOYMENT REGION
  eu-west-1 (same as aggregator and API Lambda).

VERSION: 2.0.0

CHANGELOG
  2.0.0 - Complete rewrite. Live resource discovery via AWS Config
          ListDiscoveredResources across all active regions. Cross-account
          role assumption (InventoryReadOnlyRole). Global service handling
          (IAM, CloudFront, Route 53, WAFv2, etc.) via us-east-1 recorder.
          Full pagination — no resource cap. Deduplication by (accountId,
          resourceType, resourceId). Service-wise resource count summary.
          CSV export to inventory/{account}/latest.csv. Output schema is
          backward-compatible with v1.x (services[], resources[]) with
          additional fields (resourceName, accountId, accountName on each
          resource; serviceLabel, totalResources in summary).
  1.0.0 - Initial: derived inventory from S3 findings.json written by the
          aggregator. Only resources with open Security Hub findings were
          visible.

Environment variables:
  BUCKET                    — S3 data bucket (shared with aggregator + api_lambda)
  INVENTORY_READER_ROLE_NAME (optional, default: InventoryReadOnlyRole)
                            — IAM role name assumed in each member account

Invocation event (from api_lambda POST /generate-inventory):
  { "account": "123456789012" | "all", "requestId": "<string>" }

S3 paths written:
  inventory/{account}/latest.json    — full inventory (services + resources)
  inventory/{account}/latest.csv     — flat CSV of all resources
  inventory/all/latest.json          — org-wide rollup (account="all")
  inventory/all/latest.csv           — org-wide flat CSV (account="all")
  inventory/{account}/status.json    — { status, requestId, generatedAt, error }

IAM permissions required on the Lambda execution role:
  s3:GetObject, s3:PutObject         — on the BUCKET
  sts:AssumeRole                     — to assume InventoryReadOnlyRole
  config:ListDiscoveredResources     — own account (delegated admin)
  config:DescribeConfigurationRecorders  — own account
  organizations:ListAccounts         — to enumerate member accounts (when
                                       account="all" and accounts.json absent)
"""

import boto3
import botocore.exceptions
import csv
import io
import json
import logging
import os
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

INVENTORY_VERSION = '2.0.0'

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _require_env(name: str) -> str:
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(f"Required environment variable '{name}' is not set.")
    return val

def _optional_env(name: str, default: str = '') -> str:
    return os.environ.get(name, default).strip()

BUCKET                     = _require_env('BUCKET')
INVENTORY_READER_ROLE_NAME = _optional_env('INVENTORY_READER_ROLE_NAME',
                                           'InventoryReadOnlyRole')

s3  = boto3.client('s3')
sts = boto3.client('sts')

# ---------------------------------------------------------------------------
# Global resource types
# AWS Config only records these against the us-east-1 recorder, so they must
# always be queried in us-east-1 regardless of the account's active regions.
# ---------------------------------------------------------------------------
GLOBAL_RESOURCE_TYPES: set = {
    'AWS::IAM::Group',
    'AWS::IAM::Policy',
    'AWS::IAM::Role',
    'AWS::IAM::User',
    'AWS::CloudFront::Distribution',
    'AWS::CloudFront::StreamingDistribution',
    'AWS::Route53::HostedZone',
    'AWS::Route53Resolver::ResolverRule',
    'AWS::Route53Resolver::ResolverRuleAssociation',
    'AWS::WAF::WebACL',
    'AWS::WAF::RuleGroup',
    'AWS::WAF::Rule',
    'AWS::WAFv2::WebACL',
    'AWS::WAFv2::RuleGroup',
    'AWS::WAFv2::IPSet',
    'AWS::WAFv2::RegexPatternSet',
    'AWS::WAFv2::ManagedRuleSet',
    'AWS::Shield::Protection',
    'AWS::ShieldRegional::Protection',
    'AWS::ACM::Certificate',            # ACM issues global certs via us-east-1
}

# ---------------------------------------------------------------------------
# Human-readable display labels  (resourceType → service label, display name)
# ---------------------------------------------------------------------------
_SERVICE_MAP: dict[str, tuple[str, str]] = {
    # EC2
    'AWS::EC2::Instance':              ('EC2', 'EC2 — Instances'),
    'AWS::EC2::SecurityGroup':         ('EC2', 'EC2 — Security Groups'),
    'AWS::EC2::Volume':                ('EC2', 'EC2 — EBS Volumes'),
    'AWS::EC2::VPC':                   ('EC2', 'EC2 — VPCs'),
    'AWS::EC2::Subnet':                ('EC2', 'EC2 — Subnets'),
    'AWS::EC2::NetworkInterface':      ('EC2', 'EC2 — Network Interfaces'),
    'AWS::EC2::RouteTable':            ('EC2', 'EC2 — Route Tables'),
    'AWS::EC2::InternetGateway':       ('EC2', 'EC2 — Internet Gateways'),
    'AWS::EC2::NatGateway':            ('EC2', 'EC2 — NAT Gateways'),
    'AWS::EC2::EgressOnlyInternetGateway': ('EC2', 'EC2 — Egress-Only IGWs'),
    'AWS::EC2::TransitGateway':        ('EC2', 'EC2 — Transit Gateways'),
    'AWS::EC2::TransitGatewayAttachment': ('EC2', 'EC2 — TGW Attachments'),
    'AWS::EC2::LaunchTemplate':        ('EC2', 'EC2 — Launch Templates'),
    'AWS::EC2::CustomerGateway':       ('EC2', 'EC2 — Customer Gateways'),
    'AWS::EC2::VPNConnection':         ('EC2', 'EC2 — VPN Connections'),
    'AWS::EC2::VPNGateway':            ('EC2', 'EC2 — Virtual Private Gateways'),
    'AWS::EC2::FlowLog':               ('EC2', 'EC2 — Flow Logs'),
    'AWS::EC2::Host':                  ('EC2', 'EC2 — Dedicated Hosts'),
    'AWS::EC2::IPAM':                  ('EC2', 'EC2 — IPAM'),
    # S3
    'AWS::S3::Bucket':                 ('S3', 'S3 — Buckets'),
    'AWS::S3::AccountPublicAccessBlock': ('S3', 'S3 — Account Public Access Block'),
    # IAM (global)
    'AWS::IAM::User':                  ('IAM', 'IAM — Users'),
    'AWS::IAM::Role':                  ('IAM', 'IAM — Roles'),
    'AWS::IAM::Group':                 ('IAM', 'IAM — Groups'),
    'AWS::IAM::Policy':                ('IAM', 'IAM — Policies'),
    # RDS
    'AWS::RDS::DBInstance':            ('RDS', 'RDS — DB Instances'),
    'AWS::RDS::DBCluster':             ('RDS', 'RDS — Clusters'),
    'AWS::RDS::DBSnapshot':            ('RDS', 'RDS — Snapshots'),
    'AWS::RDS::DBClusterSnapshot':     ('RDS', 'RDS — Cluster Snapshots'),
    'AWS::RDS::DBSubnetGroup':         ('RDS', 'RDS — Subnet Groups'),
    'AWS::RDS::EventSubscription':     ('RDS', 'RDS — Event Subscriptions'),
    # Lambda
    'AWS::Lambda::Function':           ('Lambda', 'Lambda — Functions'),
    # EKS
    'AWS::EKS::Cluster':               ('EKS', 'EKS — Clusters'),
    'AWS::EKS::FargateProfile':        ('EKS', 'EKS — Fargate Profiles'),
    'AWS::EKS::Addon':                 ('EKS', 'EKS — Add-ons'),
    # ECS
    'AWS::ECS::Cluster':               ('ECS', 'ECS — Clusters'),
    'AWS::ECS::TaskDefinition':        ('ECS', 'ECS — Task Definitions'),
    'AWS::ECS::Service':               ('ECS', 'ECS — Services'),
    # ECR
    'AWS::ECR::Repository':            ('ECR', 'ECR — Repositories'),
    'AWS::ECR::PublicRepository':      ('ECR', 'ECR — Public Repositories'),
    'AWS::ECR::RegistryPolicy':        ('ECR', 'ECR — Registry Policies'),
    # Elastic Beanstalk
    'AWS::ElasticBeanstalk::Application': ('ElasticBeanstalk', 'Elastic Beanstalk — Applications'),
    'AWS::ElasticBeanstalk::ApplicationVersion': ('ElasticBeanstalk', 'Elastic Beanstalk — App Versions'),
    'AWS::ElasticBeanstalk::Environment': ('ElasticBeanstalk', 'Elastic Beanstalk — Environments'),
    # ELB
    'AWS::ElasticLoadBalancing::LoadBalancer': ('ELB', 'ELB — Classic Load Balancers'),
    'AWS::ElasticLoadBalancingV2::LoadBalancer': ('ELBv2', 'ELBv2 — App / Network LBs'),
    'AWS::ElasticLoadBalancingV2::Listener':     ('ELBv2', 'ELBv2 — Listeners'),
    # CloudFront (global)
    'AWS::CloudFront::Distribution':   ('CloudFront', 'CloudFront — Distributions'),
    'AWS::CloudFront::StreamingDistribution': ('CloudFront', 'CloudFront — Streaming Distributions'),
    # CloudTrail
    'AWS::CloudTrail::Trail':          ('CloudTrail', 'CloudTrail — Trails'),
    # CloudWatch
    'AWS::CloudWatch::Alarm':          ('CloudWatch', 'CloudWatch — Alarms'),
    # CloudFormation
    'AWS::CloudFormation::Stack':      ('CloudFormation', 'CloudFormation — Stacks'),
    # CodeBuild / CodePipeline
    'AWS::CodeBuild::Project':         ('CodeBuild', 'CodeBuild — Projects'),
    'AWS::CodePipeline::Pipeline':     ('CodePipeline', 'CodePipeline — Pipelines'),
    # DynamoDB
    'AWS::DynamoDB::Table':            ('DynamoDB', 'DynamoDB — Tables'),
    # Elasticsearch / OpenSearch
    'AWS::Elasticsearch::Domain':      ('OpenSearch', 'Elasticsearch — Domains'),
    'AWS::OpenSearch::Domain':         ('OpenSearch', 'OpenSearch — Domains'),
    # KMS
    'AWS::KMS::Key':                   ('KMS', 'KMS — Keys'),
    'AWS::KMS::Alias':                 ('KMS', 'KMS — Aliases'),
    # Kinesis
    'AWS::Kinesis::Stream':            ('Kinesis', 'Kinesis — Streams'),
    'AWS::KinesisFirehose::DeliveryStream': ('Kinesis', 'Kinesis Firehose — Delivery Streams'),
    # MSK
    'AWS::MSK::Cluster':               ('MSK', 'MSK — Kafka Clusters'),
    # Redshift
    'AWS::Redshift::Cluster':          ('Redshift', 'Redshift — Clusters'),
    'AWS::Redshift::ClusterSnapshot':  ('Redshift', 'Redshift — Snapshots'),
    # SageMaker
    'AWS::SageMaker::NotebookInstance': ('SageMaker', 'SageMaker — Notebook Instances'),
    'AWS::SageMaker::Model':            ('SageMaker', 'SageMaker — Models'),
    'AWS::SageMaker::EndpointConfig':   ('SageMaker', 'SageMaker — Endpoint Configs'),
    'AWS::SageMaker::Endpoint':         ('SageMaker', 'SageMaker — Endpoints'),
    # Secrets Manager
    'AWS::SecretsManager::Secret':     ('SecretsManager', 'Secrets Manager — Secrets'),
    # SNS / SQS
    'AWS::SNS::Topic':                 ('SNS', 'SNS — Topics'),
    'AWS::SQS::Queue':                 ('SQS', 'SQS — Queues'),
    # SSM
    'AWS::SSM::ManagedInstanceInventory': ('SSM', 'SSM — Managed Instances'),
    'AWS::SSM::PatchCompliance':        ('SSM', 'SSM — Patch Compliance'),
    'AWS::SSM::AssociationCompliance':  ('SSM', 'SSM — Association Compliance'),
    'AWS::SSM::FileData':               ('SSM', 'SSM — File Data'),
    # WAF / WAFv2 (global)
    'AWS::WAF::WebACL':                ('WAF', 'WAF — Web ACLs'),
    'AWS::WAF::RuleGroup':             ('WAF', 'WAF — Rule Groups'),
    'AWS::WAF::Rule':                  ('WAF', 'WAF — Rules'),
    'AWS::WAFv2::WebACL':              ('WAFv2', 'WAFv2 — Web ACLs'),
    'AWS::WAFv2::RuleGroup':           ('WAFv2', 'WAFv2 — Rule Groups'),
    'AWS::WAFv2::IPSet':               ('WAFv2', 'WAFv2 — IP Sets'),
    'AWS::WAFv2::RegexPatternSet':     ('WAFv2', 'WAFv2 — Regex Pattern Sets'),
    'AWS::WAFv2::ManagedRuleSet':      ('WAFv2', 'WAFv2 — Managed Rule Sets'),
    # Route 53 (global)
    'AWS::Route53::HostedZone':        ('Route53', 'Route 53 — Hosted Zones'),
    'AWS::Route53Resolver::ResolverRule': ('Route53', 'Route 53 Resolver — Rules'),
    'AWS::Route53Resolver::ResolverRuleAssociation': ('Route53', 'Route 53 Resolver — Rule Associations'),
    # ACM (global)
    'AWS::ACM::Certificate':           ('ACM', 'ACM — Certificates'),
    # Auto Scaling
    'AWS::AutoScaling::AutoScalingGroup':      ('AutoScaling', 'Auto Scaling — Groups'),
    'AWS::AutoScaling::LaunchConfiguration':   ('AutoScaling', 'Auto Scaling — Launch Configurations'),
    'AWS::AutoScaling::ScalingPolicy':         ('AutoScaling', 'Auto Scaling — Scaling Policies'),
    'AWS::AutoScaling::ScheduledAction':       ('AutoScaling', 'Auto Scaling — Scheduled Actions'),
    'AWS::AutoScaling::WarmPool':              ('AutoScaling', 'Auto Scaling — Warm Pools'),
    # API Gateway
    'AWS::ApiGateway::RestApi':        ('APIGateway', 'API Gateway — REST APIs'),
    'AWS::ApiGateway::Stage':          ('APIGateway', 'API Gateway — Stages'),
    'AWS::ApiGatewayV2::Api':          ('APIGateway', 'API Gateway v2 — APIs'),
    'AWS::ApiGatewayV2::Stage':        ('APIGateway', 'API Gateway v2 — Stages'),
    # GuardDuty
    'AWS::GuardDuty::Detector':        ('GuardDuty', 'GuardDuty — Detectors'),
    'AWS::GuardDuty::IPSet':           ('GuardDuty', 'GuardDuty — IP Sets'),
    'AWS::GuardDuty::ThreatIntelSet':  ('GuardDuty', 'GuardDuty — Threat Intel Sets'),
    # Config
    'AWS::Config::ConfigRule':         ('Config', 'Config — Rules'),
    'AWS::Config::ConformancePack':    ('Config', 'Config — Conformance Packs'),
    'AWS::Config::OrganizationConfigRule': ('Config', 'Config — Org Rules'),
    # Backup
    'AWS::Backup::BackupPlan':         ('Backup', 'Backup — Plans'),
    'AWS::Backup::BackupSelection':    ('Backup', 'Backup — Selections'),
    'AWS::Backup::BackupVault':        ('Backup', 'Backup — Vaults'),
    'AWS::Backup::RecoveryPoint':      ('Backup', 'Backup — Recovery Points'),
    # EFS
    'AWS::EFS::FileSystem':            ('EFS', 'EFS — File Systems'),
    'AWS::EFS::AccessPoint':           ('EFS', 'EFS — Access Points'),
    # FSx
    'AWS::FSx::FileSystem':            ('FSx', 'FSx — File Systems'),
    # Network Firewall
    'AWS::NetworkFirewall::Firewall':        ('NetworkFirewall', 'Network Firewall — Firewalls'),
    'AWS::NetworkFirewall::FirewallPolicy':  ('NetworkFirewall', 'Network Firewall — Policies'),
    'AWS::NetworkFirewall::RuleGroup':       ('NetworkFirewall', 'Network Firewall — Rule Groups'),
    # DAX
    'AWS::DAX::Cluster':               ('DAX', 'DAX — Clusters'),
    # Glue
    'AWS::Glue::Job':                  ('Glue', 'Glue — Jobs'),
    # Step Functions
    'AWS::StepFunctions::Activity':    ('StepFunctions', 'Step Functions — Activities'),
    'AWS::StepFunctions::StateMachine': ('StepFunctions', 'Step Functions — State Machines'),
    # EventBridge
    'AWS::Events::Rule':               ('EventBridge', 'EventBridge — Rules'),
    'AWS::Events::EventBus':           ('EventBridge', 'EventBridge — Event Buses'),
    # Athena
    'AWS::Athena::WorkGroup':          ('Athena', 'Athena — Workgroups'),
    'AWS::Athena::DataCatalog':        ('Athena', 'Athena — Data Catalogs'),
    # AccessAnalyzer
    'AWS::AccessAnalyzer::Analyzer':   ('AccessAnalyzer', 'IAM Access Analyzer — Analyzers'),
    # AppConfig
    'AWS::AppConfig::Application':     ('AppConfig', 'AppConfig — Applications'),
    # Amplify
    'AWS::Amplify::App':               ('Amplify', 'Amplify — Apps'),
    # CodeArtifact
    'AWS::CodeArtifact::Repository':   ('CodeArtifact', 'CodeArtifact — Repositories'),
    # Transfer Family
    'AWS::Transfer::Server':           ('Transfer', 'Transfer Family — Servers'),
    # MSK (duplicate key safety)
    'AWS::AmazonMQ::Broker':           ('AmazonMQ', 'Amazon MQ — Brokers'),
    # Lightsail (not recorded by Config, listed for completeness)
}

def _service_label(resource_type: str) -> str:
    """Return the short service label (e.g. 'EC2', 'S3', 'IAM')."""
    return _SERVICE_MAP.get(resource_type, ('Other', resource_type))[0]

def _display_name(resource_type: str) -> str:
    """Return the human-readable display name for a resource type."""
    return _SERVICE_MAP.get(resource_type, ('Other', resource_type))[1]


# ---------------------------------------------------------------------------
# Status helpers
# ---------------------------------------------------------------------------

def _write_status(account: str, request_id: str, status: str,
                  error: str = None, progress: str = None):
    """Write inventory/{account}/status.json."""
    payload = {
        'status':      status,   # pending | running | done | failed
        'requestId':   request_id,
        'generatedAt': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'error':       error,
        'progress':    progress,
        'version':     INVENTORY_VERSION,
    }
    s3.put_object(
        Bucket=BUCKET,
        Key=f'inventory/{account}/status.json',
        Body=json.dumps(payload),
        ContentType='application/json',
    )


# ---------------------------------------------------------------------------
# S3 helpers
# ---------------------------------------------------------------------------

def _load_json(key: str, default=None):
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        return json.loads(obj['Body'].read().decode())
    except Exception as exc:
        code = getattr(exc, 'response', {}).get('Error', {}).get('Code', '')
        if code in ('NoSuchKey', '404'):
            return default
        raise


def _load_accounts() -> list:
    """Return [{id, name}] from summaries/accounts.json, or fall back to
    AWS Organizations if the file is not yet present."""
    data = _load_json('summaries/accounts.json', default=None)
    if data is not None:
        return data
    logger.info('summaries/accounts.json not found — querying Organizations')
    org = boto3.client('organizations')
    accounts = []
    paginator = org.get_paginator('list_accounts')
    for page in paginator.paginate():
        for a in page['Accounts']:
            if a.get('Status') == 'ACTIVE':
                accounts.append({'id': a['Id'], 'name': a.get('Name', a['Id'])})
    return accounts


# ---------------------------------------------------------------------------
# Cross-account credentials
# ---------------------------------------------------------------------------

def _get_session_credentials(account_id: str, own_account_id: str) -> dict | None:
    """Assume InventoryReadOnlyRole in a member account.
    Returns a dict of {aws_access_key_id, aws_secret_access_key,
    aws_session_token} or None if the own account is requested (no assumption
    needed) or if the assume fails.
    """
    if account_id == own_account_id:
        return None   # use the Lambda execution role directly

    role_arn = f'arn:aws:iam::{account_id}:role/{INVENTORY_READER_ROLE_NAME}'
    try:
        resp  = sts.assume_role(
            RoleArn         = role_arn,
            RoleSessionName = f'InventoryLambda-{account_id}',
            DurationSeconds = 900,
            # ExternalId matches the condition in the member-account trust policy
            # deployed by securityhub-inventory-member-role.yaml.
            ExternalId      = f'{account_id}-inventory-reader',
        )
        creds = resp['Credentials']
        return {
            'aws_access_key_id':     creds['AccessKeyId'],
            'aws_secret_access_key': creds['SecretAccessKey'],
            'aws_session_token':     creds['SessionToken'],
        }
    except Exception as exc:
        logger.warning('AssumeRole failed for %s: %s', role_arn, exc)
        return None


def _config_client(region: str, creds: dict | None):
    """Build a boto3 Config client — with assumed-role creds if provided."""
    if creds:
        return boto3.client('config', region_name=region, **creds)
    return boto3.client('config', region_name=region)


# ---------------------------------------------------------------------------
# Region discovery
# ---------------------------------------------------------------------------

def _get_active_regions(creds: dict | None) -> list[str]:
    """Return list of regions where Config is recording for the account.
    Falls back to a safe default set if the DescribeConfigurationRecorders
    call fails or returns nothing.
    Always includes 'us-east-1' for global resource types.
    """
    _DEFAULT_REGIONS = [
        'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
        'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
        'eu-north-1', 'ap-southeast-1', 'ap-southeast-2',
        'ap-northeast-1', 'ap-northeast-2', 'ap-south-1',
        'ca-central-1', 'sa-east-1', 'af-south-1', 'me-south-1',
    ]
    regions: set[str] = {'us-east-1'}   # always include for global types

    # Use EC2 DescribeRegions to get all opted-in regions for the account
    try:
        ec2_kwargs: dict = {'region_name': 'us-east-1'}
        if creds:
            ec2_kwargs.update(creds)
        ec2       = boto3.client('ec2', **ec2_kwargs)
        paginator = ec2.get_paginator('describe_regions')
        for page in paginator.paginate(Filters=[{'Name': 'opt-in-status',
                                                  'Values': ['opt-in-not-required',
                                                             'opted-in']}]):
            for r in page['Regions']:
                regions.add(r['RegionName'])
        logger.info('Found %d active regions', len(regions))
    except Exception as exc:
        logger.warning('DescribeRegions failed: %s — using default region list', exc)
        regions.update(_DEFAULT_REGIONS)

    return sorted(regions)


# ---------------------------------------------------------------------------
# Config resource discovery
# ---------------------------------------------------------------------------

def _list_resources_in_region(config_client, resource_type: str) -> list[dict]:
    """Paginate ListDiscoveredResources for one resource type in one region.
    Returns list of {resourceId, resourceName} dicts.
    """
    resources: list[dict] = []
    kwargs = {
        'resourceType':       resource_type,
        'includeDeletedResources': False,
    }
    while True:
        try:
            resp = config_client.list_discovered_resources(**kwargs)
        except botocore.exceptions.ClientError as exc:
            code = exc.response.get('Error', {}).get('Code', '')
            if code in ('NoSuchConfigurationRecorderException',
                        'AccessDeniedException', 'UnauthorizedException',
                        'OptInRequired'):
                # Config not enabled or no access in this region/account
                return resources
            logger.warning('ListDiscoveredResources error type=%s: %s',
                           resource_type, exc)
            return resources
        except Exception as exc:
            logger.warning('ListDiscoveredResources error type=%s: %s',
                           resource_type, exc)
            return resources

        for r in resp.get('resourceIdentifiers', []):
            resources.append({
                'resourceId':   r.get('resourceId', ''),
                'resourceName': r.get('resourceName') or r.get('resourceId', ''),
            })

        next_token = resp.get('nextToken')
        if not next_token:
            break
        kwargs['nextToken'] = next_token

    return resources


def _get_supported_resource_types(config_client) -> list[str]:
    """Return all resource types the Config recorder supports in this region.
    This avoids calling ListDiscoveredResources for types that are not
    recorded, which would always return empty.
    """
    types: list[str] = []
    kwargs: dict     = {}
    while True:
        try:
            resp = config_client.list_discovered_resources(
                resourceType='AWS::Config::ResourceCompliance',
                **kwargs,
            )
        except Exception:
            break
        next_token = resp.get('nextToken')
        if not next_token:
            break
        kwargs['nextToken'] = next_token

    # GetDiscoveredResourceCounts gives us the resource types actually recorded
    try:
        resp = config_client.get_discovered_resource_counts()
        for item in resp.get('resourceCounts', []):
            if item.get('count', 0) > 0:
                types.append(item['resourceType'])
    except Exception:
        # Fall back to querying every known type from _SERVICE_MAP
        types = list(_SERVICE_MAP.keys())

    return types


def discover_resources_for_account(account_id: str, account_name: str,
                                    own_account_id: str) -> list[dict]:
    """Discover ALL resources in all regions for one account.

    Returns a flat list of resource dicts:
      { resourceType, resourceName, resourceId, region,
        accountId, accountName, service, displayName }
    """
    creds   = _get_session_credentials(account_id, own_account_id)
    regions = _get_active_regions(creds)

    # Collect all resource types we want to query — union of _SERVICE_MAP keys
    all_known_types   = set(_SERVICE_MAP.keys())
    global_types      = GLOBAL_RESOURCE_TYPES & all_known_types
    regional_types    = all_known_types - global_types

    resources: list[dict] = []
    seen: set[tuple]      = set()   # (accountId, resourceType, resourceId)

    def _add(rtype: str, region: str, raw_resources: list[dict]):
        for r in raw_resources:
            rid  = r['resourceId']
            key  = (account_id, rtype, rid)
            if key in seen:
                continue
            seen.add(key)
            resources.append({
                'resourceType': rtype,
                'resourceName': r.get('resourceName') or rid,
                'resourceId':   rid,
                'region':       region,
                'accountId':    account_id,
                'accountName':  account_name,
                'service':      _service_label(rtype),
                'displayName':  _display_name(rtype),
            })

    # ── Global types — always query us-east-1 ────────────────────────────
    cfg_global = _config_client('us-east-1', creds)
    for rtype in sorted(global_types):
        raw = _list_resources_in_region(cfg_global, rtype)
        if raw:
            _add(rtype, 'global', raw)

    # ── Regional types — query each active region in parallel ─────────────
    # Build a task list: (region, resource_type) pairs
    # We skip us-east-1 global types already collected above
    tasks: list[tuple[str, str]] = []
    for region in regions:
        cfg = _config_client(region, creds)
        # Discover which types are actually recorded in this region
        try:
            resp  = cfg.get_discovered_resource_counts()
            types_with_data = {
                item['resourceType']
                for item in resp.get('resourceCounts', [])
                if item.get('count', 0) > 0
            }
        except Exception:
            # If the call fails, try all known regional types
            types_with_data = regional_types

        for rtype in regional_types:
            if rtype in types_with_data:
                tasks.append((region, rtype, cfg))

    # Run regional queries concurrently — max 20 threads
    def _fetch(region: str, rtype: str, cfg) -> tuple[str, str, list]:
        return region, rtype, _list_resources_in_region(cfg, rtype)

    with ThreadPoolExecutor(max_workers=20) as pool:
        futures = {pool.submit(_fetch, reg, rtype, cfg): (reg, rtype)
                   for reg, rtype, cfg in tasks}
        for future in as_completed(futures):
            try:
                region, rtype, raw = future.result()
                if raw:
                    _add(rtype, region, raw)
            except Exception as exc:
                reg, rtype = futures[future]
                logger.warning('Discovery error region=%s type=%s: %s',
                               reg, rtype, exc)

    logger.info('account=%s discovered=%d resources across %d regions',
                account_id, len(resources), len(regions))
    return resources


# ---------------------------------------------------------------------------
# Inventory builders
# ---------------------------------------------------------------------------

def build_inventory_from_resources(account_id: str, account_name: str,
                                    resources: list[dict]) -> dict:
    """Aggregate a flat resource list into the inventory output shape.

    Returns:
      { accountId, accountName, lastGenerated, totalResources,
        services[], resources[] }
    """
    # Group by resourceType
    by_type: dict[str, list] = defaultdict(list)
    for r in resources:
        by_type[r['resourceType']].append(r)

    services: list[dict] = []
    for rtype, rlist in sorted(by_type.items(),
                                key=lambda kv: -len(kv[1])):
        regions = sorted({r['region'] for r in rlist})
        services.append({
            'resourceType':  rtype,
            'service':       _service_label(rtype),
            'displayName':   _display_name(rtype),
            'resourceCount': len(rlist),
            'regions':       regions,
        })

    # Resources sorted by service then resourceType then resourceName
    sorted_resources = sorted(
        resources,
        key=lambda r: (r['service'], r['resourceType'], r.get('resourceName', '')),
    )

    return {
        'accountId':      account_id,
        'accountName':    account_name,
        'lastGenerated':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'totalResources': len(resources),
        'services':       services,
        'resources':      sorted_resources,
    }


def build_service_summary(resources: list[dict]) -> list[dict]:
    """Return a service-wise resource count summary sorted by count desc.

    [{ service, resourceCount, resourceTypes: [{ resourceType, displayName,
                                                  count }] }]
    """
    svc_map: dict[str, dict] = {}
    for r in resources:
        svc   = r['service']
        rtype = r['resourceType']
        if svc not in svc_map:
            svc_map[svc] = {'service': svc, 'resourceCount': 0, 'types': {}}
        svc_map[svc]['resourceCount'] += 1
        svc_map[svc]['types'][rtype] = svc_map[svc]['types'].get(rtype, 0) + 1

    summary: list[dict] = []
    for svc, data in sorted(svc_map.items(), key=lambda kv: -kv[1]['resourceCount']):
        types_list = sorted(
            [{'resourceType': rt, 'displayName': _display_name(rt), 'count': cnt}
             for rt, cnt in data['types'].items()],
            key=lambda x: -x['count'],
        )
        summary.append({
            'service':       svc,
            'resourceCount': data['resourceCount'],
            'resourceTypes': types_list,
        })
    return summary


# ---------------------------------------------------------------------------
# CSV builder
# ---------------------------------------------------------------------------

def build_csv(resources: list[dict]) -> bytes:
    """Build a flat CSV of all resources.

    Columns: service, resourceType, displayName, resourceName, resourceId,
             region, accountId, accountName
    """
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Service', 'ResourceType', 'DisplayName',
        'ResourceName', 'ResourceId',
        'Region', 'AccountId', 'AccountName',
    ])
    sorted_rows = sorted(
        resources,
        key=lambda r: (r.get('service', ''), r.get('resourceType', ''),
                       r.get('resourceName', '')),
    )
    for r in sorted_rows:
        writer.writerow([
            r.get('service',       ''),
            r.get('resourceType',  ''),
            r.get('displayName',   _display_name(r.get('resourceType', ''))),
            r.get('resourceName',  ''),
            r.get('resourceId',    ''),
            r.get('region',        ''),
            r.get('accountId',     ''),
            r.get('accountName',   ''),
        ])
    return output.getvalue().encode('utf-8')


# ---------------------------------------------------------------------------
# S3 writers
# ---------------------------------------------------------------------------

def _write_inventory(account: str, inventory: dict, csv_bytes: bytes):
    """Write latest.json and latest.csv for one account."""
    s3.put_object(
        Bucket=BUCKET,
        Key=f'inventory/{account}/latest.json',
        Body=json.dumps(inventory),
        ContentType='application/json',
    )
    s3.put_object(
        Bucket=BUCKET,
        Key=f'inventory/{account}/latest.csv',
        Body=csv_bytes,
        ContentType='text/csv',
    )
    logger.info('Wrote inventory/%s: %d resources', account,
                inventory.get('totalResources', 0))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    """Invoked asynchronously by the API Lambda (InvocationType='Event').

    Event shape:
      { "account": "123456789012" | "all", "requestId": "<string>" }
    """
    t_start    = time.perf_counter()
    account_id = (event.get('account') or 'all').strip()
    request_id = event.get('requestId', 'unknown')

    logger.info('inventory: account=%s requestId=%s version=%s',
                account_id, request_id, INVENTORY_VERSION)

    _write_status(account_id, request_id, 'pending',
                  progress='Initialising')

    own_account_id = boto3.client('sts').get_caller_identity()['Account']
    error_msg      = None

    try:
        accounts   = _load_accounts()
        name_map   = {a['id']: a.get('name', a['id']) for a in accounts}

        if account_id == 'all':
            # ── All accounts: discover per-account then roll up ───────────
            all_resources: list[dict] = []
            total_accounts            = len(accounts)

            for idx, acct in enumerate(accounts, 1):
                aid   = acct['id']
                aname = acct.get('name', aid)
                _write_status(account_id, request_id, 'running',
                              progress=f'Scanning {aname} ({idx}/{total_accounts})')
                try:
                    acct_resources = discover_resources_for_account(
                        aid, aname, own_account_id)
                    inventory  = build_inventory_from_resources(
                        aid, aname, acct_resources)
                    csv_bytes  = build_csv(acct_resources)
                    _write_inventory(aid, inventory, csv_bytes)
                    all_resources.extend(acct_resources)
                except Exception as exc:
                    logger.exception('inventory: failed for account %s: %s', aid, exc)

            # Org-wide rollup
            _write_status(account_id, request_id, 'running',
                          progress='Building org-wide rollup')
            all_inventory = build_inventory_from_resources(
                'all', 'All Accounts', all_resources)
            all_inventory['accountsIncluded'] = len(accounts)
            all_inventory['serviceSummary']   = build_service_summary(all_resources)
            all_csv = build_csv(all_resources)
            _write_inventory('all', all_inventory, all_csv)

        else:
            # ── Single account ────────────────────────────────────────────
            aname = name_map.get(account_id, account_id)
            _write_status(account_id, request_id, 'running',
                          progress=f'Scanning {aname}')
            resources = discover_resources_for_account(
                account_id, aname, own_account_id)
            inventory = build_inventory_from_resources(
                account_id, aname, resources)
            inventory['serviceSummary'] = build_service_summary(resources)
            csv_bytes = build_csv(resources)
            _write_inventory(account_id, inventory, csv_bytes)

        _write_status(account_id, request_id, 'done')

    except Exception as exc:
        error_msg = str(exc)
        logger.exception('inventory: FAILED account=%s: %s', account_id, exc)
        _write_status(account_id, request_id, 'failed', error=error_msg)

    duration = round(time.perf_counter() - t_start, 1)
    logger.info('inventory: total=%.1fs account=%s', duration, account_id)

    return {
        'statusCode':      200 if not error_msg else 500,
        'account':         account_id,
        'error':           error_msg,
        'durationSeconds': duration,
        'version':         INVENTORY_VERSION,
    }
