securityhub_counts_by_account = defaultdict(int)
inspector_counts_by_account = defaultdict(int)

for finding in findings:
    securityhub_counts_by_account[
        finding.get('AwsAccountId', 'UNKNOWN')
    ] += 1

for finding in inspector_findings:
    inspector_counts_by_account[
        finding.get('AwsAccountId', 'UNKNOWN')
    ] += 1

split_account_ids = sorted(
    set(securityhub_counts_by_account)
    | set(inspector_counts_by_account)
)

for account_id in split_account_ids:
    logger.info(
        'finding_split account=%s securityhub=%d inspector=%d',
        account_id,
        securityhub_counts_by_account.get(account_id, 0),
        inspector_counts_by_account.get(account_id, 0),
    )