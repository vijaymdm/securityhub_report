# Security Hub Compliance Dashboard — Project State
*Last updated: September 2026*

---

## 1. Current File Versions

| File | Version | Status |
|------|---------|--------|
| `aggregator_lambda.py` | **1.6.1** | Validated, prod-ready — deploy pending |
| `api_lambda.py` | **1.5.4** | Prod-ready — deploy pending |
| `report_generator_lambda.py` | **1.0.1** | Prod-ready |
| `inventory_lambda.py` | **2.0.0** | Prod-ready — deploy pending |
| `securityhub-dashboard.jsx` | **1.5.7** | Prod-ready — rebuild + redeploy pending |
| `cfn/securityhub-dashboard-main.yaml` | — | Updated for inventory v2.0.0 — deploy pending |
| `cfn/securityhub-member-role.yaml` | — | Up to date (TrustedAdvisorReadOnlyRole) |
| `cfn/securityhub-inventory-member-role.yaml` | — | **New** — InventoryReadOnlyRole StackSet template |
| `cfn/deploy.ps1` | — | Up to date |

### Backups present in `backups/`
```
aggregator_lambda_v1.5.4.py
aggregator_lambda_v1.5.6.py
aggregator_lambda_v1.5.7.py
aggregator_lambda_v1.6.0.py          ← last prod-deployed version
api_lambda_v1.4.2.py
api_lambda_v1.5.0.py
api_lambda_v1.5.2.py                 ← last prod-deployed version
inventory_lambda_v1.0.0.py
report_generator_lambda_v1.0.0.py
securityhub-dashboard_v1.5.0.jsx
securityhub-dashboard_v1.5.2.jsx
securityhub-dashboard_v1.5.5.jsx     ← last prod-deployed version
```

**Missing backups** (need to be created before next deploy):
- `aggregator_lambda_v1.6.1.py`
- `api_lambda_v1.5.4.py`
- `inventory_lambda_v2.0.0.py`
- `securityhub-dashboard_v1.5.7.jsx`

---

## 2. Architecture Overview

```
EventBridge (daily 03:00 UTC)
        │
        ▼
AggregatorLambda (eu-west-1, Python 3.12)
  ├── Fetches ALL open SH findings (no ProductArn filter)
  ├── Splits SH vs Inspector in Python via is_inspector_finding()
  ├── Writes summaries/{account}/latest.json + findings.json
  ├── Writes summaries/all/latest.json + findings.json
  ├── Writes summaries/accounts.json + version.json
  ├── Writes snapshots/{date}/findings.json  (day-over-day delta)
  ├── Writes trusted-advisor/{account}/latest.json
  ├── Writes inspector/{account}/latest.json
  └── Sends SES email digest (new CRITICAL/HIGH findings)

User → CloudFront → S3 (UI bucket: securityhub-dashboard-site)
                           │
                    React Dashboard (securityhub-dashboard.jsx)
                           │
                    API Gateway (HTTP, JWT/Cognito auth)
                           │
                    ApiLambda (eu-west-1, Python 3.12)
                      ├── GET /summary, /findings, /accounts, /version
                      ├── GET /trusted-advisor, /inspector
                      ├── POST /generate-report → ReportGeneratorLambda (async)
                      ├── GET /report-status, /report-url
                      ├── POST /generate-inventory → InventoryLambda (async)
                      ├── GET /inventory-status, /inventory
                      └── All reads from S3 data bucket

ReportGeneratorLambda (on-demand, invoked async)
  └── Reads summaries/ + snapshots/ → writes reports/{account}/latest.{pdf,csv,xlsx}

InventoryLambda (on-demand, invoked async)
  └── Reads summaries/{account}/findings.json → writes inventory/{account}/latest.json
```

**Deployment region:** `eu-west-1` for all resources.
**Global service exceptions:** SES → `us-east-1`, Support API (Trusted Advisor) → `us-east-1`.

---

## 3. Decisions Made

### Data separation — Security Hub vs Inspector
- **Decision:** Fetch all findings in one `GetFindings` call (no `ProductArn` filter at API level). Split Security Hub vs Inspector in Python using `is_inspector_finding()`.
- **Reason:** AWS Security Hub API rejects `NOT_CONTAINS` comparison on `ProductArn`. A single query avoids `InvalidInputException` and is simpler to maintain.
- **Inspector identification signals (4, any one sufficient):**
  1. `ProductArn` ends with `::product/aws/inspector`
  2. `ProductFields["aws/inspector/ProductVersion"] == "2"`
  3. `ProductName == "inspector"` AND `CompanyName == "amazon"` AND `GeneratorId == "awsinspector"`
  4. `GeneratorId` starts with `aws/inspector` or `awsinspector`
- **Warning log** emitted when a finding has partial Inspector signals but wasn't classified — visible in CloudWatch for misclassification debugging.

### Control ID extraction
- **Decision:** `_extract_control_id()` accepts `ProductFields.ControlId` (consolidated controls, e.g. `EC2.1`) OR `GeneratorId` with `security-control/` prefix (older standards-specific controls). Full ARN-style `GeneratorId` values (GuardDuty, Macie) are excluded.
- **Reason:** v1.5.8 removed the GeneratorId fallback entirely which broke top-controls display. v1.5.9 restored it with the `security-control/` prefix guard.

### Report generation — separate Lambda
- **Decision:** Report generation (PDF/CSV/Excel) is a standalone `report_generator_lambda` invoked asynchronously on user demand. Not part of the aggregator run.
- **Reason:** Report building for 80+ accounts with `fpdf2` + `openpyxl` caused aggregator timeouts.

### Inventory — separate Lambda
- **Decision:** Account inventory is a standalone `inventory_lambda` invoked asynchronously from the dashboard.
- **Reason:** Same timeout concern. Inventory Lambda reads from already-written `findings.json` files — no new Security Hub API calls.

### Score calculation
- **Decision:** Compliance score uses AWS's official formula: `(passed controls / enabled controls) × 100`. Controls with `NOT_AVAILABLE` status excluded from both numerator and denominator. Worst status per control per account is used when multiple findings exist.
- **Reason:** Matches what the AWS Security Hub console shows.

### `condense_finding()` shape
- **Decision:** Added `source: "securityhub"` and `resourceType` fields in v1.6.1.
- **Reason:** `source` field provides defence-in-depth so the API and dashboard can filter out any misclassified Inspector findings that leaked into `findings.json` in pre-fix data.

### SES client region
- **Decision:** SES client always targets `us-east-1`, regardless of Lambda deployment region.
- **Reason:** SES `SendEmail` is a global service; using any other region endpoint causes `EndpointResolutionError`. This was accidentally changed to `eu-west-1` in the working file and fixed in the v1.6.1 validation.

### Trusted Advisor cross-account access
- **Decision:** A lightweight IAM role `TrustedAdvisorReadOnlyRole` is deployed to every member account via CloudFormation StackSet. The aggregator assumes this role per-account to call `DescribeTrustedAdvisorChecks`.
- **Reason:** AWS Support API requires account-local credentials — delegated admin access doesn't extend to it.

---

## 4. Current State — What Is and Isn't Deployed

### Deployed in AWS (last known good state)
- `aggregator_lambda.py` **v1.6.0** — running in `securityhub-aggregator-prod`
- `api_lambda.py` **v1.5.2** — running in `securityhub-api-prod`
- `report_generator_lambda.py` **v1.0.1** — running in `securityhub-report-generator-prod`
- `inventory_lambda.py` **v1.0.0** — running in `securityhub-inventory-prod`
- `securityhub-dashboard.jsx` **v1.5.5** — last known deployed to CloudFront

### Pending deployment (code changed locally, not yet in AWS)
| File | Local | Deployed | Changes |
|------|-------|----------|---------|
| `aggregator_lambda.py` | 1.6.1 | 1.6.0 | SES region fix, version constant fix, hardened Inspector classifier, source field in condense_finding, per-account split logging |
| `api_lambda.py` | 1.5.4 | 1.5.2 | v1.5.3: `/findings` source filter; v1.5.4: `GET /inventory-csv` presigned download URL route |
| `inventory_lambda.py` | 2.0.0 | 1.0.0 | Full rewrite — live AWS Config resource discovery across all regions, cross-account role assumption, global services, pagination, dedup, CSV export, service summary |
| `securityhub-dashboard.jsx` | 1.5.7 | 1.5.5 | Fixed severity counts not updating on account switch (1.5.6), fixed white-screen crash from Set in dep array (1.5.7), selectedIdsKey memo |
| `cfn/securityhub-dashboard-main.yaml` | updated | deployed | InventoryRole policy expanded (Config, EC2, STS, Orgs); InventoryLambda memory 512→1024, timeout 300→840; `INVENTORY_READER_ROLE_NAME` env var added; `InventoryRoleArn` output added |
| `cfn/securityhub-inventory-member-role.yaml` | **new** | not deployed | InventoryReadOnlyRole StackSet template for all member accounts |

---

## 5. Work In Progress

### Dashboard `securityhub-dashboard.jsx` v1.5.6 → 1.5.7 (local, not deployed)

**v1.5.6** fixed three bugs in the summary fetch `useEffect`:
1. Stale `summaryCache` closure in multi-select branch — aggregate computed from snapshot, not live data
2. Multi branch `newCache` only contained newly fetched entries; cached accounts dropped from aggregate
3. Dependency array was `[apiAccountId]` only — adding accounts while staying in multi mode never re-ran the effect

**v1.5.7** fixed the regression introduced by v1.5.6:
- Adding `selectedIds` (a `Set`) directly to the `useEffect` dep array caused an infinite render loop (React `Object.is()` always fails for Sets → effect runs every render → `setLoading(true)` → re-render → loop → white screen)
- Fix: `selectedIdsKey = useMemo(() => [...selectedIds].sort().join(','), [selectedIds])` — a stable string primitive used as the dependency instead

### Aggregator `aggregator_lambda.py` v1.6.1 (local, not deployed)

Validated prod-ready. Two bugs fixed from v1.6.0:
1. `ses` client was using `region_name='eu-west-1'` (causes email failures) — corrected to `us-east-1`
2. `AGGREGATOR_VERSION` constant was `'1.6.0'` while header said `1.6.1` — aligned to `1.6.1`

### `cfn/securityhub-dashboard-main.yaml` (updated, not deployed)

Changes made for inventory v2.0.0:
- `InventoryRole` policy: added `sts:AssumeRole` on `arn:aws:iam::*:role/InventoryReadOnlyRole`, `sts:GetCallerIdentity`, `config:ListDiscoveredResources`, `config:GetDiscoveredResourceCounts`, `ec2:DescribeRegions`, `organizations:ListAccounts`
- `InventoryLambda` resource: memory `512` → `1024`, timeout `300` → `840`, added `INVENTORY_READER_ROLE_NAME: InventoryReadOnlyRole` env var
- New output `InventoryRoleArn` — required as the `InventoryRoleArn` parameter when deploying the member-account StackSet

### `cfn/securityhub-inventory-member-role.yaml` (new, not deployed)

New StackSet template that deploys `InventoryReadOnlyRole` to every member account. Mirrors `securityhub-member-role.yaml` in structure. Key properties:
- Permissions: `config:ListDiscoveredResources`, `config:GetDiscoveredResourceCounts`, `ec2:DescribeRegions`
- Trust: allows `InventoryRoleArn` principal only; `ExternalId` condition set to `{AccountId}-inventory-reader` (confused-deputy prevention)
- `MaxSessionDuration`: 3600 s

### `inventory_lambda.py` `_get_session_credentials()` (updated)

`sts:AssumeRole` call now passes `ExternalId='{account_id}-inventory-reader'` to satisfy the trust policy condition enforced by the CFN template. Without this the `AssumeRole` call would fail with `AccessDenied` even if the role ARN and principal are correct.

### `inventory_lambda.py` v1.0.0 → v2.0.0 (local, not deployed)

Complete rewrite. Key changes:
- **Live resource discovery** via AWS Config `ListDiscoveredResources` — all resources regardless of Security Hub findings
- **Multi-region**: queries every opted-in region returned by `ec2:DescribeRegions`
- **Global services**: IAM, CloudFront, Route 53, WAF, WAFv2, ACM always queried from `us-east-1` Config recorder
- **Cross-account**: assumes `InventoryReadOnlyRole` in each member account via STS; own account uses execution role directly
- **Full pagination**: no resource cap — all pages consumed via `NextToken`
- **Deduplication**: by `(accountId, resourceType, resourceId)` across regions
- **Concurrent discovery**: `ThreadPoolExecutor(max_workers=20)` for regional queries
- **CSV export**: writes `inventory/{account}/latest.csv` alongside `latest.json`
- **Service summary**: `serviceSummary[]` added to output with per-service and per-type counts
- **Status progress**: status.json now includes `progress` field with human-readable scan stage
- **Schema**: backward-compatible — `services[]` and `resources[]` retained; each resource gains `resourceName`, `service`, `displayName` fields

---

## 6. Open Questions / Items

### HIGH — Must do before next aggregator run
- [ ] **Deploy `aggregator_lambda.py` v1.6.1** — the SES region bug means email digests fail silently on every run until this is deployed
- [ ] **Deploy `securityhub-dashboard.jsx` v1.5.7** — the current deployed version (v1.5.5) has the account-switch bug and the white-screen crash. Users cannot reliably switch accounts.

### MEDIUM — Should do soon
- [ ] **Run the aggregator once** — the dashboard currently shows "No summary available for this account yet" on all tabs because `summaries/all/latest.json` doesn't exist in S3. Trigger manually: `aws lambda invoke --function-name securityhub-aggregator-prod --region eu-west-1 --payload '{}' response.json`
- [ ] **Deploy `inventory_lambda.py` v2.0.0** — complete rewrite; uses live Config-based resource discovery. Requires `InventoryReadOnlyRole` deployed to every member account and Lambda execution role updated with new permissions (see Section 10 below).
- [ ] **Deploy `InventoryReadOnlyRole` CloudFormation StackSet** — use `cfn/securityhub-inventory-member-role.yaml` (new file). Deploy via StackSets with SERVICE_MANAGED permissions targeting all accounts in your Organization. Pass the `InventoryRoleArn` value from the main stack Outputs tab as the `InventoryRoleArn` parameter. Requires AWS Config to be recording in each member account — at minimum `us-east-1` (for global resource types: IAM, CloudFront, Route 53, WAF, ACM).
- [x] ~~**Apply `api_lambda.py` v1.5.3**~~ — `source == 'securityhub'` filter applied to `/findings`. Uses `f.get('source', 'securityhub')` default so pre-v1.6.1 records (no `source` field) are preserved until the aggregator re-runs.
- [ ] **Create missing backups** — `aggregator_lambda_v1.6.1.py`, `api_lambda_v1.5.4.py`, `inventory_lambda_v2.0.0.py`, and `securityhub-dashboard_v1.5.7.jsx` should be created in `backups/` before or alongside the next deploy.

### LOW — Known limitations, no immediate action needed
- [ ] **`fetch_all_compliance_findings()` fetches all ACTIVE findings** regardless of WorkflowStatus — for 80+ accounts this is a large API call. If aggregator timeout becomes an issue, this is the phase to optimise first. Watch `TIMING phase=fetch_all_compliance_findings duration_s=` in CloudWatch.
- [ ] **`summaries/all/findings.json` has no account attribution per finding** — the `all` findings file is a flat concatenation of per-account condensed findings. Each finding does have `accountId` in the condensed shape but it's only populated via `write_daily_snapshot`, not in `write_to_s3`'s `all_condensed`. Drill-down on "All Accounts" view will show findings without account labels in the panel.
- [ ] **Inspector tab shows all-accounts findings capped at 500 per account** — `summarize_inspector_by_account` limits condensed findings to `[:500]` per account. For accounts with very high Inspector finding counts, the tab will be truncated.
- [x] ~~**Inventory Lambda reads from `findings.json`**~~ — resolved in v2.0.0. Inventory now uses live AWS Config discovery and reflects all resources regardless of Security Hub findings.

---

## 7. Known Issues (Closed)

| Issue | Fix applied | Version |
|-------|-------------|---------|
| `InvalidInputException` on aggregator startup — `NOT_CONTAINS` comparison on `ProductArn` | Removed ProductArn API filter, moved to Python-side split | aggregator 1.5.5 |
| Inspector findings appearing in Security Hub severity counts and drill-down | Hardened `is_inspector_finding()` with 4 signals + WARNING log | aggregator 1.6.1 |
| Top failing controls empty after v1.5.8 | Restored `GeneratorId` fallback with `security-control/` prefix guard in `_extract_control_id()` | aggregator 1.5.9 |
| PDF download opening in same tab (CloudFront) | Added `ResponseContentDisposition: attachment` to presigned URL | api 1.5.1 |
| "Could not start report generation: Failed to fetch" | POST timeout raised to 30s; CORS headers updated to allow POST | dashboard 1.5.2/1.5.3 |
| Security Hub severity counts not updating on account switch | Fixed stale closure and missing dependency in `useEffect` | dashboard 1.5.6 |
| White screen when selecting accounts | `selectedIds` Set in dep array caused infinite re-render loop; replaced with `selectedIdsKey` string | dashboard 1.5.7 |
| SES email digest failing silently | `ses` client corrected from `eu-west-1` to `us-east-1` | aggregator 1.6.1 |
| `AGGREGATOR_VERSION` constant mismatch with header | Aligned constant to `'1.6.1'` | aggregator 1.6.1 |

---

## 8. Deployment Checklist (Next Deploy)

Run in order. Use `deploy.ps1 -SkipBuild -SkipStackSet` for Lambda-only changes, or full deploy for dashboard changes.

```
[ ] 1. Create backups/aggregator_lambda_v1.6.1.py
[ ] 2. Create backups/api_lambda_v1.5.4.py
[ ] 3. Create backups/inventory_lambda_v2.0.0.py
[x] 4. api_lambda.py v1.5.3 source-filter change — already applied locally
[ ] 5. Create backups/securityhub-dashboard_v1.5.7.jsx
[ ] 6. Deploy InventoryReadOnlyRole StackSet to all member accounts
        Template: cfn/securityhub-inventory-member-role.yaml
        Parameter InventoryRoleArn: copy from main stack Outputs → InventoryRoleArn
        (deploy BEFORE updating the main stack so the role exists when Lambda runs)
[ ] 7. Run deploy.ps1 — deploys updated main stack (InventoryRole policy + Lambda
        memory/timeout/env var) + all Lambda ZIPs + dashboard
        Use: deploy.ps1 -SkipBuild for Lambda-only, or full run with npm build
[ ] 8. npm run build (if dashboard changes are included)
[ ] 9. After deploy: trigger aggregator run manually
[ ] 10. Verify summaries/all/latest.json exists in S3
[ ] 11. Verify dashboard shows data on all accounts
[ ] 12. Verify Inspector tab shows findings (not SH findings)
[ ] 13. Test "Generate inventory" button — should trigger live Config discovery
[ ] 14. Verify inventory/{account}/latest.csv written to S3 after generation
[ ] 15. Test GET /inventory-csv → presigned URL → browser CSV download
        Confirm CSV columns: Service, ResourceType, DisplayName, ResourceName,
        ResourceId, Region, AccountId, AccountName
[ ] 16. Verify inventory shows resources with NO Security Hub findings
        (confirms live Config discovery, not findings.json fallback)
[ ] 17. Test "Generate report" → PDF / CSV / Excel download
[ ] 18. Check CloudWatch: confirm "split: X Security Hub findings, Y Inspector findings"
        where Y > 0 if Inspector is enabled
[ ] 19. Check CloudWatch: confirm no "Possible Inspector finding not classified" WARNINGs
[ ] 20. Check CloudWatch: confirm inventory log lines show resource counts per account
        e.g. "account=123456789012 discovered=347 resources across 12 regions"
```

---

## 9. S3 Data Layout (Reference)

```
securityhub-dashboard-data/
  summaries/
    accounts.json                       ← account list for dropdown
    version.json                        ← aggregator version + last run timestamp
    all/
      latest.json                       ← all-accounts SH summary (score, severities)
      findings.json                     ← all-accounts condensed SH findings
    {account_id}/
      latest.json                       ← per-account SH summary
      findings.json                     ← per-account condensed SH findings
  snapshots/
    {YYYY-MM-DD}/
      findings.json                     ← daily SH snapshot for delta/email digest
  trusted-advisor/
    all/latest.json
    {account_id}/latest.json
  inspector/
    all/latest.json
    {account_id}/latest.json
  reports/
    {account_id}/
      status.json                       ← { status, requestId, generatedAt, error }
      latest.pdf / latest.csv / latest.xlsx
  inventory/
    all/latest.json
    {account_id}/
      latest.json
      status.json
```

---

## 10. IAM Permissions Required (Aggregator Lambda Role)

```
securityhub:GetFindings
organizations:ListAccounts
sts:AssumeRole                          ← for Trusted Advisor cross-account reads
support:DescribeTrustedAdvisorChecks    ← own account only
support:DescribeTrustedAdvisorCheckResult
inspector2:BatchGetAccountStatus
ses:SendEmail
s3:GetObject, s3:PutObject             ← on securityhub-dashboard-data bucket
```

Member account role `TrustedAdvisorReadOnlyRole` requires:
```
support:DescribeTrustedAdvisorChecks
support:DescribeTrustedAdvisorCheckResult
```
Trust policy must allow the aggregator Lambda execution role ARN to assume it.

---

## 11. IAM Permissions Required (Inventory Lambda Role)

New permissions required on the inventory Lambda execution role for v2.0.0.
**These are now managed by `cfn/securityhub-dashboard-main.yaml`** — no manual
IAM changes needed; deploying the updated main stack applies them automatically.

```
s3:GetObject, s3:PutObject             ← on securityhub-dashboard-data bucket (summaries/*, inventory/*)
sts:AssumeRole                         ← resource: arn:aws:iam::*:role/InventoryReadOnlyRole
sts:GetCallerIdentity                  ← to determine own account ID (skip self-assumption)
config:ListDiscoveredResources         ← own (delegated admin) account
config:GetDiscoveredResourceCounts     ← own account
ec2:DescribeRegions                    ← to enumerate opted-in regions per account
organizations:ListAccounts             ← fallback if summaries/accounts.json absent
```

Member account role `InventoryReadOnlyRole` — deployed via **`cfn/securityhub-inventory-member-role.yaml`** StackSet:
```
config:ListDiscoveredResources
config:GetDiscoveredResourceCounts
ec2:DescribeRegions
```
Trust policy:
- Principal: `InventoryRoleArn` (from main stack Outputs tab)
- Condition: `sts:ExternalId = {MemberAccountId}-inventory-reader`
  The Lambda passes this automatically in `_get_session_credentials()`.

Optional environment variable on the Lambda (set by the main stack):
```
INVENTORY_READER_ROLE_NAME   ← default: InventoryReadOnlyRole
                                Must match RoleName parameter used in the StackSet
```
