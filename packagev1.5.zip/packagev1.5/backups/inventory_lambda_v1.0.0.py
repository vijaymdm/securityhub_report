"""
On-demand Account Inventory Lambda.
Invoked asynchronously by the API Lambda (InvocationType='Event') when the
user opens the Inventory tab or clicks 'Refresh inventory' in the dashboard.

Reads condensed findings already written to S3 by the aggregator — no
Security Hub API calls are made here.

Builds a per-account and org-wide inventory of:
  - Which AWS service types have open findings
  - How many distinct resources per service
  - Severity breakdown per service
  - Which regions are affected
  - A per-account resource-level list with finding counts

Deployment region: eu-west-1 (same as aggregator and API Lambda)

VERSION: 1.0.0

CHANGELOG
  1.0.0 - Initial: on-demand inventory generation from S3 condensed findings.
          Reads summaries/accounts.json and summaries/{account}/findings.json.
          Writes inventory/{account}/latest.json, inventory/all/latest.json,
          and inventory/{account}/status.json (polled by the dashboard).

Environment variables required:
  BUCKET  — S3 data bucket name (same as aggregator + api_lambda)

Invocation event shape (set by api_lambda POST /generate-inventory):
  {
    "account":   "123456789012" | "all",
    "requestId": "<api-gateway-request-id>"
  }

S3 paths read:
  summaries/accounts.json               — account list [{id, name, accountId}]
  summaries/{account}/findings.json     — condensed findings list

S3 paths written:
  inventory/{account}/latest.json       — per-account inventory
  inventory/all/latest.json             — org-wide inventory
  inventory/{account}/status.json       — { status, requestId, generatedAt, error }
"""

import boto3
import botocore.exceptions
import json
import logging
import os
import time
from datetime import datetime, timezone
from collections import defaultdict

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

INVENTORY_VERSION = '1.0.0'

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
def _require_env(name: str) -> str:
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(f"Required environment variable '{name}' is not set.")
    return val

BUCKET = _require_env('BUCKET')

s3 = boto3.client('s3')

# ---------------------------------------------------------------------------
# Human-readable display names for common AWS resource types (ASFF format)
# ---------------------------------------------------------------------------
_SERVICE_DISPLAY = {
    'AwsEc2Instance':              'EC2 — Instances',
    'AwsEc2SecurityGroup':         'EC2 — Security Groups',
    'AwsEc2Volume':                'EC2 — EBS Volumes',
    'AwsEc2Vpc':                   'EC2 — VPCs',
    'AwsEc2Subnet':                'EC2 — Subnets',
    'AwsEc2NetworkInterface':      'EC2 — Network Interfaces',
    'AwsEc2RouteTable':            'EC2 — Route Tables',
    'AwsEc2InternetGateway':       'EC2 — Internet Gateways',
    'AwsEc2NatGateway':            'EC2 — NAT Gateways',
    'AwsEc2LaunchTemplate':        'EC2 — Launch Templates',
    'AwsEc2TransitGateway':        'EC2 — Transit Gateways',
    'AwsS3Bucket':                 'S3 — Buckets',
    'AwsS3Object':                 'S3 — Objects',
    'AwsS3AccessPoint':            'S3 — Access Points',
    'AwsIamUser':                  'IAM — Users',
    'AwsIamRole':                  'IAM — Roles',
    'AwsIamGroup':                 'IAM — Groups',
    'AwsIamPolicy':                'IAM — Policies',
    'AwsIamAccessKey':             'IAM — Access Keys',
    'AwsRdsDbInstance':            'RDS — DB Instances',
    'AwsRdsDbCluster':             'RDS — Clusters',
    'AwsRdsDbSnapshot':            'RDS — Snapshots',
    'AwsRdsDbClusterSnapshot':     'RDS — Cluster Snapshots',
    'AwsLambdaFunction':           'Lambda — Functions',
    'AwsEksCluster':               'EKS — Clusters',
    'AwsEcsCluster':               'ECS — Clusters',
    'AwsEcsTaskDefinition':        'ECS — Task Definitions',
    'AwsEcsService':               'ECS — Services',
    'AwsEcrRepository':            'ECR — Repositories',
    'AwsEcrContainerImage':        'ECR — Container Images',
    'AwsEksNodegroup':             'EKS — Node Groups',
    'AwsElasticBeanstalkEnvironment': 'Elastic Beanstalk — Environments',
    'AwsElbLoadBalancer':          'ELB — Classic Load Balancers',
    'AwsElbv2LoadBalancer':        'ELBv2 — Application / Network LBs',
    'AwsElbv2Listener':            'ELBv2 — Listeners',
    'AwsCloudFrontDistribution':   'CloudFront — Distributions',
    'AwsCloudTrailTrail':          'CloudTrail — Trails',
    'AwsCloudWatchAlarm':          'CloudWatch — Alarms',
    'AwsCloudFormationStack':      'CloudFormation — Stacks',
    'AwsCodeBuildProject':         'CodeBuild — Projects',
    'AwsCodePipelinePipeline':     'CodePipeline — Pipelines',
    'AwsDynamoDbTable':            'DynamoDB — Tables',
    'AwsElasticsearchDomain':      'Elasticsearch — Domains',
    'AwsOpenSearchServiceDomain':  'OpenSearch — Domains',
    'AwsKmsKey':                   'KMS — Keys',
    'AwsKinesisStream':            'Kinesis — Streams',
    'AwsMskCluster':               'MSK — Kafka Clusters',
    'AwsRedshiftCluster':          'Redshift — Clusters',
    'AwsSageMakerNotebookInstance':'SageMaker — Notebook Instances',
    'AwsSecretsManagerSecret':     'Secrets Manager — Secrets',
    'AwsSnsSubscription':          'SNS — Subscriptions',
    'AwsSnsTopic':                 'SNS — Topics',
    'AwsSqsQueue':                 'SQS — Queues',
    'AwsSsmDocument':              'SSM — Documents',
    'AwsSsmManagedInstance':       'SSM — Managed Instances',
    'AwsWafWebAcl':                'WAF — Web ACLs',
    'AwsWafv2WebAcl':              'WAFv2 — Web ACLs',
    'AwsApiGatewayRestApi':        'API Gateway — REST APIs',
    'AwsApiGatewayV2Api':          'API Gateway v2 — APIs',
    'AwsApiGatewayStage':          'API Gateway — Stages',
    'AwsCertificateManagerCertificate': 'ACM — Certificates',
    'AwsAutoScalingAutoScalingGroup': 'Auto Scaling — Groups',
    'AwsAutoScalingLaunchConfiguration': 'Auto Scaling — Launch Configurations',
    'AwsRoute53HostedZone':        'Route 53 — Hosted Zones',
    'AwsGuardDutyDetector':        'GuardDuty — Detectors',
    'AwsBackupBackupPlan':         'AWS Backup — Plans',
    'AwsBackupBackupVault':        'AWS Backup — Vaults',
    'AwsDaxCluster':               'DAX — Clusters',
    'AwsEfsMountTarget':           'EFS — Mount Targets',
    'AwsEfsAccessPoint':           'EFS — Access Points',
    'AwsNetworkFirewallFirewall':   'Network Firewall — Firewalls',
    'AwsNetworkFirewallFirewallPolicy': 'Network Firewall — Policies',
    'Container':                   'Containers',
    'Other':                       'Other',
}

SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']


def _service_display(resource_type: str) -> str:
    """Return a human-readable service name, falling back to the raw type."""
    return _SERVICE_DISPLAY.get(resource_type, resource_type or 'Unknown')


# ---------------------------------------------------------------------------
# Status helpers
# ---------------------------------------------------------------------------

def _write_status(account: str, request_id: str, status: str, error: str = None):
    """Write inventory/{account}/status.json."""
    payload = {
        'status':      status,
        'requestId':   request_id,
        'generatedAt': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'error':       error,
    }
    s3.put_object(
        Bucket=BUCKET,
        Key=f'inventory/{account}/status.json',
        Body=json.dumps(payload),
        ContentType='application/json',
    )


# ---------------------------------------------------------------------------
# S3 data loaders
# ---------------------------------------------------------------------------

def _load_json(key: str, default=None):
    """Load and parse a JSON object from S3. Returns `default` on NoSuchKey."""
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        return json.loads(obj['Body'].read().decode())
    except (s3.exceptions.NoSuchKey, botocore.exceptions.ClientError) as e:
        code = getattr(e, 'response', {}).get('Error', {}).get('Code', '')
        if code in ('NoSuchKey', '404'):
            return default
        raise


def _load_accounts() -> list:
    """Return list of {id, name, accountId} from summaries/accounts.json."""
    return _load_json('summaries/accounts.json', default=[])


def _load_findings(account_id: str) -> list:
    """Load condensed findings for one account from summaries/{account}/findings.json.
    Each finding has: severity, title, resourceId, controlId, workflowStatus,
    region, firstObservedAt — plus resourceType is sometimes present.
    ResourceType comes from the original finding via condense_finding(); if absent
    we derive it from the resourceId ARN prefix or leave as 'Unknown'.
    """
    return _load_json(f'summaries/{account_id}/findings.json', default=[])


# ---------------------------------------------------------------------------
# Resource type inference from ARN (fallback when resourceType is absent)
# ---------------------------------------------------------------------------

_ARN_PREFIXES = [
    ('arn:aws:ec2:', 'AwsEc2'),
    ('arn:aws:s3:::', 'AwsS3Bucket'),
    ('arn:aws:iam:', 'AwsIam'),
    ('arn:aws:rds:', 'AwsRds'),
    ('arn:aws:lambda:', 'AwsLambdaFunction'),
    ('arn:aws:eks:', 'AwsEksCluster'),
    ('arn:aws:ecs:', 'AwsEcs'),
    ('arn:aws:ecr:', 'AwsEcr'),
    ('arn:aws:elasticloadbalancing:', 'AwsElbv2LoadBalancer'),
    ('arn:aws:cloudfront:', 'AwsCloudFrontDistribution'),
    ('arn:aws:cloudtrail:', 'AwsCloudTrailTrail'),
    ('arn:aws:kms:', 'AwsKmsKey'),
    ('arn:aws:sns:', 'AwsSnsTopic'),
    ('arn:aws:sqs:', 'AwsSqsQueue'),
    ('arn:aws:secretsmanager:', 'AwsSecretsManagerSecret'),
    ('arn:aws:dynamodb:', 'AwsDynamoDbTable'),
    ('arn:aws:apigateway:', 'AwsApiGateway'),
    ('arn:aws:acm:', 'AwsCertificateManagerCertificate'),
    ('arn:aws:autoscaling:', 'AwsAutoScalingAutoScalingGroup'),
]


def _infer_resource_type(resource_id: str) -> str:
    rid = resource_id.lower()
    for prefix, rtype in _ARN_PREFIXES:
        if rid.startswith(prefix.lower()):
            return rtype
    return 'Other'


# ---------------------------------------------------------------------------
# Core inventory builder
# ---------------------------------------------------------------------------

def build_account_inventory(account_id: str, account_name: str,
                             findings: list) -> dict:
    """Build inventory for a single account from its condensed findings list.

    Returns a dict with:
      accountId, accountName, lastGenerated, totalFindings, totalResources,
      services[], resources[]
    """
    # --- aggregate by resource type ---
    # service_map: { resource_type: { resourceIds: set, severities: {sev: count},
    #                                 regions: set, findingCount: int } }
    service_map: dict = defaultdict(lambda: {
        'resourceIds':  set(),
        'severities':   {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0},
        'regions':      set(),
        'findingCount': 0,
    })

    # resource_map: { resourceId: { resourceType, region, severity_worst, findingCount } }
    resource_map: dict = {}

    severity_rank = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}

    for f in findings:
        rid   = f.get('resourceId', 'unknown')
        rtype = f.get('resourceType', '') or _infer_resource_type(rid)
        sev   = f.get('severity', 'LOW')
        reg   = f.get('region', '')

        # service aggregation
        svc = service_map[rtype]
        svc['resourceIds'].add(rid)
        svc['findingCount'] += 1
        if sev in svc['severities']:
            svc['severities'][sev] += 1
        if reg:
            svc['regions'].add(reg)

        # resource-level aggregation
        if rid not in resource_map:
            resource_map[rid] = {
                'resourceId':    rid,
                'resourceType':  rtype,
                'region':        reg,
                'findingCount':  0,
                'worstSeverity': sev,
            }
        r = resource_map[rid]
        r['findingCount'] += 1
        if severity_rank.get(sev, 99) < severity_rank.get(r['worstSeverity'], 99):
            r['worstSeverity'] = sev

    # --- format services list (sorted by finding count desc) ---
    services = sorted(
        [
            {
                'resourceType':  rtype,
                'displayName':   _service_display(rtype),
                'resourceCount': len(svc['resourceIds']),
                'findingCount':  svc['findingCount'],
                'critical':      svc['severities']['CRITICAL'],
                'high':          svc['severities']['HIGH'],
                'medium':        svc['severities']['MEDIUM'],
                'low':           svc['severities']['LOW'],
                'regions':       sorted(svc['regions']),
            }
            for rtype, svc in service_map.items()
        ],
        key=lambda x: -x['findingCount'],
    )

    # --- format resources list (sorted by worst severity then finding count) ---
    resources = sorted(
        list(resource_map.values()),
        key=lambda r: (
            severity_rank.get(r['worstSeverity'], 99),
            -r['findingCount'],
        ),
    )

    return {
        'accountId':      account_id,
        'accountName':    account_name,
        'lastGenerated':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'totalFindings':  len(findings),
        'totalResources': len(resource_map),
        'services':       services,
        'resources':      resources,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    """Invoked asynchronously by the API Lambda (InvocationType='Event').

    Event shape:
      { "account": "123456789012"|"all", "requestId": "<string>" }

    Behaviour:
      - account = specific 12-digit ID  →  build inventory for that account only
                                            and write inventory/{account}/latest.json
      - account = "all"                 →  build inventory for EVERY known account
                                            plus the org-wide rollup, write all files

    Always writes a status file first (pending) so the dashboard can show progress.
    """
    t_start    = time.perf_counter()
    account_id = (event.get('account') or 'all').strip()
    request_id = event.get('requestId', 'unknown')

    logger.info('inventory: account=%s requestId=%s version=%s',
                account_id, request_id, INVENTORY_VERSION)

    _write_status(account_id, request_id, 'pending')

    error_msg = None

    try:
        accounts     = _load_accounts()                         # [{id, name, accountId}]
        name_map     = {a['id']: a.get('name', a['id']) for a in accounts}

        if account_id == 'all':
            # ── Build per-account inventories then roll up ────────────────
            per_account_inventories = {}

            for acct in accounts:
                aid   = acct['id']
                aname = acct.get('name', aid)
                try:
                    findings = _load_findings(aid)
                    inv      = build_account_inventory(aid, aname, findings)
                    per_account_inventories[aid] = inv

                    s3.put_object(
                        Bucket=BUCKET,
                        Key=f'inventory/{aid}/latest.json',
                        Body=json.dumps(inv),
                        ContentType='application/json',
                    )
                    logger.info('inventory: wrote account %s (%d findings, %d resources)',
                                aid, inv['totalFindings'], inv['totalResources'])
                except Exception as exc:
                    logger.exception('inventory: failed for account %s: %s', aid, exc)

            # ── Org-wide rollup ───────────────────────────────────────────
            all_services:   dict = defaultdict(lambda: {
                'resourceIds': set(), 'severities': {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0},
                'regions': set(), 'findingCount': 0,
            })
            all_resources:  dict = {}
            total_findings  = 0
            severity_rank   = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}

            for inv in per_account_inventories.values():
                total_findings += inv['totalFindings']
                for r in inv['resources']:
                    rid   = r['resourceId']
                    rtype = r['resourceType']
                    sev   = r['worstSeverity']
                    reg   = r.get('region', '')

                    svc = all_services[rtype]
                    svc['resourceIds'].add(rid)
                    svc['findingCount'] += r['findingCount']
                    if sev in svc['severities']:
                        svc['severities'][sev] += r['findingCount']
                    if reg:
                        svc['regions'].add(reg)

                    if rid not in all_resources or \
                       severity_rank.get(sev, 99) < severity_rank.get(all_resources[rid]['worstSeverity'], 99):
                        all_resources[rid] = {
                            'resourceId':    rid,
                            'resourceType':  rtype,
                            'accountId':     inv['accountId'],
                            'accountName':   inv['accountName'],
                            'region':        reg,
                            'findingCount':  r['findingCount'],
                            'worstSeverity': sev,
                        }

            all_services_list = sorted(
                [
                    {
                        'resourceType':  rtype,
                        'displayName':   _service_display(rtype),
                        'resourceCount': len(svc['resourceIds']),
                        'findingCount':  svc['findingCount'],
                        'critical':      svc['severities']['CRITICAL'],
                        'high':          svc['severities']['HIGH'],
                        'medium':        svc['severities']['MEDIUM'],
                        'low':           svc['severities']['LOW'],
                        'regions':       sorted(svc['regions']),
                    }
                    for rtype, svc in all_services.items()
                ],
                key=lambda x: -x['findingCount'],
            )

            all_resources_list = sorted(
                list(all_resources.values()),
                key=lambda r: (severity_rank.get(r['worstSeverity'], 99), -r['findingCount']),
            )

            all_inventory = {
                'accountId':       'all',
                'accountName':     'All Accounts',
                'lastGenerated':   datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
                'accountsIncluded': len(per_account_inventories),
                'totalFindings':   total_findings,
                'totalResources':  len(all_resources),
                'services':        all_services_list,
                'resources':       all_resources_list,
            }

            s3.put_object(
                Bucket=BUCKET,
                Key='inventory/all/latest.json',
                Body=json.dumps(all_inventory),
                ContentType='application/json',
            )
            logger.info('inventory: wrote all (%d accounts, %d resources)',
                        len(per_account_inventories), len(all_resources))

        else:
            # ── Single account ────────────────────────────────────────────
            aname    = name_map.get(account_id, account_id)
            findings = _load_findings(account_id)
            inv      = build_account_inventory(account_id, aname, findings)

            s3.put_object(
                Bucket=BUCKET,
                Key=f'inventory/{account_id}/latest.json',
                Body=json.dumps(inv),
                ContentType='application/json',
            )
            logger.info('inventory: wrote account %s (%d findings, %d resources)',
                        account_id, inv['totalFindings'], inv['totalResources'])

        _write_status(account_id, request_id, 'done')

    except Exception as exc:
        error_msg = str(exc)
        logger.exception('inventory: FAILED account=%s: %s', account_id, exc)
        _write_status(account_id, request_id, 'failed', error=error_msg)

    logger.info('inventory: total=%.2fs', time.perf_counter() - t_start)

    return {
        'statusCode': 200 if not error_msg else 500,
        'account':    account_id,
        'error':      error_msg,
        'durationSeconds': round(time.perf_counter() - t_start, 1),
    }
