"""
Runs on a schedule (EventBridge, e.g. daily 03:00 GMT) in the Security Hub
DELEGATED ADMINISTRATOR account.

Deployment region: eu-west-1
  The Lambda, EventBridge rule, S3 bucket, and API Gateway all live in eu-west-1.
  Two AWS services used by this Lambda are GLOBAL and must always target us-east-1
  regardless of where the Lambda is deployed — see notes below.

VERSION: 1.5.4   (bump this + add a CHANGELOG line every time you redeploy)

CHANGELOG
  1.5.4 - Inspector findings separated from Security Hub. fetch_all_findings()
          and fetch_all_compliance_findings() now exclude Inspector via ProductArn
          filter. New fetch_inspector_findings(), summarize_inspector_by_account(),
          write_inspector_to_s3() functions write to inspector/{account}/latest.json.
          lambda_handler return payload includes inspectorAccountsProcessed.
  1.5.0 - Day-over-day snapshot comparison (snapshots/{date}/findings.json).
          Multi-tab Excel report: Failed / Passed / Previously-Failed-Now-Passed.
          SES email digest of new Critical/High findings sent after each run.
  1.4.0 - Executive summary PDF page, severity bar chart, NEW finding badges
          (FirstObservedAt-based delta), findings-by-resource-type page.
          IsNew + ResourceType columns added to CSV.
  1.3.0 - Real AWS-formula compliance score (passed/enabled controls).
          Fixed-height PDF rows. CSV columns reordered, Severity first.
          Clean-account fix (100%-passing accounts still appear).
  1.2.0 - Trusted Advisor integration, CSV export, findings.json per-account.
  1.1.0 - PDF report generation (fpdf2), severity-grouped findings.
  1.0.0 - Initial: Security Hub aggregation, per-account JSON summaries.
  1.3.0 - Real AWS-formula compliance score (passed/enabled controls,
          matches Security Hub console exactly). Fixed-height PDF table
          rows (no more multi_cell misalignment on long titles). CSV
          columns reordered with Severity first. Clean-account fix so
          100%-passing accounts still appear in the dashboard.
  1.2.0 - Added Trusted Advisor integration (cross-account role read +
          Organizational-style aggregation), CSV export, findings.json
          per-account output for click-to-drill-down severity cards.
  1.1.0 - Added PDF report generation (fpdf2), severity-grouped findings.
  1.0.0 - Initial: Security Hub findings aggregation, per-account JSON
          summaries, account index for dashboard dropdown.

Security Hub:
  Because this account is delegated admin, GetFindings already returns findings
  from all 70+ member accounts — no cross-account role needed. Each finding
  carries AwsAccountId telling you which account it belongs to.

Trusted Advisor:
  The AWS Support API is a GLOBAL service (us-east-1 only) and requires
  Business+/Enterprise support plan. This endpoint must always be called
  against us-east-1 even though the Lambda itself runs in eu-west-1.
  a lightweight cross-account role (TA_READER_ROLE_NAME) in each member
  account to call DescribeTrustedAdvisorChecks / DescribeTrustedAdvisorCheckResult.
  The delegated-admin account itself is queried using its own credentials.

  Required IAM permissions on the Lambda execution role:
    - sts:AssumeRole  (to assume TA_READER_ROLE_NAME in member accounts)
    - support:DescribeTrustedAdvisorChecks
    - support:DescribeTrustedAdvisorCheckResult

  Required IAM permissions on TA_READER_ROLE_NAME in EVERY member account:
    - support:DescribeTrustedAdvisorChecks
    - support:DescribeTrustedAdvisorCheckResult
    Trust policy must allow the Lambda execution role ARN to assume it.

Writes to S3:
  summaries/accounts.json                    <- account list (dropdown)
  summaries/{account_id}/latest.json         <- per-account Security Hub summary
  summaries/{account_id}/findings.json       <- condensed findings (click-to-drill-down)
  summaries/all/latest.json                  <- all-accounts Security Hub summary
  summaries/all/findings.json                <- all-accounts condensed findings
  trusted-advisor/{account_id}/latest.json   <- per-account TA summary
  trusted-advisor/all/latest.json            <- all-accounts TA summary
  inspector/{account_id}/latest.json         <- per-account Inspector summary
  inspector/all/latest.json                  <- all-accounts Inspector summary
  reports/{account_id}/latest.pdf            <- per-account PDF (Security Hub)
  reports/{account_id}/latest.csv            <- per-account CSV (Security Hub)
  reports/all/latest.pdf                     <- combined PDF
  reports/all/latest.csv                     <- combined CSV
"""

AGGREGATOR_VERSION = '1.5.4'


import boto3
import json
import csv
import io
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from fpdf import FPDF, XPos, YPos

try:
    import openpyxl
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# Configuration from environment variables — fail fast at cold-start if missing
# ---------------------------------------------------------------------------
def _require_env(name):
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(
            f"Required environment variable '{name}' is not set. "
            "Set it in the Lambda function configuration before deploying."
        )
    return val

def _optional_env(name, default=''):
    return os.environ.get(name, default).strip()


BUCKET         = _require_env('BUCKET')
SES_FROM_EMAIL = _require_env('SES_FROM_EMAIL')
SES_TO_EMAIL   = _require_env('SES_TO_EMAIL')

# Optional override: comma-separated "accountId=name" pairs, e.g.
#   "143301474150=audit,824623333855=AmazonAWS"
# Falls back to an empty dict — names come from AWS Organizations instead.
def _parse_account_overrides(raw):
    overrides = {}
    for pair in raw.split(','):
        pair = pair.strip()
        if '=' in pair:
            aid, name = pair.split('=', 1)
            aid = aid.strip()
            if aid:
                overrides[aid] = name.strip()
    return overrides

ACCOUNT_NAME_OVERRIDES = _parse_account_overrides(
    _optional_env('ACCOUNT_NAME_OVERRIDES', '')
)

securityhub = boto3.client('securityhub')
s3           = boto3.client('s3')
sts          = boto3.client('sts')
# SES: us-east-1 is required here because SES send_email is a global endpoint
# that must be called in the region where the sender identity is verified.
# Keep this as us-east-1 regardless of the Lambda's deployment region (eu-west-1).
ses          = boto3.client('ses', region_name='us-east-1')

# Warn (not fail) if openpyxl is missing — logged after logger is configured
if not EXCEL_AVAILABLE:
    logger.warning('openpyxl not installed — Excel reports disabled. Add openpyxl to the Lambda ZIP.')

SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
# Pre-computed rank dict used in multiple sort keys — avoids repeated inline comprehensions
SEVERITY_RANK  = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}

# ---------------------------------------------------------------------------
# Timing helper — logs wall-clock duration of every major phase to CloudWatch
# ---------------------------------------------------------------------------
class _timed:
    """Context manager that logs the wall-clock duration of a named phase.

    Usage:
        with _timed('fetch_all_findings'):
            findings = fetch_all_findings()

    Emits a single [TIMING] INFO line per phase so CloudWatch Logs Insights
    can query:
        filter @message like /TIMING/
        | parse @message "TIMING phase=* duration_s=*" as phase, duration
        | stats avg(duration) by phase
    """
    def __init__(self, name: str):
        self.name = name

    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_):
        elapsed = time.perf_counter() - self._start
        logger.info('TIMING phase=%s duration_s=%.2f', self.name, elapsed)

# A finding counts as "new since last scan" if AWS's own FirstObservedAt
# timestamp falls within this window. 26h (not 24h) gives a buffer for
# schedule drift/Lambda start delay on a daily run — adjust if you change
# the EventBridge schedule frequency.
NEW_FINDING_WINDOW_HOURS = 26


def is_new_finding(f, now):
    """True if this finding's FirstObservedAt is within the new-finding
    window. Uses AWS's own timestamp — no extra state/snapshot storage
    needed to detect what's new since the last run."""
    observed = f.get('FirstObservedAt')
    if not observed:
        return False
    try:
        observed_dt = datetime.strptime(observed, '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc)
    except ValueError:
        try:
            observed_dt = datetime.strptime(observed, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
        except ValueError:
            return False
    return (now - observed_dt) <= timedelta(hours=NEW_FINDING_WINDOW_HOURS)


def get_resource_type(f):
    """Extract the AWS resource type (e.g. 'AwsS3Bucket', 'AwsEc2SecurityGroup')
    from a finding, falling back to 'Unknown' if not present."""
    resources = f.get('Resources', [{}])
    return (resources[0].get('Type') if resources else None) or 'Unknown'

# ---------------------------------------------------------------------------
# Cross-account role assumed in every member account to read Trusted Advisor.
# Create this role in each member account and trust the Lambda execution role.
# ---------------------------------------------------------------------------
TA_READER_ROLE_NAME = 'TrustedAdvisorReadOnlyRole'

# Optional: map account IDs to friendly names (pulled from Organizations by
# default — see get_account_names() below). Override via ACCOUNT_NAME_OVERRIDES
# environment variable: comma-separated "accountId=name" pairs.


def get_account_names():
    """Pull friendly names directly from AWS Organizations."""
    org = boto3.client('organizations')
    names = {}
    paginator = org.get_paginator('list_accounts')
    for page in paginator.paginate():
        for acct in page['Accounts']:
            names[acct['Id']] = acct['Name']
    names.update(ACCOUNT_NAME_OVERRIDES)
    return names


# ---------------------------------------------------------------------------
# Security Hub
# ---------------------------------------------------------------------------

# ProductArn prefix that identifies AWS Inspector v2 findings inside Security Hub.
# Inspector v2 uses: arn:aws:inspector2:{region}::product/aws/inspector
# All Security Hub native security-standard controls use:
#   arn:aws:securityhub:{region}::product/aws/securityhub
_INSPECTOR_PRODUCT_ARN_PREFIX = 'arn:aws:inspector'


def is_inspector_finding(f: dict) -> bool:
    """Return True if this finding originated from AWS Inspector v2.
    Inspector findings carry a ProductArn that starts with 'arn:aws:inspector'.
    Security Hub native control findings use 'arn:aws:securityhub'."""
    return f.get('ProductArn', '').startswith(_INSPECTOR_PRODUCT_ARN_PREFIX)


def fetch_all_findings():
    """Paginate through GetFindings for ACTIVE, non-suppressed OPEN findings only.
    This is used for severity counts / top controls / PDF-CSV report content —
    i.e. 'what still needs attention'. It intentionally excludes PASSED findings
    and AWS Inspector findings (which have their own separate data path)."""
    findings = []
    paginator = securityhub.get_paginator('get_findings')
    page_iterator = paginator.paginate(
        Filters={
            'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
            'WorkflowStatus': [
                {'Value': 'NEW', 'Comparison': 'EQUALS'},
                {'Value': 'NOTIFIED', 'Comparison': 'EQUALS'},
            ],
            # Exclude Inspector — it has its own fetch / S3 path / dashboard tab.
            'ProductArn': [{'Value': _INSPECTOR_PRODUCT_ARN_PREFIX, 'Comparison': 'PREFIX_NOT_EQUALS'}],
        },
        PaginationConfig={'PageSize': 100},
    )
    for page in page_iterator:
        findings.extend(page['Findings'])
    return findings


def fetch_all_compliance_findings():
    """Paginate through GetFindings for ALL ACTIVE findings regardless of
    workflow status — this includes PASSED findings, which fetch_all_findings()
    deliberately excludes. Needed to replicate AWS's own security score formula,
    which is based on per-control Pass/Fail/Warning status, not just open findings.
    Inspector findings are excluded — they don't carry Compliance.Status and would
    distort the control score calculation."""
    findings = []
    paginator = securityhub.get_paginator('get_findings')
    page_iterator = paginator.paginate(
        Filters={
            'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
            # Exclude Inspector findings from compliance score calculation.
            'ProductArn': [{'Value': _INSPECTOR_PRODUCT_ARN_PREFIX, 'Comparison': 'PREFIX_NOT_EQUALS'}],
        },
        PaginationConfig={'PageSize': 100},
    )
    for page in page_iterator:
        findings.extend(page['Findings'])
    return findings


def fetch_inspector_findings():
    """Paginate through GetFindings for ACTIVE Inspector v2 findings only.
    Inspector findings are identified by ProductArn starting with
    'arn:aws:inspector'. Only NEW and NOTIFIED workflow statuses are fetched
    (open, unresolved vulnerabilities)."""
    findings = []
    paginator = securityhub.get_paginator('get_findings')
    page_iterator = paginator.paginate(
        Filters={
            'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
            'WorkflowStatus': [
                {'Value': 'NEW', 'Comparison': 'EQUALS'},
                {'Value': 'NOTIFIED', 'Comparison': 'EQUALS'},
            ],
            'ProductArn': [{'Value': _INSPECTOR_PRODUCT_ARN_PREFIX, 'Comparison': 'PREFIX'}],
        },
        PaginationConfig={'PageSize': 100},
    )
    for page in page_iterator:
        findings.extend(page['Findings'])
    logger.info('fetch_inspector_findings: fetched %d Inspector findings', len(findings))
    return findings


def compute_control_scores(compliance_findings):
    """Replicates AWS Security Hub's official security score formula:

        score = (passed controls / enabled controls) * 100

    where 'enabled controls' = controls with a Compliance.Status of
    PASSED, FAILED, or WARNING. Controls with NOT_AVAILABLE ('No data')
    are excluded from both numerator and denominator, matching AWS's
    documented behaviour exactly.

    A control's overall status per account is the worst status seen among
    its findings: FAILED > WARNING > PASSED > NOT_AVAILABLE. This mirrors
    how Security Hub itself rolls up multiple findings under one control.

    Returns (per_account_scores, all_accounts_score) where each is:
        {'passedControls': int, 'failedControls': int, 'warningControls': int,
         'totalEnabledControls': int, 'score': int}
    """
    STATUS_RANK = {'FAILED': 3, 'WARNING': 2, 'PASSED': 1, 'NOT_AVAILABLE': 0}

    # (account_id, control_id) -> worst status seen
    control_status = {}

    for f in compliance_findings:
        acct = f.get('AwsAccountId', 'UNKNOWN')
        control_id = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
        status = f.get('Compliance', {}).get('Status', 'NOT_AVAILABLE')
        key = (acct, control_id)

        if key not in control_status or STATUS_RANK.get(status, 0) > STATUS_RANK.get(control_status[key], 0):
            control_status[key] = status

    def _score_from_counts(passed, failed, warning):
        enabled = passed + failed + warning
        if enabled == 0:
            return 0
        return round((passed / enabled) * 100)

    per_account = defaultdict(lambda: {'passedControls': 0, 'failedControls': 0, 'warningControls': 0})
    for (acct, _control_id), status in control_status.items():
        if status == 'PASSED':
            per_account[acct]['passedControls'] += 1
        elif status == 'FAILED':
            per_account[acct]['failedControls'] += 1
        elif status == 'WARNING':
            per_account[acct]['warningControls'] += 1
        # NOT_AVAILABLE is intentionally not counted at all

    per_account_scores = {}
    total_passed = total_failed = total_warning = 0
    for acct, counts in per_account.items():
        enabled = counts['passedControls'] + counts['failedControls'] + counts['warningControls']
        per_account_scores[acct] = {
            **counts,
            'totalEnabledControls': enabled,
            'score': _score_from_counts(counts['passedControls'], counts['failedControls'], counts['warningControls']),
        }
        total_passed += counts['passedControls']
        total_failed += counts['failedControls']
        total_warning += counts['warningControls']

    all_accounts_score = {
        'passedControls': total_passed,
        'failedControls': total_failed,
        'warningControls': total_warning,
        'totalEnabledControls': total_passed + total_failed + total_warning,
        'score': _score_from_counts(total_passed, total_failed, total_warning),
    }

    return per_account_scores, all_accounts_score


def summarize_by_account(findings):
    """Group OPEN findings by AwsAccountId and compute per-account severity
    counts / top controls. The 'score' field here is a placeholder overwritten
    later with the real AWS-formula score from compute_control_scores() —
    kept here only so the dict shape is consistent if that step is skipped.
    Returns (summaries, by_account)."""
    by_account = defaultdict(list)
    for f in findings:
        acct = f.get('AwsAccountId', 'UNKNOWN')
        by_account[acct].append(f)

    summaries = {}
    for account_id, acct_findings in by_account.items():
        severity_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        control_counts = {}

        for f in acct_findings:
            sev = f.get('Severity', {}).get('Label', 'LOW')
            if sev in severity_counts:
                severity_counts[sev] += 1

            control_id = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
            title = f.get('Title', 'Unknown control')
            if control_id not in control_counts:
                control_counts[control_id] = {'id': control_id, 'title': title, 'severity': sev, 'count': 0}
            control_counts[control_id]['count'] += 1

        top_controls = sorted(control_counts.values(), key=lambda x: -x['count'])[:5]

        summaries[account_id] = {
            'accountId': account_id,
            'critical': severity_counts['CRITICAL'],
            'high': severity_counts['HIGH'],
            'medium': severity_counts['MEDIUM'],
            'low': severity_counts['LOW'],
            'score': 0,  # overwritten in lambda_handler with the real AWS-formula score
            'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'topControls': top_controls,
        }
    return summaries, by_account


def condense_finding(f):
    """Small, frontend-friendly shape for a single Security Hub finding."""
    resources = f.get('Resources', [{}])
    return {
        'severity': f.get('Severity', {}).get('Label', 'LOW'),
        'title': f.get('Title', 'Unknown finding'),
        'resourceId': resources[0].get('Id', 'unknown') if resources else 'unknown',
        'controlId': f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN'),
        'workflowStatus': f.get('Workflow', {}).get('Status', 'UNKNOWN'),
        'region': f.get('Region', ''),
        'firstObservedAt': f.get('FirstObservedAt', ''),
    }


def _pdf_safe(text: str) -> str:
    """Replace characters outside latin-1 range with ASCII equivalents so
    fpdf2's built-in Helvetica font (latin-1 only) never raises
    FPDFUnicodeEncodingException on em-dashes, smart quotes, etc."""
    replacements = {
        '\u2014': '--',   # em dash
        '\u2013': '-',    # en dash
        '\u2018': "'",    # left single quote
        '\u2019': "'",    # right single quote
        '\u201c': '"',    # left double quote
        '\u201d': '"',    # right double quote
        '\u2026': '...',  # ellipsis
        '\u00a0': ' ',    # non-breaking space
    }
    for ch, replacement in replacements.items():
        text = text.replace(ch, replacement)
    # Final safety net: drop anything still outside latin-1
    return text.encode('latin-1', errors='replace').decode('latin-1')


def build_pdf_report(account_id, account_name, summary, findings):
    """Builds a report with three parts, in order:
      1. Executive summary page — score, severity bar chart, new-vs-existing
         delta, top 3 failing controls. Meant to be readable standalone.
      2. Full findings detail, grouped Critical -> High -> Medium -> Low,
         with a NEW badge on findings first observed since the last run.
      3. Findings-by-resource-type summary table — which AWS services are
         contributing the most findings, at a glance.
    Returns raw bytes.

    Uses fixed-height table rows (no multi_cell) so wrapping long titles can
    never desync a row's cell borders — every row stays on one baseline,
    with text truncated to fit instead of wrapping.
    """
    now = datetime.now(timezone.utc)
    pdf = FPDF(orientation='P', unit='mm', format='A4')
    pdf.set_margins(10, 10, 10)
    pdf.set_auto_page_break(auto=True, margin=12)

    def row(*cells_and_widths, h=6, fill=False):
        """Write one fixed-height table row. Args alternate (text, width)."""
        pairs = list(zip(cells_and_widths[::2], cells_and_widths[1::2]))
        for i, (text, w) in enumerate(pairs):
            is_last = (i == len(pairs) - 1)
            pdf.cell(
                w, h, str(text), border=1, fill=fill,
                new_x=XPos.RIGHT if not is_last else XPos.LMARGIN,
                new_y=YPos.TOP if not is_last else YPos.NEXT,
            )

    fill_by_severity = {
        'CRITICAL': (245, 220, 220),
        'HIGH': (250, 235, 215),
        'MEDIUM': (255, 250, 210),
        'LOW': (235, 235, 235),
    }
    bar_color_by_severity = {
        'CRITICAL': (229, 72, 77),
        'HIGH': (245, 166, 35),
        'MEDIUM': (91, 155, 213),
        'LOW': (138, 150, 163),
    }

    # Precompute which findings are new, and group by severity / resource type
    new_findings = [f for f in findings if is_new_finding(f, now)]
    existing_findings = [f for f in findings if f not in new_findings]

    by_severity = defaultdict(list)
    for f in findings:
        sev = f.get('Severity', {}).get('Label', 'LOW')
        by_severity[sev].append(f)
    ordered_severities = SEVERITY_ORDER + [s for s in by_severity if s not in SEVERITY_ORDER]

    by_resource_type = defaultdict(list)
    for f in findings:
        by_resource_type[get_resource_type(f)].append(f)

    # =====================================================================
    # PAGE 1 — EXECUTIVE SUMMARY
    # =====================================================================
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 16)
    pdf.cell(0, 9, 'AWS Security Hub Compliance Report', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 10)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(0, 6, _pdf_safe(f'Account: {account_name}  ({account_id})'), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f'Generated: {summary["lastScan"]}', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(4)

    # ── Compliance score ───────────────────────────────────────────────
    pdf.set_font('Helvetica', 'B', 14)
    pdf.cell(0, 8, f'Compliance Score: {summary["score"]} / 100', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 9)
    pdf.set_text_color(90, 90, 90)
    passed = summary.get('passedControls', 0)
    total_enabled = summary.get('totalEnabledControls', 0)
    pdf.cell(0, 5, f'{passed} passed / {total_enabled} enabled controls (matches AWS Security Hub console formula)',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(5)

    # ── Severity distribution bar chart ───────────────────────────────
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Severity Distribution', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(1)
    sev_counts = {
        'CRITICAL': summary['critical'], 'HIGH': summary['high'],
        'MEDIUM': summary['medium'], 'LOW': summary['low'],
    }
    max_count = max(sev_counts.values()) or 1
    max_bar_w = 140
    label_w = 22
    for sev in SEVERITY_ORDER:
        count = sev_counts[sev]
        bar_w = (count / max_count) * max_bar_w
        y_start = pdf.get_y()
        pdf.set_font('Helvetica', 'B', 8)
        pdf.cell(label_w, 6, sev, new_x=XPos.RIGHT, new_y=YPos.TOP)
        if bar_w > 0:
            pdf.set_fill_color(*bar_color_by_severity[sev])
            pdf.cell(bar_w, 6, '', fill=True, new_x=XPos.RIGHT, new_y=YPos.TOP)
        pdf.set_font('Helvetica', '', 8)
        pdf.set_xy(10 + label_w + bar_w + 2, y_start)
        pdf.cell(15, 6, str(count), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(4)

    # ── New vs. existing (trend/delta) ────────────────────────────────
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Since Last Scan', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 9)
    new_crit_high = sum(1 for f in new_findings if f.get('Severity', {}).get('Label') in ('CRITICAL', 'HIGH'))
    pdf.set_text_color(190, 40, 40) if new_findings else pdf.set_text_color(60, 140, 80)
    pdf.cell(0, 6,
             _pdf_safe(
                 f'{len(new_findings)} new finding{"s" if len(new_findings) != 1 else ""} '
                 f'(first observed in the last ~{NEW_FINDING_WINDOW_HOURS}h)'
                 + (f'  --  {new_crit_high} of them Critical/High' if new_crit_high else '')
             ),
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_text_color(110, 110, 110)
    pdf.cell(0, 5, f'{len(existing_findings)} ongoing finding{"s" if len(existing_findings) != 1 else ""} (open before this window)',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(4)

    # ── Top 3 failing controls ─────────────────────────────────────────
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Top Failing Controls', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', 'B', 8)
    pdf.set_fill_color(210, 210, 210)
    row('Control ID', 30, 'Title', 100, 'Severity', 30, 'Count', 30, h=7, fill=True)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_fill_color(255, 255, 255)
    for c in summary.get('topControls', [])[:3]:
        row(str(c['id'])[:18], 30, _pdf_safe(str(c['title'])[:60]), 100, str(c['severity']), 30, str(c['count']), 30, h=6)

    # =====================================================================
    # PAGE 2+ — FULL FINDINGS DETAIL, GROUPED BY SEVERITY, NEW BADGE
    # =====================================================================
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 13)
    pdf.cell(0, 8, f'All Findings ({len(findings)} total)', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(1)

    for sev in ordered_severities:
        sev_findings = by_severity.get(sev, [])
        if not sev_findings:
            continue

        pdf.set_font('Helvetica', 'B', 11)
        pdf.cell(0, 8, f'{sev} ({len(sev_findings)})', new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        pdf.set_font('Helvetica', 'B', 8)
        pdf.set_fill_color(210, 210, 210)
        row('New?', 12, 'Control ID', 28, 'Finding Title', 82, 'Resource', 48, 'Region', 20, h=7, fill=True)

        pdf.set_font('Helvetica', '', 7)
        pdf.set_fill_color(*fill_by_severity.get(sev, (255, 255, 255)))
        # Sorted so NEW findings surface first, then by control id
        sorted_findings = sorted(
            sev_findings,
            key=lambda f: (not is_new_finding(f, now), f.get('ProductFields', {}).get('ControlId') or '')
        )
        for f in sorted_findings:
            badge = 'NEW' if is_new_finding(f, now) else ''
            control_id = _pdf_safe((f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', ''))[:15])
            title = _pdf_safe(f.get('Title', 'Unknown finding')[:50])
            resources = f.get('Resources', [{}])
            resource_id = resources[0].get('Id', 'unknown') if resources else 'unknown'
            resource_short = _pdf_safe(resource_id[-30:] if len(resource_id) > 30 else resource_id)
            region = f.get('Region', '')[:10]
            row(badge, 12, control_id, 28, title, 82, resource_short, 48, region, 20, h=6, fill=True)
        pdf.ln(4)

    # =====================================================================
    # PAGE N — FINDINGS BY RESOURCE TYPE
    # =====================================================================
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 13)
    pdf.cell(0, 8, 'Findings by Resource Type', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_text_color(110, 110, 110)
    pdf.cell(0, 5, 'Which AWS services are contributing the most findings, across all severities.',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(2)

    pdf.set_font('Helvetica', 'B', 8)
    pdf.set_fill_color(210, 210, 210)
    row('Resource Type', 66, 'Critical', 26, 'High', 26, 'Medium', 26, 'Low', 26, 'Total', 20, h=7, fill=True)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_fill_color(255, 255, 255)

    type_rows = []
    for rtype, flist in by_resource_type.items():
        counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        for f in flist:
            sev = f.get('Severity', {}).get('Label', 'LOW')
            if sev in counts:
                counts[sev] += 1
        type_rows.append((rtype, counts, len(flist)))
    type_rows.sort(key=lambda t: -t[2])

    for rtype, counts, total in type_rows:
        row(rtype[:38], 66, str(counts['CRITICAL']), 26, str(counts['HIGH']), 26,
            str(counts['MEDIUM']), 26, str(counts['LOW']), 26, str(total), 20, h=6)

    return bytes(pdf.output())


def build_csv_report(account_id, account_name, findings):
    """CSV with one row per finding, sorted Critical -> High -> Medium -> Low,
    new findings first within each severity, then by Control ID (matches
    the PDF's ordering). Severity is the first column since that's the
    most common filter/sort users apply in Excel."""
    now = datetime.now(timezone.utc)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Severity', 'IsNew', 'ControlId', 'Title', 'ResourceType', 'ResourceId', 'Region',
        'WorkflowStatus', 'RecordState', 'FirstObservedAt', 'AccountId', 'AccountName',
    ])

    severity_rank = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}
    sorted_findings = sorted(
        findings,
        key=lambda f: (
            severity_rank.get(f.get('Severity', {}).get('Label', 'LOW'), 99),
            not is_new_finding(f, now),
            f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', ''),
        )
    )

    for f in sorted_findings:
        sev = f.get('Severity', {}).get('Label', 'LOW')
        title = f.get('Title', 'Unknown finding')
        resources = f.get('Resources', [{}])
        resource_id = resources[0].get('Id', 'unknown') if resources else 'unknown'
        resource_type = get_resource_type(f)
        control_id = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
        workflow_status = f.get('Workflow', {}).get('Status', 'UNKNOWN')
        record_state = f.get('RecordState', 'UNKNOWN')
        first_observed = f.get('FirstObservedAt', '')
        region = f.get('Region', '')
        is_new = 'YES' if is_new_finding(f, now) else ''

        writer.writerow([
            sev, is_new, control_id, title, resource_type, resource_id, region,
            workflow_status, record_state, first_observed, account_id, account_name,
        ])

    return output.getvalue().encode('utf-8')



# ---------------------------------------------------------------------------
# Snapshot helpers — day-over-day comparison
# ---------------------------------------------------------------------------

def _finding_fingerprint(f):
    """Stable unique key for a finding: account + control + resource.
    Works on both raw Security Hub findings and condensed finding dicts."""
    # condensed finding dict
    if 'controlId' in f:
        return f"{f.get('accountId', f.get('AwsAccountId', 'UNKNOWN'))}|{f.get('controlId','')}|{f.get('resourceId','')}"
    # raw Security Hub finding
    resources  = f.get('Resources', [{}])
    resource_id = resources[0].get('Id', 'unknown') if resources else 'unknown'
    control_id  = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
    return f"{f.get('AwsAccountId', 'UNKNOWN')}|{control_id}|{resource_id}"


def write_daily_snapshot(findings):
    """Write today's open findings to snapshots/{YYYY-MM-DD}/findings.json.
    Stored for historical trend analysis; compared to yesterday's to find deltas."""
    today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    condensed = []
    for f in findings:
        cf = condense_finding(f)
        cf['_fp']       = _finding_fingerprint(f)
        cf['accountId'] = f.get('AwsAccountId', 'UNKNOWN')
        condensed.append(cf)
    s3.put_object(
        Bucket=BUCKET,
        Key=f'snapshots/{today}/findings.json',
        Body=json.dumps(condensed),
        ContentType='application/json',
    )
    logger.info('Snapshot written: snapshots/%s/findings.json (%d findings)', today, len(condensed))
    return condensed


def load_yesterday_snapshot():
    """Load yesterday's snapshot. Returns an empty list if none exists
    (first run, or yesterday's Lambda was skipped)."""
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d')
    try:
        obj  = s3.get_object(Bucket=BUCKET, Key=f'snapshots/{yesterday}/findings.json')
        data = json.loads(obj['Body'].read().decode())
        logger.info('Loaded yesterday snapshot: %d findings from %s', len(data), yesterday)
        return data
    except s3.exceptions.NoSuchKey:
        logger.info('No snapshot found for %s — first run or gap in schedule', yesterday)
        return []
    except Exception as exc:
        logger.warning('Could not load yesterday snapshot: %s', exc)
        return []


def compare_snapshots(today_condensed, yesterday_condensed):
    """Compare today vs yesterday by fingerprint.

    Returns:
        new_findings      — in today, not in yesterday (newly introduced)
        resolved_findings — in yesterday, not in today (remediated / suppressed)
    """
    today_fps     = {cf['_fp']: cf for cf in today_condensed     if '_fp' in cf}
    yesterday_fps = {cf['_fp']: cf for cf in yesterday_condensed if '_fp' in cf}

    new_findings      = [cf for fp, cf in today_fps.items()     if fp not in yesterday_fps]
    resolved_findings = [cf for fp, cf in yesterday_fps.items() if fp not in today_fps]

    new_crit_high = sum(1 for f in new_findings if f.get('severity', '') in ('CRITICAL', 'HIGH'))
    logger.info('Snapshot delta — new: %d (Crit/High: %d), resolved: %d',
                len(new_findings), new_crit_high, len(resolved_findings))
    return new_findings, resolved_findings


# ---------------------------------------------------------------------------
# Excel report — 3 tabs: Failed / Passed / Previously-Failed-Now-Passed
# ---------------------------------------------------------------------------

def build_excel_report(account_id, account_name,
                        failed_findings,
                        passed_findings,
                        resolved_findings,
                        account_names):
    """Build a 3-tab Excel workbook and return raw bytes.
    Returns None (gracefully) if openpyxl is not installed."""
    if not EXCEL_AVAILABLE:
        return None

    try:
        from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        return None

    SEV_FILL = {
        'CRITICAL': 'F8D7DA',
        'HIGH':     'FFF3CD',
        'MEDIUM':   'D1ECF1',
        'LOW':      'F8F9FA',
    }

    def _hdr(ws, headers, bg='1E2761', fg='FFFFFF'):
        fill   = PatternFill('solid', fgColor=bg)
        font   = Font(bold=True, color=fg, name='Calibri', size=10)
        align  = Alignment(horizontal='center', vertical='center', wrap_text=True)
        thin   = Side(style='thin', color='C0C0C0')
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        ws.append(headers)
        for cell in ws[ws.max_row]:
            cell.fill = fill; cell.font = font
            cell.alignment = align; cell.border = border
        ws.row_dimensions[ws.max_row].height = 22

    def _row(ws, values, bg=None):
        thin   = Side(style='thin', color='E0E0E0')
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        fill   = PatternFill('solid', fgColor=bg) if bg else None
        ws.append(values)
        for cell in ws[ws.max_row]:
            cell.font      = Font(name='Calibri', size=9)
            cell.alignment = Alignment(vertical='center', wrap_text=True)
            cell.border    = border
            if fill:
                cell.fill = fill
        ws.row_dimensions[ws.max_row].height = 16

    def _widths(ws, widths):
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

    wb = openpyxl.Workbook()

    # ── Tab 1: Failed Checks ─────────────────────────────────────────────
    ws1 = wb.active
    ws1.title = 'Failed Checks'
    _hdr(ws1, ['Severity','ControlId','Title','ResourceId','ResourceType',
               'Region','WorkflowStatus','FirstObservedAt','AccountId','AccountName'])
    sev_rank = {s: i for i, s in enumerate(SEVERITY_ORDER)}
    for f in sorted(failed_findings,
                    key=lambda x: (sev_rank.get(x.get('Severity',{}).get('Label','LOW'),99),
                                   x.get('ProductFields',{}).get('ControlId') or '')):
        sev  = f.get('Severity', {}).get('Label', 'LOW')
        res  = f.get('Resources', [{}])
        acct = f.get('AwsAccountId', account_id)
        _row(ws1, [sev,
                   f.get('ProductFields',{}).get('ControlId') or f.get('GeneratorId',''),
                   f.get('Title',''),
                   res[0].get('Id','') if res else '',
                   res[0].get('Type','') if res else '',
                   f.get('Region',''),
                   f.get('Workflow',{}).get('Status',''),
                   f.get('FirstObservedAt',''),
                   acct, account_names.get(acct, acct)],
             SEV_FILL.get(sev))
    _widths(ws1, [12,18,55,55,28,14,16,22,16,22])
    ws1.freeze_panes = 'A2'

    # ── Tab 2: Passed Checks ─────────────────────────────────────────────
    ws2 = wb.create_sheet('Passed Checks')
    _hdr(ws2, ['ControlId','Title','ResourceId','AccountId','AccountName'], '155724')
    seen = set()
    for f in passed_findings:
        if account_id not in ('ALL', f.get('AwsAccountId','')):
            continue
        ctrl = f.get('ProductFields',{}).get('ControlId') or f.get('GeneratorId','')
        res  = f.get('Resources',[{}])
        rid  = res[0].get('Id','') if res else ''
        acct = f.get('AwsAccountId', account_id)
        key  = (acct, ctrl, rid)
        if key in seen:
            continue
        seen.add(key)
        _row(ws2, [ctrl, f.get('Title',''), rid, acct, account_names.get(acct,acct)], 'E8F5E9')
    _widths(ws2, [20,65,60,16,22])
    ws2.freeze_panes = 'A2'

    # ── Tab 3: Previously Failed, Now Passed ─────────────────────────────
    ws3 = wb.create_sheet('Previously Failed - Now Passed')
    _hdr(ws3, ['Severity','ControlId','Title','ResourceId','Region',
               'AccountId','AccountName','FirstObservedAt'], '0D47A1')
    for r in resolved_findings:
        acct = r.get('accountId', account_id)
        if account_id not in ('ALL', acct):
            continue
        _row(ws3, [r.get('severity',''), r.get('controlId',''),
                   r.get('title',''), r.get('resourceId',''),
                   r.get('region',''), acct, account_names.get(acct,acct),
                   r.get('firstObservedAt','')], 'E3F2FD')
    _widths(ws3, [12,20,55,55,14,16,22,22])
    ws3.freeze_panes = 'A2'

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# SES email digest — new Critical/High findings
# ---------------------------------------------------------------------------

def send_email_digest(new_findings, account_names):
    """Send an HTML email via SES listing new Critical/High findings.
    Silently skips if SES_TO_EMAIL is still the placeholder or SES call fails."""
    if 'UPDATE_YOUR_DL' in SES_TO_EMAIL:
        logger.info('SES email skipped — SES_TO_EMAIL is still the placeholder value.')
        return

    crit_high = [f for f in new_findings if f.get('severity','') in ('CRITICAL','HIGH')]
    if not crit_high:
        logger.info('No new Critical/High findings — email digest not sent.')
        return

    today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    rows_html = ''
    for f in sorted(crit_high, key=lambda x: (x.get('severity',''), x.get('controlId',''))):
        sev   = f.get('severity','')
        color = '#dc3545' if sev == 'CRITICAL' else '#fd7e14'
        acct  = f.get('accountId','')
        rows_html += f"""
        <tr>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;">
            <span style="background:{color};color:#fff;padding:2px 8px;border-radius:4px;
                         font-size:11px;font-weight:bold;">{sev}</span></td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-family:monospace;font-size:12px;">{f.get('controlId','')}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;">{f.get('title','')}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-size:11px;">
            {account_names.get(acct, acct)}<br><span style="color:#888;">{acct}</span></td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-family:monospace;font-size:11px;">{f.get('resourceId','')[-50:]}</td>
        </tr>"""

    html_body = f"""
    <html><body style="font-family:Calibri,Arial,sans-serif;color:#1c2340;max-width:900px;margin:0 auto;">
      <div style="background:#1E2761;padding:18px 24px;border-radius:6px 6px 0 0;">
        <h2 style="color:#fff;margin:0;font-size:18px;">
          &#x1F514; Security Hub &#8212; New Critical/High Findings ({today})
        </h2>
      </div>
      <div style="background:#f5f7fc;padding:14px 24px;border:1px solid #dde4f0;border-top:none;">
        <p style="margin:0;font-size:13px;">
          <strong>{len(crit_high)}</strong> new Critical or High severity finding(s) appeared since
          yesterday&#x2019;s scan. Full details and downloadable reports are available on the
          <a href="https://security.vijaymdm.click" style="color:#2E6DA4;">Security Hub Dashboard</a>.
        </p>
      </div>
      <table width="100%" cellpadding="0" cellspacing="0"
             style="border-collapse:collapse;border:1px solid #dde4f0;border-top:none;">
        <thead style="background:#eef2f7;">
          <tr>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Severity</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Control ID</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Finding</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Account</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Resource</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
      <div style="padding:12px 24px;background:#f5f7fc;border:1px solid #dde4f0;border-top:none;
                  border-radius:0 0 6px 6px;">
        <p style="margin:0;font-size:11px;color:#888;">
          Sent by Security Hub Aggregator v{AGGREGATOR_VERSION} &middot; {today}
          &middot; Auto-generated &#8212; do not reply.
        </p>
      </div>
    </body></html>"""

    try:
        ses.send_email(
            Source=SES_FROM_EMAIL,
            Destination={'ToAddresses': [SES_TO_EMAIL]},
            Message={
                'Subject': {'Data': f'[Security Hub] {len(crit_high)} New Critical/High Finding(s) — {today}'},
                'Body': {
                    'Html': {'Data': html_body},
                    'Text': {'Data': (
                        f'Security Hub: {len(crit_high)} new Critical/High findings on {today}. '
                        'See dashboard: https://security.vijaymdm.click'
                    )},
                },
            },
        )
        logger.info('SES digest sent to %s (%d new Crit/High findings)', SES_TO_EMAIL, len(crit_high))
    except Exception as exc:
        logger.warning('SES send_email failed (check SES verification + IAM): %s', exc)


# ---------------------------------------------------------------------------
# S3 write helpers — Security Hub summaries + Trusted Advisor
# ---------------------------------------------------------------------------

def write_to_s3(summaries, by_account, account_names, all_accounts_score):
    """Write all Security Hub summaries to S3:
      summaries/accounts.json            — account list for dashboard dropdown
      summaries/{account_id}/latest.json — per-account summary (score, severities)
      summaries/{account_id}/findings.json — condensed findings for drill-down
      summaries/all/latest.json          — aggregated all-accounts summary
      summaries/all/findings.json        — all findings combined
      summaries/version.json             — aggregator version + last run timestamp

    Per-account puts run in a thread pool (S3_WRITE_MAX_WORKERS) so 70+
    accounts don't block serially.  The combined all/version objects are
    written after the pool completes because they depend on all_condensed.
    """
    S3_WRITE_MAX_WORKERS = 20  # safe: S3 PutObject is I/O-bound, no API rate limit concern

    # Account index — written first (fast, single put)
    account_list = [
        {'id': aid, 'name': account_names.get(aid, aid), 'accountId': aid}
        for aid in sorted(summaries.keys())
    ]
    s3.put_object(Bucket=BUCKET, Key='summaries/accounts.json',
                  Body=json.dumps(account_list), ContentType='application/json')

    # Build all condensed finding lists in memory (pure Python, no I/O)
    condensed_by_account = {
        account_id: [condense_finding(f) for f in by_account.get(account_id, [])]
        for account_id in summaries
    }
    all_condensed = [c for clist in condensed_by_account.values() for c in clist]

    def _put_account(account_id):
        summary   = summaries[account_id]
        condensed = condensed_by_account[account_id]
        s3.put_object(Bucket=BUCKET, Key=f'summaries/{account_id}/latest.json',
                      Body=json.dumps(summary), ContentType='application/json')
        s3.put_object(Bucket=BUCKET, Key=f'summaries/{account_id}/findings.json',
                      Body=json.dumps(condensed), ContentType='application/json')

    # Fan-out per-account puts in parallel
    with ThreadPoolExecutor(max_workers=S3_WRITE_MAX_WORKERS) as pool:
        futures = {pool.submit(_put_account, aid): aid for aid in summaries}
        for future in as_completed(futures):
            aid = futures[future]
            try:
                future.result()
            except Exception as exc:
                logger.warning('write_to_s3: failed to write summaries for account %s: %s', aid, exc)

    # All-accounts combined summary
    all_summary = {
        'accountId': 'all',
        'critical': sum(s['critical'] for s in summaries.values()),
        'high':     sum(s['high']     for s in summaries.values()),
        'medium':   sum(s['medium']   for s in summaries.values()),
        'low':      sum(s['low']      for s in summaries.values()),
        'score':                  all_accounts_score['score'],
        'passedControls':         all_accounts_score['passedControls'],
        'failedControls':         all_accounts_score['failedControls'],
        'warningControls':        all_accounts_score['warningControls'],
        'totalEnabledControls':   all_accounts_score['totalEnabledControls'],
        'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'topControls': [],
    }
    s3.put_object(Bucket=BUCKET, Key='summaries/all/latest.json',
                  Body=json.dumps(all_summary), ContentType='application/json')
    s3.put_object(Bucket=BUCKET, Key='summaries/all/findings.json',
                  Body=json.dumps(all_condensed), ContentType='application/json')

    # Version marker — consumed by /version API route
    s3.put_object(
        Bucket=BUCKET, Key='summaries/version.json',
        Body=json.dumps({
            'aggregatorVersion': AGGREGATOR_VERSION,
            'lastRun': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        }),
        ContentType='application/json',
    )
    logger.info('write_to_s3: wrote %d account summaries + all + version', len(summaries))


def fetch_trusted_advisor_checks(account_id, own_account_id):
    """Fetch Trusted Advisor checks for a single account.
    Uses the Lambda's own credentials for the delegated-admin account,
    or assumes TA_READER_ROLE_NAME in member accounts via STS.
    Returns a list of check dicts, or [] on any error."""
    try:
        if account_id == own_account_id:
            # Support API is global — must always target us-east-1
            support = boto3.client('support', region_name='us-east-1')
        else:
            role_arn = f'arn:aws:iam::{account_id}:role/{TA_READER_ROLE_NAME}'
            # Include account_id in session name so concurrent executions
            # for different accounts never share the same STS session.
            creds = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f'TAReader-{account_id}',
                # ExternalId matches the condition in securityhub-member-role.yaml
                # trust policy — prevents confused deputy attacks.
                ExternalId=f'{account_id}-ta-reader',
            )['Credentials']
            # Support API is global — must always target us-east-1
            support = boto3.client(
                'support', region_name='us-east-1',
                aws_access_key_id=creds['AccessKeyId'],
                aws_secret_access_key=creds['SecretAccessKey'],
                aws_session_token=creds['SessionToken'],
            )

        checks_resp = support.describe_trusted_advisor_checks(language='en')
        checks = []
        for check in checks_resp.get('checks', []):
            try:
                result = support.describe_trusted_advisor_check_result(
                    checkId=check['id'], language='en'
                )
                r = result.get('result', {})
                checks.append({
                    'id':       check['id'],
                    'name':     check['name'],
                    'category': check.get('category', ''),
                    'status':   r.get('status', 'not_available'),
                    'resourcesSummary':        r.get('resourcesSummary'),
                    'estimatedMonthlySavings': r.get('categorySpecificSummary', {})
                                                 .get('costOptimizing', {})
                                                 .get('estimatedMonthlySavings'),
                })
            except Exception as check_err:
                logger.warning('TA check %s skipped for account %s: %s',
                               check['id'], account_id, check_err)
        logger.info('TA fetched %d checks for account %s', len(checks), account_id)
        return checks

    except Exception as e:
        logger.warning('fetch_trusted_advisor_checks failed for account %s: %s', account_id, e)
        return []


def summarize_ta_by_account(ta_by_account):
    """Build per-account and all-accounts Trusted Advisor summaries."""
    ta_summaries = {}
    all_checks_combined = []

    for account_id, checks in ta_by_account.items():
        total_error   = sum(1 for c in checks if c['status'] == 'error')
        total_warning = sum(1 for c in checks if c['status'] == 'warning')
        total_ok      = sum(1 for c in checks if c['status'] == 'ok')
        ta_summaries[account_id] = {
            'accountId':    account_id,
            'totalError':   total_error,
            'totalWarning': total_warning,
            'totalOk':      total_ok,
            'lastRefresh':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'checks':       checks,
        }
        all_checks_combined.extend(checks)

    all_error   = sum(1 for c in all_checks_combined if c['status'] == 'error')
    all_warning = sum(1 for c in all_checks_combined if c['status'] == 'warning')
    all_ok      = sum(1 for c in all_checks_combined if c['status'] == 'ok')
    ta_all_summary = {
        'accountId':    'all',
        'totalError':   all_error,
        'totalWarning': all_warning,
        'totalOk':      all_ok,
        'lastRefresh':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'checks':       all_checks_combined,
    }

    return ta_summaries, ta_all_summary


def write_ta_to_s3(ta_summaries_by_account, ta_all_summary):
    """Write Trusted Advisor summaries to S3:
      trusted-advisor/{account_id}/latest.json — per-account TA summary
      trusted-advisor/all/latest.json          — all-accounts TA summary
    """
    for account_id, summary in ta_summaries_by_account.items():
        s3.put_object(
            Bucket=BUCKET,
            Key=f'trusted-advisor/{account_id}/latest.json',
            Body=json.dumps(summary),
            ContentType='application/json',
        )
    s3.put_object(
        Bucket=BUCKET,
        Key='trusted-advisor/all/latest.json',
        Body=json.dumps(ta_all_summary),
        ContentType='application/json',
    )
    logger.info('write_ta_to_s3: wrote %d account TA summaries + all',
                len(ta_summaries_by_account))


# ---------------------------------------------------------------------------
# Inspector — summarisation and S3 writer
# ---------------------------------------------------------------------------

def summarize_inspector_by_account(inspector_findings):
    """Group Inspector v2 findings by account and compute per-account summary.

    Each finding is a CVE / package vulnerability / code finding from Inspector.
    We track:
      - severity counts (CRITICAL / HIGH / MEDIUM / LOW)
      - finding type breakdown (PACKAGE_VULNERABILITY, CODE_VULNERABILITY, NETWORK_REACHABILITY, etc.)
      - top 10 most-affected resources (by finding count)
      - top 10 most-common CVEs / rule titles (by count)

    Returns (summaries_by_account, all_accounts_summary).
    """
    by_account = defaultdict(list)
    for f in inspector_findings:
        acct = f.get('AwsAccountId', 'UNKNOWN')
        by_account[acct].append(f)

    summaries = {}
    for account_id, findings in by_account.items():
        sev_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        type_counts = defaultdict(int)
        resource_counts = defaultdict(int)
        title_counts = defaultdict(int)

        for f in findings:
            sev = f.get('Severity', {}).get('Label', 'LOW')
            if sev in sev_counts:
                sev_counts[sev] += 1

            # Finding type — from Types array, e.g. "Software and Configuration Checks/Vulnerabilities/CVE"
            types = f.get('Types', [])
            ftype = types[0].split('/')[-1] if types else 'Other'
            type_counts[ftype] += 1

            # Resource
            resources = f.get('Resources', [{}])
            resource_id = resources[0].get('Id', 'unknown') if resources else 'unknown'
            # Use last 60 chars to keep it readable
            resource_short = resource_id[-60:] if len(resource_id) > 60 else resource_id
            resource_counts[resource_short] += 1

            # Title (CVE ID or rule name)
            title_counts[f.get('Title', 'Unknown')] += 1

        top_resources = sorted(
            [{'resourceId': r, 'count': c} for r, c in resource_counts.items()],
            key=lambda x: -x['count']
        )[:10]

        top_findings = sorted(
            [{'title': t, 'count': c} for t, c in title_counts.items()],
            key=lambda x: -x['count']
        )[:10]

        summaries[account_id] = {
            'accountId':   account_id,
            'critical':    sev_counts['CRITICAL'],
            'high':        sev_counts['HIGH'],
            'medium':      sev_counts['MEDIUM'],
            'low':         sev_counts['LOW'],
            'total':       len(findings),
            'byType':      dict(type_counts),
            'topResources': top_resources,
            'topFindings':  top_findings,
            'lastScan':    datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            # Condensed findings list for drill-down (capped at 500 per account)
            'findings': [
                {
                    'severity':       f.get('Severity', {}).get('Label', 'LOW'),
                    'title':          f.get('Title', 'Unknown finding'),
                    'resourceId':     (f.get('Resources', [{}])[0].get('Id', 'unknown')),
                    'resourceType':   (f.get('Resources', [{}])[0].get('Type', 'Unknown')),
                    'region':         f.get('Region', ''),
                    'firstObservedAt': f.get('FirstObservedAt', ''),
                    'cveIds':         [
                        v.get('Id', '') for v in f.get('Vulnerabilities', [{}])
                        if v.get('Id')
                    ][:3],
                }
                for f in sorted(
                    findings,
                    key=lambda x: SEVERITY_RANK.get(x.get('Severity', {}).get('Label', 'LOW'), 99)
                )
            ][:500],
        }

    # All-accounts combined summary
    all_summary = {
        'accountId': 'all',
        'critical': sum(s['critical'] for s in summaries.values()),
        'high':     sum(s['high']     for s in summaries.values()),
        'medium':   sum(s['medium']   for s in summaries.values()),
        'low':      sum(s['low']      for s in summaries.values()),
        'total':    sum(s['total']    for s in summaries.values()),
        'byType':   {},
        'topResources': [],
        'topFindings':  [],
        'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'findings': [],
    }
    # Merge byType across all accounts
    all_type_counts = defaultdict(int)
    for s in summaries.values():
        for ftype, cnt in s.get('byType', {}).items():
            all_type_counts[ftype] += cnt
    all_summary['byType'] = dict(all_type_counts)

    # Top resources and findings across all accounts (from raw findings)
    all_resource_counts = defaultdict(int)
    all_title_counts = defaultdict(int)
    for f in inspector_findings:
        resources = f.get('Resources', [{}])
        rid = resources[0].get('Id', 'unknown') if resources else 'unknown'
        all_resource_counts[rid[-60:] if len(rid) > 60 else rid] += 1
        all_title_counts[f.get('Title', 'Unknown')] += 1

    all_summary['topResources'] = sorted(
        [{'resourceId': r, 'count': c} for r, c in all_resource_counts.items()],
        key=lambda x: -x['count']
    )[:10]
    all_summary['topFindings'] = sorted(
        [{'title': t, 'count': c} for t, c in all_title_counts.items()],
        key=lambda x: -x['count']
    )[:10]

    return summaries, all_summary


def write_inspector_to_s3(inspector_summaries, all_inspector_summary):
    """Write Inspector summaries to S3:
      inspector/{account_id}/latest.json — per-account Inspector summary + findings
      inspector/all/latest.json          — all-accounts Inspector summary
    """
    for account_id, summary in inspector_summaries.items():
        s3.put_object(
            Bucket=BUCKET,
            Key=f'inspector/{account_id}/latest.json',
            Body=json.dumps(summary),
            ContentType='application/json',
        )
    s3.put_object(
        Bucket=BUCKET,
        Key='inspector/all/latest.json',
        Body=json.dumps(all_inspector_summary),
        ContentType='application/json',
    )
    logger.info('write_inspector_to_s3: wrote %d account Inspector summaries + all',
                len(inspector_summaries))


# ---------------------------------------------------------------------------
# Report generation — PDF + CSV + Excel (all three per account)
# ---------------------------------------------------------------------------

# Number of accounts whose reports are built + uploaded in parallel.
# Each worker is I/O-bound (S3 puts) with bursts of CPU (fpdf2 / openpyxl).
# 10 workers cuts wall-clock time for 70 accounts from ~70× to ~7× serial cost.
# Tune down if Lambda memory pressure (Max Memory Used > 90%) is observed.
REPORT_MAX_WORKERS = 10


def _build_and_upload_account_report(account_id, name, summary, findings,
                                      passed_findings, resolved_findings, account_names):
    """Build PDF + CSV + Excel for a single account and upload all three to S3.
    Designed to run inside a ThreadPoolExecutor worker — any exception is
    caught here so one bad account never blocks the others."""
    try:
        t0 = time.perf_counter()

        pdf_bytes = build_pdf_report(account_id, name, summary, findings)
        t_pdf = time.perf_counter()
        s3.put_object(Bucket=BUCKET, Key=f'reports/{account_id}/latest.pdf',
                      Body=pdf_bytes, ContentType='application/pdf')
        t_pdf_s3 = time.perf_counter()

        csv_bytes = build_csv_report(account_id, name, findings)
        t_csv = time.perf_counter()
        s3.put_object(Bucket=BUCKET, Key=f'reports/{account_id}/latest.csv',
                      Body=csv_bytes, ContentType='text/csv')
        t_csv_s3 = time.perf_counter()

        xl_s = 0.0
        if EXCEL_AVAILABLE:
            xl = build_excel_report(account_id, name, findings,
                                    passed_findings, resolved_findings, account_names)
            t_xl = time.perf_counter()
            xl_s = t_xl - t_csv_s3
            if xl:
                s3.put_object(
                    Bucket=BUCKET, Key=f'reports/{account_id}/latest.xlsx',
                    Body=xl,
                    ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        else:
            t_xl = time.perf_counter()

        total = time.perf_counter() - t0
        logger.info(
            'TIMING report account=%s findings=%d pdf_s=%.2f pdf_s3_s=%.2f '
            'csv_s=%.2f csv_s3_s=%.2f xlsx_s=%.2f total_s=%.2f',
            account_id, len(findings),
            t_pdf    - t0,
            t_pdf_s3 - t_pdf,
            t_csv    - t_pdf_s3,
            t_csv_s3 - t_csv,
            xl_s,
            total,
        )
    except Exception as exc:
        logger.exception(
            'Report generation failed for account %s (%s) — skipping: %s',
            account_id, name, exc,
        )
        return False
    return True


def generate_and_upload_reports(summaries, by_account, account_names, all_control_score,
                                 passed_findings=None, resolved_findings=None):
    passed_findings   = passed_findings   or []
    resolved_findings = resolved_findings or []

    # ── Per-account reports — parallelised ──────────────────────────────
    # Each account's PDF + CSV + XLSX build + S3 upload runs in its own
    # thread. boto3 S3 clients are thread-safe; fpdf2 and openpyxl create
    # independent in-memory objects so there is no shared mutable state.
    errors = 0
    with ThreadPoolExecutor(max_workers=REPORT_MAX_WORKERS) as pool:
        future_to_account = {
            pool.submit(
                _build_and_upload_account_report,
                account_id,
                account_names.get(account_id, account_id),
                summary,
                by_account.get(account_id, []),
                passed_findings,
                resolved_findings,
                account_names,
            ): account_id
            for account_id, summary in summaries.items()
        }
        for future in as_completed(future_to_account):
            if not future.result():
                errors += 1

    if errors:
        logger.warning('generate_and_upload_reports: %d account(s) failed — see above', errors)

    # ── Combined "all accounts" reports — built after per-account work ──
    all_findings = [f for flist in by_account.values() for f in flist]
    all_summary  = {
        'critical': sum(s['critical'] for s in summaries.values()),
        'high':     sum(s['high']     for s in summaries.values()),
        'medium':   sum(s['medium']   for s in summaries.values()),
        'low':      sum(s['low']      for s in summaries.values()),
        'score':                  all_control_score['score'],
        'passedControls':         all_control_score['passedControls'],
        'failedControls':         all_control_score['failedControls'],
        'warningControls':        all_control_score['warningControls'],
        'totalEnabledControls':   all_control_score['totalEnabledControls'],
        'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'topControls': [],
    }

    pdf_bytes = build_pdf_report('ALL', 'All Accounts', all_summary, all_findings)
    s3.put_object(Bucket=BUCKET, Key='reports/all/latest.pdf',
                   Body=pdf_bytes, ContentType='application/pdf')

    csv_bytes = build_csv_report('ALL', 'All Accounts', all_findings)
    s3.put_object(Bucket=BUCKET, Key='reports/all/latest.csv',
                   Body=csv_bytes, ContentType='text/csv')

    if EXCEL_AVAILABLE:
        xl = build_excel_report('ALL', 'All Accounts', all_findings,
                                 passed_findings, resolved_findings, account_names)
        if xl:
            s3.put_object(
                Bucket=BUCKET, Key='reports/all/latest.xlsx',
                Body=xl,
                ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    handler_start = time.perf_counter()

    def remaining_ms():
        """Milliseconds left before Lambda hard timeout. Returns a large number
        if context is missing (e.g. local test invocation)."""
        try:
            return context.get_remaining_time_in_millis()
        except Exception:
            return 999_999_999

    account_names  = get_account_names()
    own_account_id = sts.get_caller_identity()['Account']
    logger.info('Running as account %s, processing %d known accounts',
                own_account_id, len(account_names))
    logger.info('Aggregator version: %s', AGGREGATOR_VERSION)

    # ── Security Hub: open findings (severity counts / top controls / reports) ──
    with _timed('fetch_all_findings'):
        findings = fetch_all_findings()
    logger.info('fetch_all_findings: %d findings', len(findings))

    with _timed('summarize_by_account'):
        summaries, by_account = summarize_by_account(findings)

    # ── Security Hub: real AWS-formula compliance score ──────────────────
    with _timed('fetch_all_compliance_findings'):
        compliance_findings = fetch_all_compliance_findings()
    logger.info('fetch_all_compliance_findings: %d findings', len(compliance_findings))

    with _timed('compute_control_scores'):
        per_account_scores, all_accounts_score = compute_control_scores(compliance_findings)

    for account_id, summary in summaries.items():
        control_score = per_account_scores.get(account_id, {
            'passedControls': 0, 'failedControls': 0,
            'warningControls': 0, 'totalEnabledControls': 0, 'score': 0,
        })
        summary.update(control_score)

    # Add 100%-clean accounts so they still appear in the dashboard
    for account_id, control_score in per_account_scores.items():
        if account_id in summaries or not account_id:
            continue
        summaries[account_id] = {
            'accountId': account_id,
            'critical': 0, 'high': 0, 'medium': 0, 'low': 0,
            'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'topControls': [], **control_score,
        }
        by_account[account_id] = []

    # ── Day-over-day snapshot comparison ────────────────────────────────
    with _timed('write_daily_snapshot'):
        today_snapshot = write_daily_snapshot(findings)
    with _timed('load_yesterday_snapshot'):
        yesterday_snapshot = load_yesterday_snapshot()
    with _timed('compare_snapshots'):
        new_findings, resolved_findings = compare_snapshots(today_snapshot, yesterday_snapshot)

    # Passed findings list for Excel Tab 2
    passed_raw = [f for f in compliance_findings
                  if f.get('Compliance', {}).get('Status') == 'PASSED']

    # ── Write S3 summaries ───────────────────────────────────────────────
    with _timed('write_to_s3'):
        write_to_s3(summaries, by_account, account_names, all_accounts_score)

    # ── Report generation — guarded by remaining time budget ─────────────
    # Building PDF + CSV + Excel for a large number of findings is the most
    # CPU/memory-intensive step. Skip it if less than 120 s remain so that
    # summaries (already written above) are never lost to a hard timeout.
    REPORT_TIME_GUARD_MS = 120_000  # 2 minutes minimum headroom required
    rem = remaining_ms()
    logger.info('TIMING before_reports remaining_ms=%d', rem)
    if rem > REPORT_TIME_GUARD_MS:
        with _timed('generate_and_upload_reports'):
            generate_and_upload_reports(
                summaries, by_account, account_names, all_accounts_score,
                passed_findings=passed_raw,
                resolved_findings=resolved_findings,
            )
        logger.info('Security Hub: wrote summaries/reports for %d accounts', len(summaries))
    else:
        logger.warning(
            'TIMING skipping report generation — only %d ms remaining (threshold %d ms). '
            'Summaries already written. Increase AggregatorTimeout or reduce finding volume.',
            rem, REPORT_TIME_GUARD_MS,
        )

    # ── SES email digest ─────────────────────────────────────────────────
    with _timed('send_email_digest'):
        send_email_digest(new_findings, account_names)

    # ── Trusted Advisor — concurrent fetch, max 10 accounts in parallel ─
    all_account_ids = set(summaries.keys()) | set(account_names.keys())
    all_account_ids.discard('')

    ta_by_account = {}
    ta_errors     = 0
    TA_MAX_WORKERS = 10  # tune down if Support API throttling occurs

    with _timed('fetch_trusted_advisor_all_accounts'):
        with ThreadPoolExecutor(max_workers=TA_MAX_WORKERS) as pool:
            future_to_account = {
                pool.submit(fetch_trusted_advisor_checks, aid, own_account_id): aid
                for aid in sorted(all_account_ids)
            }
            for future in as_completed(future_to_account):
                aid = future_to_account[future]
                try:
                    checks = future.result()
                    if checks:
                        ta_by_account[aid] = checks
                    else:
                        ta_errors += 1
                except Exception as exc:
                    logger.warning('TA future for account %s raised unexpectedly: %s', aid, exc)
                    ta_errors += 1

    if ta_by_account:
        with _timed('summarize_and_write_ta'):
            ta_summaries_by_account, ta_all_summary = summarize_ta_by_account(ta_by_account)
            write_ta_to_s3(ta_summaries_by_account, ta_all_summary)
        logger.info('Trusted Advisor: wrote data for %d accounts (%d skipped)',
                    len(ta_summaries_by_account), ta_errors)
    else:
        logger.warning('Trusted Advisor: no data — check support plan / IAM role %s',
                       TA_READER_ROLE_NAME)

    # ── AWS Inspector — fetch, summarise, write to S3 ────────────────────
    inspector_accounts_processed = 0
    with _timed('fetch_inspector_findings'):
        inspector_findings = fetch_inspector_findings()
    if inspector_findings:
        with _timed('summarize_and_write_inspector'):
            inspector_summaries, all_inspector_summary = summarize_inspector_by_account(inspector_findings)
            write_inspector_to_s3(inspector_summaries, all_inspector_summary)
        inspector_accounts_processed = len(inspector_summaries)
        logger.info('Inspector: wrote data for %d accounts (%d findings)',
                    inspector_accounts_processed, len(inspector_findings))
    else:
        logger.info('Inspector: no active findings found (Inspector may not be enabled)')

    total_elapsed = time.perf_counter() - handler_start
    logger.info('TIMING lambda_handler_total duration_s=%.2f', total_elapsed)

    return {
        'statusCode': 200,
        'body': json.dumps({
            'version':                    AGGREGATOR_VERSION,
            'accountsProcessed':          len(summaries),
            'totalFindings':              len(findings),
            'newFindings':                len(new_findings),
            'resolvedFindings':           len(resolved_findings),
            'taAccountsProcessed':        len(ta_by_account),
            'taAccountsSkipped':          ta_errors,
            'inspectorAccountsProcessed': inspector_accounts_processed,
            'inspectorTotalFindings':     len(inspector_findings),
            'totalDurationSeconds':       round(total_elapsed, 1),
        }),
    }
