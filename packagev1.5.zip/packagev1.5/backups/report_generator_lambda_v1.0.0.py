"""
On-demand report generator Lambda.
Invoked asynchronously by the API Lambda (InvocationType='Event') when the
user clicks 'Generate report' in the dashboard.

Reads all required data from S3 — no Security Hub API calls are made here.
Builds PDF, CSV, and Excel reports then writes them to S3.
Writes a status file so the dashboard can poll for completion.

Deployment region: eu-west-1 (same as aggregator and API Lambda)

VERSION: 1.0.0

CHANGELOG
  1.0.0 - Initial: on-demand report generation from S3 data.
          Reads summaries/{account}/latest.json, findings.json,
          summaries/accounts.json, snapshots/ for resolved findings.
          Writes reports/{account}/latest.{pdf,csv,xlsx} and
          reports/{account}/status.json (polled by the dashboard).

Environment variables required:
  BUCKET            — S3 data bucket name (same as aggregator + api_lambda)

Invocation event shape (set by api_lambda POST /generate-report):
  {
    "account":   "123456789012" | "all",
    "format":    "pdf" | "csv" | "xlsx" | "all",
    "requestId": "<api-gateway-request-id>"
  }

S3 paths read:
  summaries/{account}/latest.json       — summary dict (score, severities, etc.)
  summaries/{account}/findings.json     — condensed findings (open/failed)
  summaries/accounts.json               — account list [{id, name, accountId}]
  summaries/version.json                — aggregator version + last run timestamp
  snapshots/{yesterday}/findings.json   — yesterday's snapshot for resolved delta

S3 paths written:
  reports/{account}/latest.pdf
  reports/{account}/latest.csv
  reports/{account}/latest.xlsx
  reports/{account}/status.json         — { status, requestId, generatedAt, formats, error }
"""

import boto3
import botocore.exceptions
import csv
import io
import json
import logging
import os
import time
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from fpdf import FPDF, XPos, YPos

try:
    import openpyxl
    from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

REPORT_GENERATOR_VERSION = '1.0.0'

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
def _require_env(name):
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(f"Required environment variable '{name}' is not set.")
    return val

BUCKET = _require_env('BUCKET')

s3 = boto3.client('s3')

SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
SEVERITY_RANK  = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}

# How many hours back a finding is considered "new" — must match aggregator
NEW_FINDING_WINDOW_HOURS = 26

# ---------------------------------------------------------------------------
# Status helpers — written to S3 so the dashboard can poll for completion
# ---------------------------------------------------------------------------

def _write_status(account: str, request_id: str, status: str,
                  formats: list = None, error: str = None):
    """Write reports/{account}/status.json. Called at start (pending),
    on completion (done), and on failure (failed)."""
    payload = {
        'status':       status,            # 'pending' | 'done' | 'failed'
        'requestId':    request_id,
        'generatedAt':  datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'formats':      formats or [],
        'error':        error,
    }
    s3.put_object(
        Bucket=BUCKET,
        Key=f'reports/{account}/status.json',
        Body=json.dumps(payload),
        ContentType='application/json',
    )

# ---------------------------------------------------------------------------
# S3 data loaders
# ---------------------------------------------------------------------------

def _load_json(key: str, default=None):
    """Load and parse a JSON object from S3. Returns `default` on NoSuchKey."""
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        return json.loads(obj['Body'].read().decode())
    except (s3.exceptions.NoSuchKey, botocore.exceptions.ClientError) as e:
        code = getattr(e, 'response', {}).get('Error', {}).get('Code', '')
        if code in ('NoSuchKey', '404'):
            return default
        raise


def load_account_data(account_id: str):
    """Load summary + condensed findings for one account from S3.
    Returns (summary_dict, condensed_findings_list) or raises if missing."""
    summary  = _load_json(f'summaries/{account_id}/latest.json')
    findings = _load_json(f'summaries/{account_id}/findings.json', default=[])

    if summary is None:
        raise FileNotFoundError(
            f'No summary found for account {account_id}. '
            'Run the aggregator first.'
        )
    return summary, findings


def load_account_names() -> dict:
    """Return {account_id: friendly_name} from summaries/accounts.json."""
    accounts = _load_json('summaries/accounts.json', default=[])
    return {a['id']: a.get('name', a['id']) for a in accounts}


def load_resolved_findings() -> list:
    """Load yesterday's snapshot to produce the resolved-findings list.
    Returns [] if no snapshot is available (first run / gap in schedule)."""
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d')
    today     = datetime.now(timezone.utc).strftime('%Y-%m-%d')

    yesterday_data = _load_json(f'snapshots/{yesterday}/findings.json', default=[])
    today_data     = _load_json(f'snapshots/{today}/findings.json',     default=[])

    if not yesterday_data or not today_data:
        return []

    today_fps = {f.get('_fp') for f in today_data if f.get('_fp')}
    return [f for f in yesterday_data if f.get('_fp') and f['_fp'] not in today_fps]


# ---------------------------------------------------------------------------
# Utility helpers shared by all three builders
# ---------------------------------------------------------------------------

def _is_new(finding: dict, now: datetime) -> bool:
    """True if this condensed finding's firstObservedAt is within the new
    finding window. Works on both condensed and raw finding shapes."""
    observed = finding.get('firstObservedAt') or finding.get('FirstObservedAt', '')
    if not observed:
        return False
    for fmt in ('%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ'):
        try:
            dt = datetime.strptime(observed, fmt).replace(tzinfo=timezone.utc)
            return (now - dt) <= timedelta(hours=NEW_FINDING_WINDOW_HOURS)
        except ValueError:
            continue
    return False


def _pdf_safe(text: str) -> str:
    """Replace non-latin-1 characters so fpdf2 Helvetica font never raises."""
    replacements = {
        '\u2014': '--', '\u2013': '-', '\u2018': "'", '\u2019': "'",
        '\u201c': '"',  '\u201d': '"', '\u2026': '...', '\u00a0': ' ',
    }
    for ch, rep in replacements.items():
        text = text.replace(ch, rep)
    return text.encode('latin-1', errors='replace').decode('latin-1')


def _get_resource_type(f: dict) -> str:
    resources = f.get('Resources', [{}]) or f.get('resources', [{}])
    return (resources[0].get('Type') if resources else None) or 'Unknown'


# ---------------------------------------------------------------------------
# PDF builder
# ---------------------------------------------------------------------------

def build_pdf_report(account_id: str, account_name: str,
                     summary: dict, findings: list) -> bytes:
    """Build a 3-page PDF from condensed finding data.

    `findings` is the condensed list from summaries/{account}/findings.json —
    keys: severity, title, resourceId, controlId, workflowStatus, region,
          firstObservedAt.
    `summary` is from summaries/{account}/latest.json.
    """
    now = datetime.now(timezone.utc)

    pdf = FPDF(orientation='P', unit='mm', format='A4')
    pdf.set_margins(10, 10, 10)
    pdf.set_auto_page_break(auto=True, margin=12)

    def row(*cells_and_widths, h=6, fill=False):
        pairs = list(zip(cells_and_widths[::2], cells_and_widths[1::2]))
        for i, (text, w) in enumerate(pairs):
            is_last = i == len(pairs) - 1
            pdf.cell(w, h, str(text), border=1, fill=fill,
                     new_x=XPos.RIGHT if not is_last else XPos.LMARGIN,
                     new_y=YPos.TOP  if not is_last else YPos.NEXT)

    SEV_STYLES = {
        'CRITICAL': {'fill': (245, 220, 220), 'bar': (229, 72, 77)},
        'HIGH':     {'fill': (250, 235, 215), 'bar': (245, 166, 35)},
        'MEDIUM':   {'fill': (255, 250, 210), 'bar': (91, 155, 213)},
        'LOW':      {'fill': (235, 235, 235), 'bar': (138, 150, 163)},
    }

    new_findings      = [f for f in findings if _is_new(f, now)]
    existing_findings = [f for f in findings if not _is_new(f, now)]

    by_severity = defaultdict(list)
    for f in findings:
        by_severity[f.get('severity', 'LOW')].append(f)

    by_resource = defaultdict(list)
    for f in findings:
        rt = f.get('resourceType') or _get_resource_type(f)
        by_resource[rt].append(f)

    # ── Page 1: Executive Summary ────────────────────────────────────────
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 16)
    pdf.cell(0, 9, 'AWS Security Hub Compliance Report', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 10)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(0, 6, _pdf_safe(f'Account: {account_name}  ({account_id})'),
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.cell(0, 6, f'Generated: {summary.get("lastScan", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))}',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(4)

    # Compliance score
    pdf.set_font('Helvetica', 'B', 14)
    pdf.cell(0, 8, f'Compliance Score: {summary.get("score", 0)} / 100',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 9)
    pdf.set_text_color(90, 90, 90)
    pdf.cell(0, 5,
             f'{summary.get("passedControls", 0)} passed / {summary.get("totalEnabledControls", 0)} enabled controls',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(5)

    # Severity bar chart
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Severity Distribution', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(1)
    sev_counts = {s: summary.get(s.lower(), 0) for s in SEVERITY_ORDER}
    max_count  = max(sev_counts.values()) or 1
    max_bar_w  = 140
    label_w    = 22
    for sev in SEVERITY_ORDER:
        count = sev_counts[sev]
        bar_w = (count / max_count) * max_bar_w
        y_start = pdf.get_y()
        pdf.set_font('Helvetica', 'B', 8)
        pdf.cell(label_w, 6, sev, new_x=XPos.RIGHT, new_y=YPos.TOP)
        if bar_w > 0:
            pdf.set_fill_color(*SEV_STYLES[sev]['bar'])
            pdf.cell(bar_w, 6, '', fill=True, new_x=XPos.RIGHT, new_y=YPos.TOP)
        pdf.set_font('Helvetica', '', 8)
        pdf.set_xy(10 + label_w + bar_w + 2, y_start)
        pdf.cell(15, 6, str(count), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(4)

    # Since last scan
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Since Last Scan', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 9)
    new_crit_high = sum(1 for f in new_findings if f.get('severity') in ('CRITICAL', 'HIGH'))
    pdf.set_text_color(190, 40, 40) if new_findings else pdf.set_text_color(60, 140, 80)
    line = (f'{len(new_findings)} new finding{"s" if len(new_findings) != 1 else ""} '
            f'(first observed in the last ~{NEW_FINDING_WINDOW_HOURS}h)')
    if new_crit_high:
        line += f'  --  {new_crit_high} of them Critical/High'
    pdf.cell(0, 6, _pdf_safe(line), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_text_color(110, 110, 110)
    pdf.cell(0, 5,
             f'{len(existing_findings)} ongoing finding{"s" if len(existing_findings) != 1 else ""} (open before this window)',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(4)

    # Top failing controls
    pdf.set_font('Helvetica', 'B', 11)
    pdf.cell(0, 7, 'Top Failing Controls', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', 'B', 8)
    pdf.set_fill_color(210, 210, 210)
    row('Control ID', 30, 'Title', 100, 'Severity', 30, 'Count', 30, h=7, fill=True)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_fill_color(255, 255, 255)
    for c in summary.get('topControls', [])[:3]:
        row(_pdf_safe(str(c.get('id', ''))[:18]), 30,
            _pdf_safe(str(c.get('title', ''))[:60]), 100,
            str(c.get('severity', '')), 30,
            str(c.get('count', '')), 30, h=6)

    # ── Page 2+: Full findings by severity ──────────────────────────────
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 13)
    pdf.cell(0, 8, f'All Findings ({len(findings)} total)',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.ln(1)

    ordered_severities = SEVERITY_ORDER + [s for s in by_severity if s not in SEVERITY_ORDER]
    for sev in ordered_severities:
        sev_findings = by_severity.get(sev, [])
        if not sev_findings:
            continue
        fill_rgb = SEV_STYLES.get(sev, {'fill': (255, 255, 255)})['fill']

        pdf.set_font('Helvetica', 'B', 11)
        pdf.cell(0, 8, f'{sev} ({len(sev_findings)})', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_font('Helvetica', 'B', 8)
        pdf.set_fill_color(210, 210, 210)
        row('New?', 12, 'Control ID', 28, 'Finding Title', 82, 'Resource', 48, 'Region', 20,
            h=7, fill=True)
        pdf.set_font('Helvetica', '', 7)
        pdf.set_fill_color(*fill_rgb)

        sorted_f = sorted(sev_findings,
                          key=lambda f: (not _is_new(f, now), f.get('controlId', '')))
        for f in sorted_f:
            badge        = 'NEW' if _is_new(f, now) else ''
            control_id   = _pdf_safe(str(f.get('controlId', ''))[:15])
            title        = _pdf_safe(str(f.get('title', ''))[:50])
            resource_id  = str(f.get('resourceId', ''))
            resource_short = _pdf_safe(resource_id[-30:] if len(resource_id) > 30 else resource_id)
            region       = str(f.get('region', ''))[:10]
            row(badge, 12, control_id, 28, title, 82, resource_short, 48, region, 20,
                h=6, fill=True)
        pdf.ln(4)

    # ── Page N: Findings by resource type ───────────────────────────────
    pdf.add_page()
    pdf.set_font('Helvetica', 'B', 13)
    pdf.cell(0, 8, 'Findings by Resource Type', new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_text_color(110, 110, 110)
    pdf.cell(0, 5, 'AWS services contributing the most findings.',
             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(2)

    pdf.set_font('Helvetica', 'B', 8)
    pdf.set_fill_color(210, 210, 210)
    row('Resource Type', 66, 'Critical', 26, 'High', 26, 'Medium', 26, 'Low', 26, 'Total', 20,
        h=7, fill=True)
    pdf.set_font('Helvetica', '', 8)
    pdf.set_fill_color(255, 255, 255)

    type_rows = []
    for rtype, flist in by_resource.items():
        counts = defaultdict(int)
        for f in flist:
            counts[f.get('severity', 'LOW')] += 1
        type_rows.append((rtype, dict(counts), len(flist)))
    type_rows.sort(key=lambda t: -t[2])

    for rtype, counts, total in type_rows:
        row(_pdf_safe(rtype[:38]), 66,
            str(counts.get('CRITICAL', 0)), 26,
            str(counts.get('HIGH', 0)),     26,
            str(counts.get('MEDIUM', 0)),   26,
            str(counts.get('LOW', 0)),      26,
            str(total),                     20, h=6)

    return bytes(pdf.output())


# ---------------------------------------------------------------------------
# CSV builder
# ---------------------------------------------------------------------------

def build_csv_report(account_id: str, account_name: str,
                     findings: list) -> bytes:
    """Build CSV from condensed findings list."""
    now    = datetime.now(timezone.utc)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Severity', 'IsNew', 'ControlId', 'Title', 'ResourceId', 'Region',
        'WorkflowStatus', 'FirstObservedAt', 'AccountId', 'AccountName',
    ])

    sorted_findings = sorted(
        findings,
        key=lambda f: (
            SEVERITY_RANK.get(f.get('severity', 'LOW'), 99),
            not _is_new(f, now),
            f.get('controlId', ''),
        )
    )
    for f in sorted_findings:
        writer.writerow([
            f.get('severity', ''),
            'YES' if _is_new(f, now) else '',
            f.get('controlId', ''),
            f.get('title', ''),
            f.get('resourceId', ''),
            f.get('region', ''),
            f.get('workflowStatus', ''),
            f.get('firstObservedAt', ''),
            account_id,
            account_name,
        ])
    return output.getvalue().encode('utf-8')


# ---------------------------------------------------------------------------
# Excel builder
# ---------------------------------------------------------------------------

def build_excel_report(account_id: str, account_name: str,
                       failed_findings: list,
                       resolved_findings: list,
                       account_names: dict) -> bytes | None:
    """Build 3-tab Excel workbook.
    Tab 1 — Failed Checks (from condensed findings.json)
    Tab 2 — Previously Failed, Now Passed (resolved_findings from snapshot delta)
    Returns None if openpyxl not installed.
    """
    if not EXCEL_AVAILABLE:
        return None

    SEV_FILL = {
        'CRITICAL': 'F8D7DA', 'HIGH': 'FFF3CD',
        'MEDIUM':   'D1ECF1', 'LOW':  'F8F9FA',
    }

    def _hdr(ws, headers, bg='1E2761', fg='FFFFFF'):
        fill   = PatternFill('solid', fgColor=bg)
        font   = Font(bold=True, color=fg, name='Calibri', size=10)
        align  = Alignment(horizontal='center', vertical='center', wrap_text=True)
        thin   = Side(style='thin', color='C0C0C0')
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        ws.append(headers)
        for cell in ws[ws.max_row]:
            cell.fill = fill; cell.font = font
            cell.alignment = align; cell.border = border
        ws.row_dimensions[ws.max_row].height = 22

    def _row(ws, values, bg=None):
        thin   = Side(style='thin', color='E0E0E0')
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        fill   = PatternFill('solid', fgColor=bg) if bg else None
        ws.append(values)
        for cell in ws[ws.max_row]:
            cell.font      = Font(name='Calibri', size=9)
            cell.alignment = Alignment(vertical='center', wrap_text=True)
            cell.border    = border
            if fill:
                cell.fill = fill
        ws.row_dimensions[ws.max_row].height = 16

    def _widths(ws, widths):
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

    wb = openpyxl.Workbook()

    # Tab 1: Failed Checks
    ws1 = wb.active
    ws1.title = 'Failed Checks'
    _hdr(ws1, ['Severity', 'ControlId', 'Title', 'ResourceId', 'Region',
               'WorkflowStatus', 'FirstObservedAt', 'AccountId', 'AccountName'])
    for f in sorted(failed_findings,
                    key=lambda x: (SEVERITY_RANK.get(x.get('severity', 'LOW'), 99),
                                   x.get('controlId', ''))):
        sev  = f.get('severity', 'LOW')
        acct = f.get('accountId', account_id)
        _row(ws1, [
            sev,
            f.get('controlId', ''),
            f.get('title', ''),
            f.get('resourceId', ''),
            f.get('region', ''),
            f.get('workflowStatus', ''),
            f.get('firstObservedAt', ''),
            acct,
            account_names.get(acct, account_name),
        ], SEV_FILL.get(sev))
    _widths(ws1, [12, 20, 55, 55, 14, 16, 22, 16, 22])
    ws1.freeze_panes = 'A2'

    # Tab 2: Previously Failed, Now Passed (resolved since yesterday)
    ws2 = wb.create_sheet('Previously Failed - Now Passed')
    _hdr(ws2, ['Severity', 'ControlId', 'Title', 'ResourceId', 'Region',
               'FirstObservedAt', 'AccountId', 'AccountName'], '155724')
    for r in resolved_findings:
        acct = r.get('accountId', account_id)
        if account_id not in ('all', 'ALL', acct):
            continue
        _row(ws2, [
            r.get('severity', ''),
            r.get('controlId', ''),
            r.get('title', ''),
            r.get('resourceId', ''),
            r.get('region', ''),
            r.get('firstObservedAt', ''),
            acct,
            account_names.get(acct, account_name),
        ], 'E3F2FD')
    _widths(ws2, [12, 20, 55, 55, 14, 22, 16, 22])
    ws2.freeze_panes = 'A2'

    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    """Invoked async by the API Lambda.

    Event shape:
      { "account": "123456789012"|"all", "format": "pdf"|"csv"|"xlsx"|"all",
        "requestId": "<string>" }
    """
    t_start    = time.perf_counter()
    account_id = (event.get('account') or 'all').strip()
    fmt        = (event.get('format')  or 'all').lower()
    request_id = event.get('requestId', 'unknown')

    logger.info('report_generator: account=%s format=%s requestId=%s version=%s',
                account_id, fmt, request_id, REPORT_GENERATOR_VERSION)

    # Write pending status immediately so the dashboard stops polling "not started"
    _write_status(account_id, request_id, 'pending')

    formats_to_build = ['pdf', 'csv', 'xlsx'] if fmt == 'all' else [fmt]
    built_formats    = []
    error_msg        = None

    try:
        # ── Load data from S3 ────────────────────────────────────────────
        account_names = load_account_names()
        account_name  = account_names.get(account_id, account_id)
        resolved      = load_resolved_findings()

        summary, findings = load_account_data(account_id)

        logger.info('report_generator: loaded %d findings for account %s',
                    len(findings), account_id)

        # ── Build and upload each requested format ───────────────────────
        if 'pdf' in formats_to_build:
            t0        = time.perf_counter()
            pdf_bytes = build_pdf_report(account_id, account_name, summary, findings)
            logger.info('report_generator: pdf build=%.2fs', time.perf_counter() - t0)
            t0 = time.perf_counter()
            s3.put_object(Bucket=BUCKET, Key=f'reports/{account_id}/latest.pdf',
                          Body=pdf_bytes, ContentType='application/pdf')
            logger.info('report_generator: pdf upload=%.2fs', time.perf_counter() - t0)
            built_formats.append('pdf')

        if 'csv' in formats_to_build:
            t0        = time.perf_counter()
            csv_bytes = build_csv_report(account_id, account_name, findings)
            logger.info('report_generator: csv build=%.2fs', time.perf_counter() - t0)
            t0 = time.perf_counter()
            s3.put_object(Bucket=BUCKET, Key=f'reports/{account_id}/latest.csv',
                          Body=csv_bytes, ContentType='text/csv')
            logger.info('report_generator: csv upload=%.2fs', time.perf_counter() - t0)
            built_formats.append('csv')

        if 'xlsx' in formats_to_build:
            if not EXCEL_AVAILABLE:
                logger.warning('report_generator: openpyxl not installed — skipping xlsx')
            else:
                t0 = time.perf_counter()
                xl = build_excel_report(account_id, account_name,
                                        findings, resolved, account_names)
                logger.info('report_generator: xlsx build=%.2fs', time.perf_counter() - t0)
                if xl:
                    t0 = time.perf_counter()
                    s3.put_object(
                        Bucket=BUCKET, Key=f'reports/{account_id}/latest.xlsx',
                        Body=xl,
                        ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                    logger.info('report_generator: xlsx upload=%.2fs', time.perf_counter() - t0)
                    built_formats.append('xlsx')

        _write_status(account_id, request_id, 'done', formats=built_formats)
        logger.info('report_generator: done account=%s formats=%s total=%.2fs',
                    account_id, built_formats, time.perf_counter() - t_start)

    except Exception as exc:
        error_msg = str(exc)
        logger.exception('report_generator: FAILED account=%s: %s', account_id, exc)
        _write_status(account_id, request_id, 'failed',
                      formats=built_formats, error=error_msg)

    return {
        'statusCode': 200 if not error_msg else 500,
        'account':    account_id,
        'formats':    built_formats,
        'error':      error_msg,
        'durationSeconds': round(time.perf_counter() - t_start, 1),
    }
