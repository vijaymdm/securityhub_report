"""
Deploy in the same account as your API Gateway (delegated admin account is fine).

VERSION: 1.5.2   (bump this + add a CHANGELOG line every time you redeploy)

CHANGELOG
  1.5.2 - Account Inventory routes. POST /generate-inventory invokes the
          inventory_lambda asynchronously (InvocationType=Event). GET
          /inventory-status polls inventory/{account}/status.json. GET
          /inventory reads inventory/{account}/latest.json. New env var:
          INVENTORY_FUNCTION_NAME.
  1.5.1 - /report-url presigned URL now includes ResponseContentDisposition=
          attachment so browsers download PDFs instead of navigating to them.
          Fixes PDF opening in the same CloudFront tab instead of downloading.
  1.5.0 - On-demand report generation. POST /generate-report invokes the
          report_generator_lambda asynchronously (InvocationType=Event) so
          the request returns immediately while the report is built in the
          background. GET /report-status polls reports/{account}/status.json
          written by the generator (pending | done | failed).
          /report-url error message updated to guide users to generate first.
          CORS_HEADERS updated to allow POST method.
          New env var: REPORT_GENERATOR_FUNCTION_NAME.
  1.4.2 - /report-url now verifies the S3 object exists (head_object) before
          generating a presigned URL. Missing key returns a clean JSON 404 with
          a diagnostic message instead of raw S3 XML in the browser.
          Added botocore.exceptions import.
  1.4.1 - Added /inspector route. Reads inspector/{account}/latest.json written
          by aggregator v1.5.4. Accepts optional severity filter (CRITICAL|HIGH|
          MEDIUM|LOW). Added VALID_INSPECTOR_SEVERITIES allowlist.
  1.4.0 - BUCKET, CORS_ALLOW_ORIGIN moved to environment variables.
          account param validated against strict regex allowlist before S3 key use.
          severity + status params validated against allowlists (400 on invalid).
          str(e) in 500 responses replaced with a safe generic message.
  1.3.1 - /report-url now accepts &format=xlsx.
  1.3.0 - /report-url now supports &format=pdf|csv|xlsx.
  1.2.0 - Added /trusted-advisor, /version routes.
  1.1.0 - Added /findings route with severity filter.
  1.0.0 - Initial: /accounts, /summary, /report-url (PDF only).

Routes (HTTP API, Lambda proxy integration):
  GET  /accounts
  GET  /summary?account={id}
  GET  /findings?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW   (severity optional)
  GET  /trusted-advisor?account={id}&status=error|warning|ok      (status optional)
  GET  /inspector?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW  (severity optional)
  POST /generate-report  body: {"account":"{id}","format":"pdf|csv|xlsx|all"}
  GET  /report-status?account={id}
  GET  /report-url?account={id}&format=pdf|csv|xlsx
  POST /generate-inventory  body: {"account":"{id}"}
  GET  /inventory-status?account={id}
  GET  /inventory?account={id}
  GET  /version

Environment variables required:
  BUCKET                        — S3 bucket name
  CORS_ALLOW_ORIGIN             — Allowed CORS origin (e.g. https://security.example.com)
  REPORT_GENERATOR_FUNCTION_NAME — Name or ARN of the report_generator_lambda
  INVENTORY_FUNCTION_NAME        — Name or ARN of the inventory_lambda
"""

import boto3
import botocore.exceptions
import json
import os
import re
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

API_VERSION = '1.5.2'

# ---------------------------------------------------------------------------
# Configuration — fail fast at cold-start if required variables are missing
# ---------------------------------------------------------------------------
def _require_env(name):
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(
            f"Required environment variable '{name}' is not set. "
            "Set it in the Lambda function configuration before deploying."
        )
    return val

BUCKET                         = _require_env('BUCKET')
CORS_ALLOW_ORIGIN              = _require_env('CORS_ALLOW_ORIGIN')
REPORT_GENERATOR_FUNCTION_NAME = _require_env('REPORT_GENERATOR_FUNCTION_NAME')
INVENTORY_FUNCTION_NAME        = _require_env('INVENTORY_FUNCTION_NAME')

s3     = boto3.client('s3')
lmbda  = boto3.client('lambda')   # used to invoke report_generator_lambda and inventory_lambda

# CORS headers — POST added so the browser preflight for /generate-report passes
CORS_HEADERS = {
    'Content-Type':                'application/json',
    'Access-Control-Allow-Origin': CORS_ALLOW_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
}

CORS_PREFLIGHT_HEADERS = {
    **CORS_HEADERS,
    'Access-Control-Max-Age': '600',
}

# 12-digit account ID or the sentinel 'all'
_ACCOUNT_RE = re.compile(r'^\d{12}$|^all$')

VALID_SEVERITIES           = {'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'}
VALID_TA_STATUSES          = {'error', 'warning', 'ok'}
VALID_INSPECTOR_SEVERITIES = {'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'}
VALID_FORMATS              = {'pdf', 'csv', 'xlsx'}
VALID_GENERATE_FORMATS     = {'pdf', 'csv', 'xlsx', 'all'}


def respond(status, body_dict, request_id=None):
    body = body_dict.copy()
    if request_id:
        body['requestId'] = request_id
    return {'statusCode': status, 'headers': CORS_HEADERS, 'body': json.dumps(body)}


def _validate_account(account, request_id):
    """Return (account, error_response | None)."""
    if not _ACCOUNT_RE.match(account):
        logger.warning('Invalid account param: %r requestId=%s', account, request_id)
        return None, respond(400, {
            'error': "Invalid 'account' parameter. Must be a 12-digit account ID or 'all'."
        }, request_id)
    return account, None


# ---------------------------------------------------------------------------
# Lambda handler
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    request_id = context.aws_request_id if context else 'local'
    path   = event.get('rawPath', '')
    params = event.get('queryStringParameters') or {}
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')

    if method == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS_PREFLIGHT_HEADERS, 'body': ''}

    try:

        # ── /version ──────────────────────────────────────────────────────
        if path.endswith('/version'):
            aggregator_version  = None
            aggregator_last_run = None
            try:
                obj          = s3.get_object(Bucket=BUCKET, Key='summaries/version.json')
                version_data = json.loads(obj['Body'].read().decode())
                aggregator_version  = version_data.get('aggregatorVersion')
                aggregator_last_run = version_data.get('lastRun')
            except s3.exceptions.NoSuchKey:
                pass
            return respond(200, {
                'apiVersion':        API_VERSION,
                'aggregatorVersion': aggregator_version,
                'aggregatorLastRun': aggregator_last_run,
            }, request_id)

        # ── /accounts ─────────────────────────────────────────────────────
        if path.endswith('/accounts'):
            obj = s3.get_object(Bucket=BUCKET, Key='summaries/accounts.json')
            return {'statusCode': 200, 'headers': CORS_HEADERS,
                    'body': obj['Body'].read().decode()}

        # ── /summary ──────────────────────────────────────────────────────
        if path.endswith('/summary'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            obj = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/latest.json')
            return {'statusCode': 200, 'headers': CORS_HEADERS,
                    'body': obj['Body'].read().decode()}

        # ── /findings ─────────────────────────────────────────────────────
        if path.endswith('/findings'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            severity = (params.get('severity') or '').upper()
            if severity and severity not in VALID_SEVERITIES:
                return respond(400, {
                    'error': f"Invalid severity '{severity}'. Must be one of: {', '.join(sorted(VALID_SEVERITIES))}."
                }, request_id)
            obj      = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/findings.json')
            findings = json.loads(obj['Body'].read().decode())
            if severity:
                findings = [f for f in findings if f.get('severity', '').upper() == severity]
            return respond(200, {
                'account':  account,
                'severity': severity or 'ALL',
                'count':    len(findings),
                'findings': findings,
            }, request_id)

        # ── /trusted-advisor ──────────────────────────────────────────────
        if path.endswith('/trusted-advisor'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            status = (params.get('status') or '').lower()
            if status and status not in VALID_TA_STATUSES:
                return respond(400, {
                    'error': f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_TA_STATUSES))}."
                }, request_id)
            obj        = s3.get_object(Bucket=BUCKET, Key=f'trusted-advisor/{account}/latest.json')
            ta_summary = json.loads(obj['Body'].read().decode())
            if status:
                checks     = [c for c in ta_summary.get('checks', []) if c.get('status', '').lower() == status]
                ta_summary = {**ta_summary, 'checks': checks}
            return respond(200, ta_summary, request_id)

        # ── /inspector ────────────────────────────────────────────────────
        if path.endswith('/inspector'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            severity = (params.get('severity') or '').upper()
            if severity and severity not in VALID_INSPECTOR_SEVERITIES:
                return respond(400, {
                    'error': f"Invalid severity '{severity}'. Must be one of: {', '.join(sorted(VALID_INSPECTOR_SEVERITIES))}."
                }, request_id)
            obj               = s3.get_object(Bucket=BUCKET, Key=f'inspector/{account}/latest.json')
            inspector_summary = json.loads(obj['Body'].read().decode())
            if severity:
                filtered          = [f for f in inspector_summary.get('findings', [])
                                     if f.get('severity', '').upper() == severity]
                inspector_summary = {**inspector_summary, 'findings': filtered}
            logger.info('Inspector: account=%s severity=%s findings=%d requestId=%s',
                        account, severity or 'ALL',
                        len(inspector_summary.get('findings', [])), request_id)
            return respond(200, inspector_summary, request_id)

        # ── POST /generate-report ─────────────────────────────────────────
        # Invokes the report_generator_lambda asynchronously (Event invocation)
        # so this request returns in < 1 second regardless of report size.
        # The generator writes reports/{account}/status.json when complete.
        # The dashboard polls GET /report-status until status == 'done',
        # then calls GET /report-url to get the presigned download URL.
        if path.endswith('/generate-report') and method == 'POST':
            # Parse body — API Gateway HTTP API sends a JSON-encoded string body
            try:
                body    = json.loads(event.get('body') or '{}')
            except (json.JSONDecodeError, TypeError):
                body    = {}

            account = (body.get('account') or 'all').strip()
            account, err = _validate_account(account, request_id)
            if err:
                return err

            fmt = (body.get('format') or 'all').lower()
            if fmt not in VALID_GENERATE_FORMATS:
                return respond(400, {
                    'error': f"Invalid format '{fmt}'. Must be one of: {', '.join(sorted(VALID_GENERATE_FORMATS))}."
                }, request_id)

            # Build the payload for the report generator
            generator_payload = {
                'account':   account,
                'format':    fmt,
                'requestId': request_id,
            }

            # Invoke asynchronously — returns HTTP 202 immediately; the generator
            # runs independently and writes status + report files to S3.
            lmbda.invoke(
                FunctionName   = REPORT_GENERATOR_FUNCTION_NAME,
                InvocationType = 'Event',          # async — no waiting for result
                Payload        = json.dumps(generator_payload).encode(),
            )

            logger.info('generate-report: invoked generator account=%s format=%s requestId=%s',
                        account, fmt, request_id)

            return respond(202, {
                'message':   'Report generation started. Poll /report-status for completion.',
                'account':   account,
                'format':    fmt,
                'requestId': request_id,
            }, request_id)

        # ── GET /report-status ────────────────────────────────────────────
        # Reads reports/{account}/status.json written by report_generator_lambda.
        # Returns { status: 'pending'|'done'|'failed', formats: [...], error: ... }
        # Dashboard polls this every 3 seconds until status == 'done', then
        # calls /report-url to get the presigned download URL.
        if path.endswith('/report-status'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err

            try:
                obj    = s3.get_object(Bucket=BUCKET, Key=f'reports/{account}/status.json')
                status = json.loads(obj['Body'].read().decode())
            except botocore.exceptions.ClientError as e:
                err_code = e.response.get('Error', {}).get('Code', '')
                if err_code in ('NoSuchKey', '404'):
                    # No generation has been triggered yet for this account
                    return respond(200, {
                        'status':      'not_started',
                        'account':     account,
                        'requestId':   None,
                        'generatedAt': None,
                        'formats':     [],
                        'error':       None,
                    }, request_id)
                raise

            return respond(200, status, request_id)

        # ── GET /report-url ───────────────────────────────────────────────
        # Generates a 15-minute presigned S3 GET URL for the requested report.
        # Verifies the object exists first — returns a clean 404 with guidance
        # to use /generate-report if the file is not yet present.
        if path.endswith('/report-url'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            fmt = (params.get('format') or 'pdf').lower()
            if fmt not in VALID_FORMATS:
                return respond(400, {
                    'error': f"Invalid format '{fmt}'. Must be one of: {', '.join(sorted(VALID_FORMATS))}."
                }, request_id)

            report_key = f'reports/{account}/latest.{fmt}'

            try:
                s3.head_object(Bucket=BUCKET, Key=report_key)
            except botocore.exceptions.ClientError as head_err:
                err_code = head_err.response.get('Error', {}).get('Code', '')
                if err_code in ('404', 'NoSuchKey'):
                    fmt_label = {'pdf': 'PDF', 'csv': 'CSV', 'xlsx': 'Excel'}.get(fmt, fmt.upper())
                    logger.info('report-url: not found account=%s format=%s requestId=%s',
                                account, fmt, request_id)
                    return respond(404, {
                        'error': (
                            f'{fmt_label} report not yet generated for this account. '
                            'Use POST /generate-report to build it on demand — '
                            'the dashboard will poll /report-status and download automatically when ready.'
                        )
                    }, request_id)
                raise

            # Build a filename for the download — used in Content-Disposition
            # so the browser saves with a meaningful name regardless of the S3 key.
            fmt_extensions = {'pdf': 'pdf', 'csv': 'csv', 'xlsx': 'xlsx'}
            filename = f'securityhub-report-{account}.{fmt_extensions.get(fmt, fmt)}'

            url = s3.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': BUCKET,
                    'Key':    report_key,
                    # ResponseContentDisposition forces download in all browsers,
                    # including Chrome/Safari which otherwise preview PDFs inline
                    # and navigate away from the CloudFront page.
                    'ResponseContentDisposition': f'attachment; filename="{filename}"',
                },
                ExpiresIn=900,
            )
            logger.info('Presigned URL: account=%s format=%s requestId=%s',
                        account, fmt, request_id)
            return respond(200, {'url': url, 'format': fmt}, request_id)

        # ── POST /generate-inventory ──────────────────────────────────────
        # Invokes inventory_lambda asynchronously (InvocationType=Event).
        # Returns 202 immediately; inventory_lambda writes the result to S3
        # and updates inventory/{account}/status.json when done.
        # Dashboard polls GET /inventory-status until status == 'done',
        # then calls GET /inventory to read the data.
        if path.endswith('/generate-inventory') and method == 'POST':
            try:
                body = json.loads(event.get('body') or '{}')
            except (json.JSONDecodeError, TypeError):
                body = {}

            account = (body.get('account') or 'all').strip()
            account, err = _validate_account(account, request_id)
            if err:
                return err

            lmbda.invoke(
                FunctionName   = INVENTORY_FUNCTION_NAME,
                InvocationType = 'Event',
                Payload        = json.dumps({
                    'account':   account,
                    'requestId': request_id,
                }).encode(),
            )

            logger.info('generate-inventory: invoked account=%s requestId=%s',
                        account, request_id)

            return respond(202, {
                'message':   'Inventory generation started. Poll /inventory-status for completion.',
                'account':   account,
                'requestId': request_id,
            }, request_id)

        # ── GET /inventory-status ─────────────────────────────────────────
        # Reads inventory/{account}/status.json written by inventory_lambda.
        # Returns { status: 'pending'|'done'|'failed', requestId, generatedAt, error }
        if path.endswith('/inventory-status'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err

            try:
                obj    = s3.get_object(Bucket=BUCKET, Key=f'inventory/{account}/status.json')
                status = json.loads(obj['Body'].read().decode())
            except botocore.exceptions.ClientError as e:
                err_code = e.response.get('Error', {}).get('Code', '')
                if err_code in ('NoSuchKey', '404'):
                    return respond(200, {
                        'status':      'not_started',
                        'account':     account,
                        'requestId':   None,
                        'generatedAt': None,
                        'error':       None,
                    }, request_id)
                raise

            return respond(200, status, request_id)

        # ── GET /inventory ────────────────────────────────────────────────
        # Reads inventory/{account}/latest.json written by inventory_lambda.
        # Returns the full inventory object (services[], resources[]).
        # Optional ?service= query param filters to a single service type.
        if path.endswith('/inventory'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err

            service_filter = (params.get('service') or '').strip()

            obj       = s3.get_object(Bucket=BUCKET, Key=f'inventory/{account}/latest.json')
            inventory = json.loads(obj['Body'].read().decode())

            if service_filter:
                inventory = {
                    **inventory,
                    'services':  [s for s in inventory.get('services', [])
                                  if s.get('resourceType') == service_filter],
                    'resources': [r for r in inventory.get('resources', [])
                                  if r.get('resourceType') == service_filter],
                }

            logger.info('inventory: account=%s service=%s services=%d resources=%d requestId=%s',
                        account, service_filter or 'ALL',
                        len(inventory.get('services', [])),
                        len(inventory.get('resources', [])),
                        request_id)
            return respond(200, inventory, request_id)

        return respond(404, {'error': 'Unknown route.'}, request_id)

    except s3.exceptions.NoSuchKey:
        return respond(404, {
            'error': 'No data found for this account yet. Wait for the next aggregator run.'
        }, request_id)
    except Exception as e:
        logger.exception('Unhandled error requestId=%s: %s', request_id, e)
        return respond(500, {
            'error': 'An internal error occurred. Check CloudWatch logs for details.',
            'requestId': request_id,
        })
