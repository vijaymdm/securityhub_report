"""
Deploy in the same account as your API Gateway (delegated admin account is fine).

VERSION: 1.4.2   (bump this + add a CHANGELOG line every time you redeploy)

CHANGELOG
  1.4.2 - /report-url now verifies the S3 object exists (head_object) before
          generating a presigned URL. Missing key returns a clean JSON 404 with
          a diagnostic message instead of raw S3 XML in the browser.
          Added botocore.exceptions import.
  1.4.1 - Added /inspector route. Reads inspector/{account}/latest.json written
          by aggregator v1.5.4. Accepts optional severity filter (CRITICAL|HIGH|
          MEDIUM|LOW). Added VALID_INSPECTOR_SEVERITIES allowlist.
  1.4.0 - BUCKET, CORS_ALLOW_ORIGIN moved to environment variables.
          account param validated against strict regex allowlist before S3 key use.
          severity + status params validated against allowlists (400 on invalid).
          str(e) in 500 responses replaced with a safe generic message.
  1.3.1 - /report-url now accepts &format=xlsx (was silently rejecting it with 400).
  1.3.0 - /report-url now supports &format=pdf|csv|xlsx (3-tab Excel) — NOTE: xlsx
          was documented in 1.3.0 but the validation guard was not updated until 1.3.1.
  1.2.0 - Added /trusted-advisor route with optional status filter.
          Added /version route for quick deployment-sync checks.
  1.1.0 - Added /findings route with optional severity filter, and
          /report-url now takes &format=pdf|csv instead of PDF-only.
  1.0.0 - Initial: /accounts, /summary, /report-url (PDF only).

Routes (HTTP API, Lambda proxy integration):
  GET /accounts
  GET /summary?account={id}
  GET /findings?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW   (severity optional)
  GET /trusted-advisor?account={id}&status=error|warning|ok      (status optional)
  GET /inspector?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW  (severity optional)
  GET /report-url?account={id}&format=pdf|csv|xlsx
  GET /version

Environment variables required:
  BUCKET            — S3 bucket name (e.g. securityhub-dashboard-data)
  CORS_ALLOW_ORIGIN — Allowed CORS origin (e.g. https://security.example.com)
"""

import boto3
import botocore.exceptions
import json
import os
import re
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

API_VERSION = '1.4.2'

# ---------------------------------------------------------------------------
# Configuration from environment variables — fail fast at init if missing
# ---------------------------------------------------------------------------
def _require_env(name):
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(
            f"Required environment variable '{name}' is not set. "
            "Set it in the Lambda function configuration before deploying."
        )
    return val

BUCKET           = _require_env('BUCKET')
CORS_ALLOW_ORIGIN = _require_env('CORS_ALLOW_ORIGIN')

s3 = boto3.client('s3')

CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': CORS_ALLOW_ORIGIN,
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
}

# Preflight cache — browsers re-use this for 10 minutes, halving API call volume
CORS_PREFLIGHT_HEADERS = {
    **CORS_HEADERS,
    'Access-Control-Max-Age': '600',
}

# Strict allowlist for account parameter — 12-digit AWS account ID or the
# sentinel value 'all' used for org-wide aggregates.
_ACCOUNT_RE = re.compile(r'^\d{12}$|^all$')

VALID_SEVERITIES          = {'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'}
VALID_TA_STATUSES         = {'error', 'warning', 'ok'}
VALID_INSPECTOR_SEVERITIES = {'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'}
VALID_FORMATS             = {'pdf', 'csv', 'xlsx'}


def respond(status, body_dict, request_id=None):
    body = body_dict.copy()
    if request_id:
        body['requestId'] = request_id
    return {'statusCode': status, 'headers': CORS_HEADERS, 'body': json.dumps(body)}


def _validate_account(account, request_id):
    """Return (account, error_response | None)."""
    if not _ACCOUNT_RE.match(account):
        logger.warning('Invalid account param received: %r (requestId=%s)', account, request_id)
        return None, respond(400, {'error': "Invalid 'account' parameter. Must be a 12-digit account ID or 'all'."}, request_id)
    return account, None


def lambda_handler(event, context):
    request_id = context.aws_request_id if context else 'local'
    path   = event.get('rawPath', '')
    params = event.get('queryStringParameters') or {}
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')

    if method == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS_PREFLIGHT_HEADERS, 'body': ''}

    try:
        # ── /version ──────────────────────────────────────────────────────
        if path.endswith('/version'):
            aggregator_version = None
            aggregator_last_run = None
            try:
                obj = s3.get_object(Bucket=BUCKET, Key='summaries/version.json')
                version_data = json.loads(obj['Body'].read().decode())
                aggregator_version = version_data.get('aggregatorVersion')
                aggregator_last_run = version_data.get('lastRun')
            except s3.exceptions.NoSuchKey:
                pass
            return respond(200, {
                'apiVersion': API_VERSION,
                'aggregatorVersion': aggregator_version,
                'aggregatorLastRun': aggregator_last_run,
            }, request_id)

        # ── /accounts ─────────────────────────────────────────────────────
        if path.endswith('/accounts'):
            obj = s3.get_object(Bucket=BUCKET, Key='summaries/accounts.json')
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': obj['Body'].read().decode(),
            }

        # ── /summary ──────────────────────────────────────────────────────
        if path.endswith('/summary'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            obj = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/latest.json')
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': obj['Body'].read().decode(),
            }

        # ── /findings ─────────────────────────────────────────────────────
        if path.endswith('/findings'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            severity = (params.get('severity') or '').upper()
            if severity and severity not in VALID_SEVERITIES:
                return respond(400, {
                    'error': f"Invalid severity '{severity}'. Must be one of: {', '.join(sorted(VALID_SEVERITIES))}."
                }, request_id)
            obj = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/findings.json')
            findings = json.loads(obj['Body'].read().decode())
            if severity:
                findings = [f for f in findings if f.get('severity', '').upper() == severity]
            return respond(200, {
                'account': account,
                'severity': severity or 'ALL',
                'count': len(findings),
                'findings': findings,
            }, request_id)

        # ── /trusted-advisor ──────────────────────────────────────────────
        if path.endswith('/trusted-advisor'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            status = (params.get('status') or '').lower()
            if status and status not in VALID_TA_STATUSES:
                return respond(400, {
                    'error': f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_TA_STATUSES))}."
                }, request_id)
            obj = s3.get_object(Bucket=BUCKET, Key=f'trusted-advisor/{account}/latest.json')
            ta_summary = json.loads(obj['Body'].read().decode())
            if status:
                checks = [c for c in ta_summary.get('checks', []) if c.get('status', '').lower() == status]
                ta_summary = {**ta_summary, 'checks': checks}
            return respond(200, ta_summary, request_id)

        # ── /inspector ────────────────────────────────────────────────────
        # Reads inspector/{account}/latest.json written by aggregator v1.5.4+.
        # Returns the full summary including per-account severity counts,
        # finding type breakdown, top resources, top CVE titles, and a
        # condensed findings list (capped at 500 per account by the aggregator).
        # Optional severity filter narrows the findings[] array in the response.
        if path.endswith('/inspector'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            severity = (params.get('severity') or '').upper()
            if severity and severity not in VALID_INSPECTOR_SEVERITIES:
                return respond(400, {
                    'error': f"Invalid severity '{severity}'. Must be one of: {', '.join(sorted(VALID_INSPECTOR_SEVERITIES))}."
                }, request_id)
            obj = s3.get_object(Bucket=BUCKET, Key=f'inspector/{account}/latest.json')
            inspector_summary = json.loads(obj['Body'].read().decode())
            if severity:
                filtered = [
                    f for f in inspector_summary.get('findings', [])
                    if f.get('severity', '').upper() == severity
                ]
                inspector_summary = {**inspector_summary, 'findings': filtered}
            logger.info('Inspector route: account=%s severity=%s findings=%d requestId=%s',
                        account, severity or 'ALL', len(inspector_summary.get('findings', [])), request_id)
            return respond(200, inspector_summary, request_id)

        # ── /report-url ───────────────────────────────────────────────────
        # Generates a 15-minute presigned S3 GET URL for the requested report.
        # Verifies the object exists first — if not, returns a clean 404 so
        # the dashboard shows a friendly message instead of raw S3 XML.
        if path.endswith('/report-url'):
            account = params.get('account', 'all')
            account, err = _validate_account(account, request_id)
            if err:
                return err
            fmt = (params.get('format') or 'pdf').lower()
            if fmt not in VALID_FORMATS:
                return respond(400, {
                    'error': f"Invalid format '{fmt}'. Must be one of: {', '.join(sorted(VALID_FORMATS))}."
                }, request_id)
            report_key = f'reports/{account}/latest.{fmt}'

            # Check the object exists before signing — presigned URLs are
            # generated successfully even for keys that don't exist, causing
            # the browser to receive raw S3 XML instead of a friendly error.
            try:
                s3.head_object(Bucket=BUCKET, Key=report_key)
            except botocore.exceptions.ClientError as head_err:
                err_code = head_err.response.get('Error', {}).get('Code', '')
                if err_code in ('404', 'NoSuchKey'):
                    fmt_label = {'pdf': 'PDF', 'csv': 'CSV', 'xlsx': 'Excel'}.get(fmt, fmt.upper())
                    logger.info('report-url: key not found account=%s format=%s key=%s requestId=%s',
                                account, fmt, report_key, request_id)
                    return respond(404, {
                        'error': (
                            f'{fmt_label} report not found for this account. '
                            'This usually means the aggregator has not run yet, '
                            'openpyxl is missing from the Lambda ZIP (Excel only), '
                            'or report generation was skipped due to a timeout. '
                            'Check CloudWatch Logs for TIMING entries and re-trigger the aggregator.'
                        )
                    }, request_id)
                raise  # unexpected S3 error — let the global handler catch it

            url = s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': BUCKET, 'Key': report_key},
                ExpiresIn=900,
            )
            logger.info('Presigned URL generated: account=%s format=%s requestId=%s',
                        account, fmt, request_id)
            return respond(200, {'url': url, 'format': fmt}, request_id)

        return respond(404, {'error': 'Unknown route.'}, request_id)

    except s3.exceptions.NoSuchKey:
        return respond(404, {'error': 'No data found for this account yet. Wait for the next aggregator run.'}, request_id)
    except Exception as e:
        # Log the real error internally; return a safe generic message to the caller
        logger.exception('Unhandled error (requestId=%s): %s', request_id, e)
        return respond(500, {'error': 'An internal error occurred. Check CloudWatch logs for details.', 'requestId': request_id})
