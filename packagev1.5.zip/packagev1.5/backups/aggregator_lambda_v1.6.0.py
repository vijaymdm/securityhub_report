"""
Runs on a schedule (EventBridge, e.g. daily 03:00 GMT) in the Security Hub
DELEGATED ADMINISTRATOR account.

Deployment region: eu-west-1
  The Lambda, EventBridge rule, S3 bucket, and API Gateway all live in eu-west-1.
  Two AWS services used by this Lambda are GLOBAL and must always target us-east-1
  regardless of where the Lambda is deployed — see notes below.

VERSION: 1.6.0   (bump this + add a CHANGELOG line every time you redeploy)

CHANGELOG
  1.6.0 - Account Inventory tab. build_account_inventory() derives per-account
          and org-wide service/resource breakdowns from the Security Hub open
          findings already collected in lambda_handler. New write_inventory_to_s3()
          writes inventory/{account_id}/latest.json and inventory/all/latest.json.
          New API route GET /inventory?account={id} added in api_lambda v1.5.2.
          No new IAM permissions required.
  1.5.9 - Fixed top-controls empty and reports missing findings regression from
          1.5.8. Added _extract_control_id() helper that accepts both
          ProductFields.ControlId (consolidated controls, e.g. 'EC2.1') and
          GeneratorId with 'security-control/' prefix (older standard-specific
          controls, e.g. 'security-control/EC2.1'). ARN-style GeneratorIds
          (GuardDuty, Macie) remain excluded. Used in summarize_by_account()
          and condense_finding().
  1.5.8 - controlId now only populated from ProductFields.ControlId (security-control
          findings only). GeneratorId fallback removed from summarize_by_account(),
          condense_finding(). Non-security-control findings (GuardDuty, Macie, etc.)
          still count toward severity totals but are excluded from top-controls table
          and have empty controlId in findings.json. _finding_fingerprint() retains
          GeneratorId fallback for stable de-duplication only. Security Hub ASFF
          ProductArn uses arn:aws:securityhub:{region}::product/aws/inspector,
          not arn:aws:inspector. is_inspector_finding() now checks the
          ::product/aws/inspector suffix plus ProductName/CompanyName/GeneratorId
          fallbacks. Added fetch_inspector_account_status() using Inspector2
          BatchGetAccountStatus so zero-finding accounts can be distinguished
          from Inspector being disabled. summarize_inspector_by_account() updated
          to accept inspector_statuses and account_ids — every account is always
          included in the output with a displayStatus field.
          New IAM permission required: inspector2:BatchGetAccountStatus.
  1.5.6 - Report generation moved to report_generator_lambda (on-demand).
          Removed: build_pdf_report, build_csv_report, build_excel_report,
          _pdf_safe, _build_and_upload_account_report, generate_and_upload_reports,
          REPORT_MAX_WORKERS, REPORT_TIME_GUARD_MS block, passed_raw,
          fpdf / openpyxl / csv / io imports.
          Aggregator now only writes summaries, snapshots, TA, Inspector data.
          Reports are generated on-demand when the user clicks Download in the
          dashboard (via POST /generate-report -> report_generator_lambda).
  1.5.5 - Replaced ProductArn API filters with a single open-findings query +
          Python-side split. fetch_open_findings() pulls all ACTIVE NEW/NOTIFIED
          findings with no ProductArn filter. is_inspector_finding() uses dual
          signal (ProductArn prefix + absence of ControlId) for robust detection.
          fetch_all_compliance_findings() has no ProductArn filter — Inspector
          findings carry no Compliance.Status so compute_control_scores() ignores
          them naturally.
  1.5.4 - Inspector findings separated from Security Hub.

Security Hub:
  Because this account is delegated admin, GetFindings already returns findings
  from all 70+ member accounts — no cross-account role needed. Each finding
  carries AwsAccountId telling you which account it belongs to.

Trusted Advisor:
  The AWS Support API is a GLOBAL service (us-east-1 only) and requires
  Business+/Enterprise support plan. This endpoint must always be called
  against us-east-1 even though the Lambda itself runs in eu-west-1.
  A lightweight cross-account role (TA_READER_ROLE_NAME) in each member
  account is assumed to call DescribeTrustedAdvisorChecks / DescribeTrustedAdvisorCheckResult.
  The delegated-admin account itself is queried using its own credentials.

  Required IAM permissions on the Lambda execution role:
    - sts:AssumeRole  (to assume TA_READER_ROLE_NAME in member accounts)
    - support:DescribeTrustedAdvisorChecks
    - support:DescribeTrustedAdvisorCheckResult

  Required IAM permissions on TA_READER_ROLE_NAME in EVERY member account:
    - support:DescribeTrustedAdvisorChecks
    - support:DescribeTrustedAdvisorCheckResult
    Trust policy must allow the Lambda execution role ARN to assume it.

Inspector v2:
  inspector2:BatchGetAccountStatus is required on the Lambda execution role.
  Inspector findings are forwarded into Security Hub and fetched via
  securityhub:GetFindings — no direct Inspector2 GetFindings call is made.

Writes to S3:
  summaries/accounts.json                    <- account list (dropdown)
  summaries/{account_id}/latest.json         <- per-account Security Hub summary
  summaries/{account_id}/findings.json       <- condensed findings (click-to-drill-down)
  summaries/all/latest.json                  <- all-accounts Security Hub summary
  summaries/all/findings.json                <- all-accounts condensed findings
  summaries/version.json                     <- aggregator version + last run timestamp
  snapshots/{YYYY-MM-DD}/findings.json       <- daily snapshot for delta tracking
  trusted-advisor/{account_id}/latest.json   <- per-account TA summary
  trusted-advisor/all/latest.json            <- all-accounts TA summary
  inspector/{account_id}/latest.json         <- per-account Inspector summary
  inspector/all/latest.json                  <- all-accounts Inspector summary
  reports/{account_id}/status.json           <- report generation status (written by report_generator_lambda)
  reports/{account_id}/latest.{pdf,csv,xlsx} <- generated on-demand by report_generator_lambda
  inventory/{account_id}/latest.json         <- per-account service/resource inventory
  inventory/all/latest.json                  <- org-wide service/resource inventory
"""

AGGREGATOR_VERSION = '1.6.0'


import boto3
import json
import logging
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# Configuration from environment variables — fail fast at cold-start if missing
# ---------------------------------------------------------------------------
def _require_env(name):
    val = os.environ.get(name, '').strip()
    if not val:
        raise EnvironmentError(
            f"Required environment variable '{name}' is not set. "
            "Set it in the Lambda function configuration before deploying."
        )
    return val

def _optional_env(name, default=''):
    return os.environ.get(name, default).strip()


BUCKET         = _require_env('BUCKET')
SES_FROM_EMAIL = _require_env('SES_FROM_EMAIL')
SES_TO_EMAIL   = _require_env('SES_TO_EMAIL')

def _parse_account_overrides(raw):
    overrides = {}
    for pair in raw.split(','):
        pair = pair.strip()
        if '=' in pair:
            aid, name = pair.split('=', 1)
            aid = aid.strip()
            if aid:
                overrides[aid] = name.strip()
    return overrides

ACCOUNT_NAME_OVERRIDES = _parse_account_overrides(
    _optional_env('ACCOUNT_NAME_OVERRIDES', '')
)

securityhub = boto3.client('securityhub')
inspector2  = boto3.client('inspector2', region_name='eu-west-1')
s3          = boto3.client('s3')
sts         = boto3.client('sts')
ses         = boto3.client('ses', region_name='us-east-1')

SEVERITY_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
SEVERITY_RANK  = {sev: i for i, sev in enumerate(SEVERITY_ORDER)}

# ---------------------------------------------------------------------------
# Timing helper — logs wall-clock duration of every major phase to CloudWatch
# ---------------------------------------------------------------------------
class _timed:
    """Context manager that logs the wall-clock duration of a named phase.

    Usage:
        with _timed('fetch_open_findings'):
            all_open = fetch_open_findings()

    Emits a single [TIMING] INFO line per phase so CloudWatch Logs Insights
    can query:
        filter @message like /TIMING/
        | parse @message "TIMING phase=* duration_s=*" as phase, duration
        | stats avg(duration) by phase
    """
    def __init__(self, name: str):
        self.name = name

    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_):
        elapsed = time.perf_counter() - self._start
        logger.info('TIMING phase=%s duration_s=%.2f', self.name, elapsed)


# ---------------------------------------------------------------------------
# Cross-account role assumed in every member account to read Trusted Advisor.
# ---------------------------------------------------------------------------
TA_READER_ROLE_NAME = 'TrustedAdvisorReadOnlyRole'


def get_account_names():
    """Pull friendly names directly from AWS Organizations."""
    org = boto3.client('organizations')
    names = {}
    paginator = org.get_paginator('list_accounts')
    for page in paginator.paginate():
        for acct in page['Accounts']:
            names[acct['Id']] = acct['Name']
    names.update(ACCOUNT_NAME_OVERRIDES)
    return names


# ---------------------------------------------------------------------------
# Security Hub — finding identification and fetching
# ---------------------------------------------------------------------------

# Inspector v2 findings forwarded into Security Hub use a ProductArn of the form:
#   arn:aws:securityhub:{region}::product/aws/inspector
# The suffix below is the reliable discriminator.
_INSPECTOR_PRODUCT_ARN_SUFFIX = '::product/aws/inspector'


def is_inspector_finding(f: dict) -> bool:
    """Return True when a Security Hub ASFF finding originated from Inspector v2.

    Inspector v2 findings forwarded into Security Hub carry:
      ProductArn  = arn:aws:securityhub:{region}::product/aws/inspector
      ProductName = Inspector
      CompanyName = Amazon
      GeneratorId = AWSInspector  (case may vary)

    Three independent signals are checked so the classification is robust
    even if a field is absent or casing differs between Inspector versions.
    Any one match is sufficient.
    """
    product_arn    = str(f.get('ProductArn',    '')).lower()
    product_name   = str(f.get('ProductName',   '')).lower()
    company_name   = str(f.get('CompanyName',   '')).lower()
    generator_id   = str(f.get('GeneratorId',   '')).lower()
    product_fields = f.get('ProductFields') or {}

    # Primary: ProductArn ends with the known Inspector product suffix
    inspector_product_arn = product_arn.endswith(_INSPECTOR_PRODUCT_ARN_SUFFIX)

    # Secondary: Inspector2 sets ProductVersion = 2 in ProductFields
    inspector_v2 = str(product_fields.get('aws/inspector/ProductVersion', '')) == '2'

    # Tertiary: product identity fields
    inspector_identity = (
        product_name == 'inspector'
        and company_name == 'amazon'
        and generator_id == 'awsinspector'
    )

    return inspector_product_arn or inspector_v2 or inspector_identity


def fetch_open_findings():
    """Fetch ALL ACTIVE, non-suppressed open findings in a single paginator call.
    No ProductArn filter is applied at the API level — the caller splits the
    result into Security Hub vs Inspector using is_inspector_finding().
    Fetches WorkflowStatus IN (NEW, NOTIFIED) — open, un-suppressed findings only.
    """
    findings = []
    paginator = securityhub.get_paginator('get_findings')
    page_iterator = paginator.paginate(
        Filters={
            'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
            'WorkflowStatus': [
                {'Value': 'NEW',      'Comparison': 'EQUALS'},
                {'Value': 'NOTIFIED', 'Comparison': 'EQUALS'},
            ],
        },
        PaginationConfig={'PageSize': 100},
    )
    for page in page_iterator:
        findings.extend(page['Findings'])
    return findings


def fetch_all_compliance_findings():
    """Fetch ALL ACTIVE findings regardless of WorkflowStatus — includes PASSED
    findings needed for the AWS-formula compliance score calculation.
    No ProductArn filter; Inspector findings carry no Compliance.Status so
    compute_control_scores() ignores them naturally.
    """
    findings = []
    paginator = securityhub.get_paginator('get_findings')
    page_iterator = paginator.paginate(
        Filters={
            'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
        },
        PaginationConfig={'PageSize': 100},
    )
    for page in page_iterator:
        findings.extend(page['Findings'])
    return findings


def compute_control_scores(compliance_findings):
    """Replicates AWS Security Hub's official security score formula:

        score = (passed controls / enabled controls) * 100

    Controls with NOT_AVAILABLE status are excluded from both numerator and
    denominator. A control's overall status per account is the worst status
    seen across all its findings: FAILED > WARNING > PASSED > NOT_AVAILABLE.

    Returns (per_account_scores, all_accounts_score).
    """
    STATUS_RANK = {'FAILED': 3, 'WARNING': 2, 'PASSED': 1, 'NOT_AVAILABLE': 0}
    control_status = {}

    for f in compliance_findings:
        acct       = f.get('AwsAccountId', 'UNKNOWN')
        control_id = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
        status     = f.get('Compliance', {}).get('Status', 'NOT_AVAILABLE')
        key        = (acct, control_id)
        if key not in control_status or STATUS_RANK.get(status, 0) > STATUS_RANK.get(control_status[key], 0):
            control_status[key] = status

    def _score_from_counts(passed, failed, warning):
        enabled = passed + failed + warning
        return 0 if enabled == 0 else round((passed / enabled) * 100)

    per_account = defaultdict(lambda: {'passedControls': 0, 'failedControls': 0, 'warningControls': 0})
    for (acct, _ctrl), status in control_status.items():
        if status == 'PASSED':
            per_account[acct]['passedControls'] += 1
        elif status == 'FAILED':
            per_account[acct]['failedControls'] += 1
        elif status == 'WARNING':
            per_account[acct]['warningControls'] += 1

    per_account_scores = {}
    total_passed = total_failed = total_warning = 0
    for acct, counts in per_account.items():
        enabled = counts['passedControls'] + counts['failedControls'] + counts['warningControls']
        per_account_scores[acct] = {
            **counts,
            'totalEnabledControls': enabled,
            'score': _score_from_counts(counts['passedControls'], counts['failedControls'], counts['warningControls']),
        }
        total_passed  += counts['passedControls']
        total_failed  += counts['failedControls']
        total_warning += counts['warningControls']

    all_accounts_score = {
        'passedControls':       total_passed,
        'failedControls':       total_failed,
        'warningControls':      total_warning,
        'totalEnabledControls': total_passed + total_failed + total_warning,
        'score':                _score_from_counts(total_passed, total_failed, total_warning),
    }
    return per_account_scores, all_accounts_score


def fetch_inspector_account_status(account_ids):
    """Get Inspector v2 enablement status for organisation accounts via
    BatchGetAccountStatus (max 100 per request).

    Inspector is regional. This checks eu-west-1 (the deployment region).

    Returns dict keyed by account ID:
      { accountId, status, enabled, enabledScanTypes, resourceState,
        errorCode, errorMessage }
    """
    valid_account_ids = sorted({
        str(aid) for aid in account_ids
        if str(aid).isdigit() and len(str(aid)) == 12
    })

    statuses = {}

    if not valid_account_ids:
        logger.warning('fetch_inspector_account_status: no valid account IDs supplied')
        return statuses

    # BatchGetAccountStatus supports a maximum of 100 accounts per request.
    for start in range(0, len(valid_account_ids), 100):
        batch = valid_account_ids[start:start + 100]
        try:
            response = inspector2.batch_get_account_status(accountIds=batch)

            for account in response.get('accounts', []):
                account_id     = account.get('accountId', 'UNKNOWN')
                resource_state = account.get('resourceState') or {}
                overall_state  = account.get('state') or {}

                scan_statuses = {
                    scan_type: (resource_state.get(scan_type) or {}).get('status', 'DISABLED')
                    for scan_type in ('ec2', 'ecr', 'lambda', 'lambdaCode', 'codeRepository')
                }
                enabled_scan_types = [k for k, v in scan_statuses.items() if v == 'ENABLED']

                statuses[account_id] = {
                    'accountId':        account_id,
                    'status':           overall_state.get('status', 'UNKNOWN'),
                    'enabled':          bool(enabled_scan_types),
                    'enabledScanTypes': enabled_scan_types,
                    'resourceState':    scan_statuses,
                    'errorCode':        overall_state.get('errorCode'),
                    'errorMessage':     overall_state.get('errorMessage'),
                }

            for failed in response.get('failedAccounts', []):
                account_id = failed.get('accountId', 'UNKNOWN')
                statuses[account_id] = {
                    'accountId':        account_id,
                    'status':           failed.get('status', 'ERROR'),
                    'enabled':          False,
                    'enabledScanTypes': [],
                    'resourceState':    failed.get('resourceStatus', {}),
                    'errorCode':        failed.get('errorCode'),
                    'errorMessage':     failed.get('errorMessage'),
                }

        except Exception as exc:
            logger.exception('Inspector status query failed for batch %s: %s', batch, exc)
            for aid in batch:
                statuses[aid] = {
                    'accountId':        aid,
                    'status':           'STATUS_CHECK_FAILED',
                    'enabled':          False,
                    'statusCheckFailed': True,
                    'enabledScanTypes': [],
                    'resourceState':    {},
                    'errorCode':        type(exc).__name__,
                    'errorMessage':     str(exc),
                }

    enabled_count = sum(1 for s in statuses.values() if s.get('enabled'))
    logger.info('Inspector status: checked=%d enabled=%d not_enabled_or_failed=%d',
                len(statuses), enabled_count, len(statuses) - enabled_count)
    return statuses


def _extract_control_id(f: dict) -> str:
    """Extract a clean Security Hub control ID from a finding.

    Security Hub findings carry the control ID in one of two places:
      1. ProductFields.ControlId  — e.g. 'EC2.1'  (consolidated controls)
      2. GeneratorId              — e.g. 'security-control/EC2.1'
                                        or 'arn:aws:securityhub:::ruleset/cis-aws-.../v/1.2.0/rule/1.1'

    Only pattern 2a ('security-control/<id>') is a meaningful control reference.
    GuardDuty / Macie GeneratorIds are full ARNs and are excluded.

    Returns the short control ID string (e.g. 'EC2.1') or '' if not a
    recognised security-control finding.
    """
    # Primary: ProductFields.ControlId (consolidated controls)
    ctrl = (f.get('ProductFields') or {}).get('ControlId', '').strip()
    if ctrl:
        return ctrl

    # Secondary: GeneratorId with 'security-control/' prefix
    gen = (f.get('GeneratorId') or '').strip()
    if gen.startswith('security-control/'):
        return gen.split('security-control/', 1)[1].strip()

    return ''


def summarize_by_account(findings):
    """Group OPEN Security Hub findings by AwsAccountId and compute per-account
    severity counts and top controls. Returns (summaries, by_account)."""
    by_account = defaultdict(list)
    for f in findings:
        by_account[f.get('AwsAccountId', 'UNKNOWN')].append(f)

    summaries = {}
    for account_id, acct_findings in by_account.items():
        severity_counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        control_counts  = {}

        for f in acct_findings:
            sev = f.get('Severity', {}).get('Label', 'LOW')
            if sev in severity_counts:
                severity_counts[sev] += 1
            # Only include in top-controls if finding has a real Security Hub
            # control ID. Uses _extract_control_id() which accepts both
            # ProductFields.ControlId and GeneratorId 'security-control/<id>'
            # patterns, but ignores GuardDuty/Macie ARN-style GeneratorIds.
            control_id = _extract_control_id(f)
            if control_id:
                title = f.get('Title', 'Unknown control')
                if control_id not in control_counts:
                    control_counts[control_id] = {'id': control_id, 'title': title, 'severity': sev, 'count': 0}
                control_counts[control_id]['count'] += 1

        summaries[account_id] = {
            'accountId':   account_id,
            'critical':    severity_counts['CRITICAL'],
            'high':        severity_counts['HIGH'],
            'medium':      severity_counts['MEDIUM'],
            'low':         severity_counts['LOW'],
            'score':       0,   # overwritten by compute_control_scores()
            'lastScan':    datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'topControls': sorted(control_counts.values(), key=lambda x: -x['count'])[:5],
        }
    return summaries, by_account


def condense_finding(f):
    """Small, frontend-friendly shape for a single Security Hub finding.
    controlId uses _extract_control_id() which accepts ProductFields.ControlId
    and GeneratorId 'security-control/<id>' patterns. Returns '' for non-control
    findings (GuardDuty, Macie, etc.) which are excluded from reports."""
    resources = f.get('Resources', [{}])
    return {
        'severity':        f.get('Severity', {}).get('Label', 'LOW'),
        'title':           f.get('Title', 'Unknown finding'),
        'resourceId':      resources[0].get('Id', 'unknown') if resources else 'unknown',
        'controlId':       _extract_control_id(f),
        'workflowStatus':  f.get('Workflow', {}).get('Status', 'UNKNOWN'),
        'region':          f.get('Region', ''),
        'firstObservedAt': f.get('FirstObservedAt', ''),
    }


# ---------------------------------------------------------------------------
# Snapshot helpers — day-over-day comparison
# ---------------------------------------------------------------------------

def _finding_fingerprint(f):
    """Stable unique key for a finding: account + control + resource."""
    if 'controlId' in f:
        return f"{f.get('accountId', f.get('AwsAccountId', 'UNKNOWN'))}|{f.get('controlId','')}|{f.get('resourceId','')}"
    resources   = f.get('Resources', [{}])
    resource_id = resources[0].get('Id', 'unknown') if resources else 'unknown'
    control_id  = f.get('ProductFields', {}).get('ControlId') or f.get('GeneratorId', 'UNKNOWN')
    return f"{f.get('AwsAccountId', 'UNKNOWN')}|{control_id}|{resource_id}"


def write_daily_snapshot(findings):
    """Write today's open findings to snapshots/{YYYY-MM-DD}/findings.json."""
    today     = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    condensed = []
    for f in findings:
        cf              = condense_finding(f)
        cf['_fp']       = _finding_fingerprint(f)
        cf['accountId'] = f.get('AwsAccountId', 'UNKNOWN')
        condensed.append(cf)
    s3.put_object(
        Bucket=BUCKET,
        Key=f'snapshots/{today}/findings.json',
        Body=json.dumps(condensed),
        ContentType='application/json',
    )
    logger.info('Snapshot written: snapshots/%s/findings.json (%d findings)', today, len(condensed))
    return condensed


def load_yesterday_snapshot():
    """Load yesterday's snapshot. Returns [] if none exists."""
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d')
    try:
        obj  = s3.get_object(Bucket=BUCKET, Key=f'snapshots/{yesterday}/findings.json')
        data = json.loads(obj['Body'].read().decode())
        logger.info('Loaded yesterday snapshot: %d findings from %s', len(data), yesterday)
        return data
    except s3.exceptions.NoSuchKey:
        logger.info('No snapshot found for %s — first run or gap in schedule', yesterday)
        return []
    except Exception as exc:
        logger.warning('Could not load yesterday snapshot: %s', exc)
        return []


def compare_snapshots(today_condensed, yesterday_condensed):
    """Compare today vs yesterday by fingerprint.
    Returns (new_findings, resolved_findings)."""
    today_fps     = {cf['_fp']: cf for cf in today_condensed     if '_fp' in cf}
    yesterday_fps = {cf['_fp']: cf for cf in yesterday_condensed if '_fp' in cf}

    new_findings      = [cf for fp, cf in today_fps.items()     if fp not in yesterday_fps]
    resolved_findings = [cf for fp, cf in yesterday_fps.items() if fp not in today_fps]

    new_crit_high = sum(1 for f in new_findings if f.get('severity', '') in ('CRITICAL', 'HIGH'))
    logger.info('Snapshot delta — new: %d (Crit/High: %d), resolved: %d',
                len(new_findings), new_crit_high, len(resolved_findings))
    return new_findings, resolved_findings


# ---------------------------------------------------------------------------
# SES email digest — new Critical/High findings
# ---------------------------------------------------------------------------

def send_email_digest(new_findings, account_names):
    """Send an HTML email via SES listing new Critical/High findings.
    Silently skips if SES_TO_EMAIL is still the placeholder or SES call fails."""
    if 'UPDATE_YOUR_DL' in SES_TO_EMAIL:
        logger.info('SES email skipped — SES_TO_EMAIL is still the placeholder value.')
        return

    crit_high = [f for f in new_findings if f.get('severity', '') in ('CRITICAL', 'HIGH')]
    if not crit_high:
        logger.info('No new Critical/High findings — email digest not sent.')
        return

    today     = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    rows_html = ''
    for f in sorted(crit_high, key=lambda x: (x.get('severity', ''), x.get('controlId', ''))):
        sev   = f.get('severity', '')
        color = '#dc3545' if sev == 'CRITICAL' else '#fd7e14'
        acct  = f.get('accountId', '')
        rows_html += f"""
        <tr>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;">
            <span style="background:{color};color:#fff;padding:2px 8px;border-radius:4px;
                         font-size:11px;font-weight:bold;">{sev}</span></td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-family:monospace;font-size:12px;">{f.get('controlId','')}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;">{f.get('title','')}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-size:11px;">
            {account_names.get(acct, acct)}<br><span style="color:#888;">{acct}</span></td>
          <td style="padding:6px 10px;border-bottom:1px solid #eee;font-family:monospace;font-size:11px;">{f.get('resourceId','')[-50:]}</td>
        </tr>"""

    html_body = f"""
    <html><body style="font-family:Calibri,Arial,sans-serif;color:#1c2340;max-width:900px;margin:0 auto;">
      <div style="background:#1E2761;padding:18px 24px;border-radius:6px 6px 0 0;">
        <h2 style="color:#fff;margin:0;font-size:18px;">
          &#x1F514; Security Hub &#8212; New Critical/High Findings ({today})
        </h2>
      </div>
      <div style="background:#f5f7fc;padding:14px 24px;border:1px solid #dde4f0;border-top:none;">
        <p style="margin:0;font-size:13px;">
          <strong>{len(crit_high)}</strong> new Critical or High severity finding(s) appeared since
          yesterday&#x2019;s scan. Full details and downloadable reports are available on the
          <a href="https://security.vijaymdm.click" style="color:#2E6DA4;">Security Hub Dashboard</a>.
        </p>
      </div>
      <table width="100%" cellpadding="0" cellspacing="0"
             style="border-collapse:collapse;border:1px solid #dde4f0;border-top:none;">
        <thead style="background:#eef2f7;">
          <tr>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Severity</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Control ID</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Finding</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Account</th>
            <th style="padding:8px 10px;text-align:left;font-size:12px;border-bottom:2px solid #c8d4e8;">Resource</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
      <div style="padding:12px 24px;background:#f5f7fc;border:1px solid #dde4f0;border-top:none;
                  border-radius:0 0 6px 6px;">
        <p style="margin:0;font-size:11px;color:#888;">
          Sent by Security Hub Aggregator v{AGGREGATOR_VERSION} &middot; {today}
          &middot; Auto-generated &#8212; do not reply.
        </p>
      </div>
    </body></html>"""

    try:
        ses.send_email(
            Source=SES_FROM_EMAIL,
            Destination={'ToAddresses': [SES_TO_EMAIL]},
            Message={
                'Subject': {'Data': f'[Security Hub] {len(crit_high)} New Critical/High Finding(s) — {today}'},
                'Body': {
                    'Html': {'Data': html_body},
                    'Text': {'Data': (
                        f'Security Hub: {len(crit_high)} new Critical/High findings on {today}. '
                        'See dashboard: https://security.vijaymdm.click'
                    )},
                },
            },
        )
        logger.info('SES digest sent to %s (%d new Crit/High findings)', SES_TO_EMAIL, len(crit_high))
    except Exception as exc:
        logger.warning('SES send_email failed (check SES verification + IAM): %s', exc)


# ---------------------------------------------------------------------------
# S3 write helpers — Security Hub summaries
# ---------------------------------------------------------------------------

def write_to_s3(summaries, by_account, account_names, all_accounts_score):
    """Write all Security Hub summaries to S3. Per-account puts are
    parallelised via a thread pool; combined all/version objects are written
    after the pool completes."""
    S3_WRITE_MAX_WORKERS = 20

    account_list = [
        {'id': aid, 'name': account_names.get(aid, aid), 'accountId': aid}
        for aid in sorted(summaries.keys())
    ]
    s3.put_object(Bucket=BUCKET, Key='summaries/accounts.json',
                  Body=json.dumps(account_list), ContentType='application/json')

    condensed_by_account = {
        account_id: [condense_finding(f) for f in by_account.get(account_id, [])]
        for account_id in summaries
    }
    all_condensed = [c for clist in condensed_by_account.values() for c in clist]

    def _put_account(account_id):
        summary   = summaries[account_id]
        condensed = condensed_by_account[account_id]
        s3.put_object(Bucket=BUCKET, Key=f'summaries/{account_id}/latest.json',
                      Body=json.dumps(summary), ContentType='application/json')
        s3.put_object(Bucket=BUCKET, Key=f'summaries/{account_id}/findings.json',
                      Body=json.dumps(condensed), ContentType='application/json')

    with ThreadPoolExecutor(max_workers=S3_WRITE_MAX_WORKERS) as pool:
        futures = {pool.submit(_put_account, aid): aid for aid in summaries}
        for future in as_completed(futures):
            aid = futures[future]
            try:
                future.result()
            except Exception as exc:
                logger.warning('write_to_s3: failed to write summaries for account %s: %s', aid, exc)

    all_summary = {
        'accountId':            'all',
        'critical':             sum(s['critical'] for s in summaries.values()),
        'high':                 sum(s['high']     for s in summaries.values()),
        'medium':               sum(s['medium']   for s in summaries.values()),
        'low':                  sum(s['low']      for s in summaries.values()),
        'score':                all_accounts_score['score'],
        'passedControls':       all_accounts_score['passedControls'],
        'failedControls':       all_accounts_score['failedControls'],
        'warningControls':      all_accounts_score['warningControls'],
        'totalEnabledControls': all_accounts_score['totalEnabledControls'],
        'lastScan':             datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'topControls':          [],
    }
    s3.put_object(Bucket=BUCKET, Key='summaries/all/latest.json',
                  Body=json.dumps(all_summary), ContentType='application/json')
    s3.put_object(Bucket=BUCKET, Key='summaries/all/findings.json',
                  Body=json.dumps(all_condensed), ContentType='application/json')
    s3.put_object(
        Bucket=BUCKET, Key='summaries/version.json',
        Body=json.dumps({
            'aggregatorVersion': AGGREGATOR_VERSION,
            'lastRun': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        }),
        ContentType='application/json',
    )
    logger.info('write_to_s3: wrote %d account summaries + all + version', len(summaries))


# ---------------------------------------------------------------------------
# Trusted Advisor
# ---------------------------------------------------------------------------

def fetch_trusted_advisor_checks(account_id, own_account_id):
    """Fetch Trusted Advisor checks for a single account. Returns [] on any error."""
    try:
        if account_id == own_account_id:
            support = boto3.client('support', region_name='us-east-1')
        else:
            role_arn = f'arn:aws:iam::{account_id}:role/{TA_READER_ROLE_NAME}'
            creds    = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f'TAReader-{account_id}',
                ExternalId=f'{account_id}-ta-reader',
            )['Credentials']
            support = boto3.client(
                'support', region_name='us-east-1',
                aws_access_key_id=creds['AccessKeyId'],
                aws_secret_access_key=creds['SecretAccessKey'],
                aws_session_token=creds['SessionToken'],
            )

        checks_resp = support.describe_trusted_advisor_checks(language='en')
        checks = []
        for check in checks_resp.get('checks', []):
            try:
                result = support.describe_trusted_advisor_check_result(
                    checkId=check['id'], language='en'
                )
                r = result.get('result', {})
                checks.append({
                    'id':       check['id'],
                    'name':     check['name'],
                    'category': check.get('category', ''),
                    'status':   r.get('status', 'not_available'),
                    'resourcesSummary':        r.get('resourcesSummary'),
                    'estimatedMonthlySavings': r.get('categorySpecificSummary', {})
                                                 .get('costOptimizing', {})
                                                 .get('estimatedMonthlySavings'),
                })
            except Exception as check_err:
                logger.warning('TA check %s skipped for account %s: %s',
                               check['id'], account_id, check_err)
        logger.info('TA fetched %d checks for account %s', len(checks), account_id)
        return checks

    except Exception as e:
        logger.warning('fetch_trusted_advisor_checks failed for account %s: %s', account_id, e)
        return []


def summarize_ta_by_account(ta_by_account):
    """Build per-account and all-accounts Trusted Advisor summaries."""
    ta_summaries        = {}
    all_checks_combined = []

    for account_id, checks in ta_by_account.items():
        ta_summaries[account_id] = {
            'accountId':    account_id,
            'totalError':   sum(1 for c in checks if c['status'] == 'error'),
            'totalWarning': sum(1 for c in checks if c['status'] == 'warning'),
            'totalOk':      sum(1 for c in checks if c['status'] == 'ok'),
            'lastRefresh':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'checks':       checks,
        }
        all_checks_combined.extend(checks)

    ta_all_summary = {
        'accountId':    'all',
        'totalError':   sum(1 for c in all_checks_combined if c['status'] == 'error'),
        'totalWarning': sum(1 for c in all_checks_combined if c['status'] == 'warning'),
        'totalOk':      sum(1 for c in all_checks_combined if c['status'] == 'ok'),
        'lastRefresh':  datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'checks':       all_checks_combined,
    }
    return ta_summaries, ta_all_summary


def write_ta_to_s3(ta_summaries_by_account, ta_all_summary):
    """Write Trusted Advisor summaries to S3."""
    for account_id, summary in ta_summaries_by_account.items():
        s3.put_object(
            Bucket=BUCKET,
            Key=f'trusted-advisor/{account_id}/latest.json',
            Body=json.dumps(summary),
            ContentType='application/json',
        )
    s3.put_object(
        Bucket=BUCKET,
        Key='trusted-advisor/all/latest.json',
        Body=json.dumps(ta_all_summary),
        ContentType='application/json',
    )
    logger.info('write_ta_to_s3: wrote %d account TA summaries + all',
                len(ta_summaries_by_account))


# ---------------------------------------------------------------------------
# Inspector — summarisation and S3 writer
# ---------------------------------------------------------------------------

def summarize_inspector_by_account(inspector_findings, inspector_statuses, account_ids):
    """Build Inspector summaries for all accounts.

    Every account in account_ids is included — even accounts with zero active
    findings — so the dashboard can distinguish:
      ENABLED_WITH_FINDINGS    — Inspector on, findings present
      ENABLED_NO_FINDINGS      — Inspector on, no current findings
      NOT_ENABLED              — Inspector disabled
      STATUS_CHECK_FAILED      — BatchGetAccountStatus call failed
      UNKNOWN                  — Status not returned for this account

    Returns (summaries_by_account, all_accounts_summary).
    """
    by_account = defaultdict(list)
    for f in inspector_findings:
        by_account[f.get('AwsAccountId', 'UNKNOWN')].append(f)

    # Process every known account, plus any that only appear in findings
    all_ids = sorted({str(aid) for aid in account_ids if aid} | set(by_account.keys()))

    summaries = {}

    for account_id in all_ids:
        findings = by_account.get(account_id, [])
        status   = inspector_statuses.get(account_id, {})

        sev_counts      = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        type_counts     = defaultdict(int)
        resource_counts = defaultdict(int)
        title_counts    = defaultdict(int)

        for f in findings:
            sev = (f.get('Severity') or {}).get('Label', 'LOW')
            if sev in sev_counts:
                sev_counts[sev] += 1
            types   = f.get('Types') or []
            ftype   = types[0].split('/')[-1] if types else 'Other'
            type_counts[ftype] += 1
            res     = (f.get('Resources') or [{}])[0]
            rid     = res.get('Id', 'unknown')
            resource_counts[rid[-60:] if len(rid) > 60 else rid] += 1
            title_counts[f.get('Title', 'Unknown')] += 1

        status_check_failed = status.get('statusCheckFailed', False)
        inspector_enabled   = status.get('enabled')  # True / False / None

        if status_check_failed:
            display_status = 'STATUS_CHECK_FAILED'
            status_message = 'Unable to determine Inspector status'
        elif inspector_enabled is True and findings:
            display_status = 'ENABLED_WITH_FINDINGS'
            status_message = f'Inspector enabled with {len(findings)} active findings'
        elif inspector_enabled is True:
            display_status = 'ENABLED_NO_FINDINGS'
            status_message = 'Inspector enabled with no active findings'
        elif inspector_enabled is False:
            display_status = 'NOT_ENABLED'
            status_message = 'Inspector is not enabled for any supported scan type'
        else:
            display_status = 'UNKNOWN'
            status_message = 'Inspector status is unknown'

        sorted_findings = sorted(
            findings,
            key=lambda f: SEVERITY_RANK.get((f.get('Severity') or {}).get('Label', 'LOW'), 99),
        )
        condensed_findings = [
            {
                'severity':        (f.get('Severity') or {}).get('Label', 'LOW'),
                'title':           f.get('Title', 'Unknown finding'),
                'resourceId':      ((f.get('Resources') or [{}])[0]).get('Id', 'unknown'),
                'resourceType':    ((f.get('Resources') or [{}])[0]).get('Type', 'Unknown'),
                'region':          f.get('Region', ''),
                'firstObservedAt': f.get('FirstObservedAt', ''),
                'cveIds':          [
                    v.get('Id') for v in (f.get('Vulnerabilities') or [])
                    if v.get('Id')
                ][:3],
            }
            for f in sorted_findings[:500]
        ]

        summaries[account_id] = {
            'accountId':          account_id,
            'inspectorEnabled':   inspector_enabled,
            'inspectorStatus':    status.get('status', 'UNKNOWN'),
            'displayStatus':      display_status,
            'statusMessage':      status_message,
            'enabledScanTypes':   status.get('enabledScanTypes', []),
            'resourceState':      status.get('resourceState', {}),
            'statusErrorCode':    status.get('errorCode'),
            'statusErrorMessage': status.get('errorMessage'),
            'critical':           sev_counts['CRITICAL'],
            'high':               sev_counts['HIGH'],
            'medium':             sev_counts['MEDIUM'],
            'low':                sev_counts['LOW'],
            'total':              len(findings),
            'byType':             dict(type_counts),
            'topResources':       sorted(
                [{'resourceId': r, 'count': c} for r, c in resource_counts.items()],
                key=lambda x: -x['count'])[:10],
            'topFindings':        sorted(
                [{'title': t, 'count': c} for t, c in title_counts.items()],
                key=lambda x: -x['count'])[:10],
            'lastScan':           datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'findings':           condensed_findings,
        }

    # All-accounts aggregate
    all_type_counts     = defaultdict(int)
    all_resource_counts = defaultdict(int)
    all_title_counts    = defaultdict(int)

    for s in summaries.values():
        for ftype, cnt in s.get('byType', {}).items():
            all_type_counts[ftype] += cnt

    for f in inspector_findings:
        res = (f.get('Resources') or [{}])[0]
        rid = res.get('Id', 'unknown')
        all_resource_counts[rid[-60:] if len(rid) > 60 else rid] += 1
        all_title_counts[f.get('Title', 'Unknown')] += 1

    enabled_count  = sum(1 for s in summaries.values() if s.get('inspectorEnabled') is True)
    disabled_count = sum(1 for s in summaries.values() if s.get('inspectorEnabled') is False)
    unknown_count  = sum(1 for s in summaries.values() if s.get('inspectorEnabled') is None)

    all_summary = {
        'accountId':        'all',
        'accountsChecked':  len(summaries),
        'enabledAccounts':  enabled_count,
        'disabledAccounts': disabled_count,
        'unknownAccounts':  unknown_count,
        'critical':         sum(s['critical'] for s in summaries.values()),
        'high':             sum(s['high']     for s in summaries.values()),
        'medium':           sum(s['medium']   for s in summaries.values()),
        'low':              sum(s['low']      for s in summaries.values()),
        'total':            sum(s['total']    for s in summaries.values()),
        'byType':           dict(all_type_counts),
        'topResources':     sorted(
            [{'resourceId': r, 'count': c} for r, c in all_resource_counts.items()],
            key=lambda x: -x['count'])[:10],
        'topFindings':      sorted(
            [{'title': t, 'count': c} for t, c in all_title_counts.items()],
            key=lambda x: -x['count'])[:10],
        'lastScan':         datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
        'findings':         [],
    }

    return summaries, all_summary


def write_inspector_to_s3(inspector_summaries, all_inspector_summary):
    """Write Inspector summaries to S3."""
    for account_id, summary in inspector_summaries.items():
        s3.put_object(
            Bucket=BUCKET,
            Key=f'inspector/{account_id}/latest.json',
            Body=json.dumps(summary),
            ContentType='application/json',
        )
    s3.put_object(
        Bucket=BUCKET,
        Key='inspector/all/latest.json',
        Body=json.dumps(all_inspector_summary),
        ContentType='application/json',
    )
    logger.info('write_inspector_to_s3: wrote %d account Inspector summaries + all',
                len(inspector_summaries))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def lambda_handler(event, context):
    handler_start = time.perf_counter()

    def remaining_ms():
        try:
            return context.get_remaining_time_in_millis()
        except Exception:
            return 999_999_999

    account_names  = get_account_names()
    own_account_id = sts.get_caller_identity()['Account']
    logger.info('Running as account %s, processing %d known accounts',
                own_account_id, len(account_names))
    logger.info('Aggregator version: %s', AGGREGATOR_VERSION)

    # ── Single open-findings query, split in Python ──────────────────────
    with _timed('fetch_open_findings'):
        all_open_findings = fetch_open_findings()
    logger.info('fetch_open_findings: %d total open findings', len(all_open_findings))

    findings           = [f for f in all_open_findings if not is_inspector_finding(f)]
    inspector_findings = [f for f in all_open_findings if     is_inspector_finding(f)]
    logger.info('split: %d Security Hub findings, %d Inspector findings',
                len(findings), len(inspector_findings))

    with _timed('summarize_by_account'):
        summaries, by_account = summarize_by_account(findings)

    # ── Compliance score ──────────────────────────────────────────────────
    with _timed('fetch_all_compliance_findings'):
        compliance_findings = fetch_all_compliance_findings()
    logger.info('fetch_all_compliance_findings: %d findings', len(compliance_findings))

    with _timed('compute_control_scores'):
        per_account_scores, all_accounts_score = compute_control_scores(compliance_findings)

    for account_id, summary in summaries.items():
        control_score = per_account_scores.get(account_id, {
            'passedControls': 0, 'failedControls': 0,
            'warningControls': 0, 'totalEnabledControls': 0, 'score': 0,
        })
        summary.update(control_score)

    for account_id, control_score in per_account_scores.items():
        if account_id in summaries or not account_id:
            continue
        summaries[account_id] = {
            'accountId': account_id,
            'critical': 0, 'high': 0, 'medium': 0, 'low': 0,
            'lastScan': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'topControls': [], **control_score,
        }
        by_account[account_id] = []

    # ── Day-over-day snapshot comparison ─────────────────────────────────
    with _timed('write_daily_snapshot'):
        today_snapshot = write_daily_snapshot(findings)
    with _timed('load_yesterday_snapshot'):
        yesterday_snapshot = load_yesterday_snapshot()
    with _timed('compare_snapshots'):
        new_findings, resolved_findings = compare_snapshots(today_snapshot, yesterday_snapshot)

    # ── Write S3 summaries ────────────────────────────────────────────────
    with _timed('write_to_s3'):
        write_to_s3(summaries, by_account, account_names, all_accounts_score)
    logger.info('Security Hub: wrote summaries for %d accounts', len(summaries))

    # ── SES email digest ──────────────────────────────────────────────────
    with _timed('send_email_digest'):
        send_email_digest(new_findings, account_names)

    # ── Trusted Advisor ───────────────────────────────────────────────────
    all_account_ids = set(summaries.keys()) | set(account_names.keys())
    all_account_ids.discard('')

    ta_by_account = {}
    ta_errors     = 0
    TA_MAX_WORKERS = 10

    with _timed('fetch_trusted_advisor_all_accounts'):
        with ThreadPoolExecutor(max_workers=TA_MAX_WORKERS) as pool:
            future_to_account = {
                pool.submit(fetch_trusted_advisor_checks, aid, own_account_id): aid
                for aid in sorted(all_account_ids)
            }
            for future in as_completed(future_to_account):
                aid = future_to_account[future]
                try:
                    checks = future.result()
                    if checks:
                        ta_by_account[aid] = checks
                    else:
                        ta_errors += 1
                except Exception as exc:
                    logger.warning('TA future for account %s raised unexpectedly: %s', aid, exc)
                    ta_errors += 1

    if ta_by_account:
        with _timed('summarize_and_write_ta'):
            ta_summaries_by_account, ta_all_summary = summarize_ta_by_account(ta_by_account)
            write_ta_to_s3(ta_summaries_by_account, ta_all_summary)
        logger.info('Trusted Advisor: wrote data for %d accounts (%d skipped)',
                    len(ta_summaries_by_account), ta_errors)
    else:
        logger.warning('Trusted Advisor: no data — check support plan / IAM role %s',
                       TA_READER_ROLE_NAME)

    # ── Inspector ─────────────────────────────────────────────────────────
    with _timed('fetch_inspector_account_status'):
        inspector_statuses = fetch_inspector_account_status(all_account_ids)

    with _timed('summarize_and_write_inspector'):
        inspector_summaries, all_inspector_summary = summarize_inspector_by_account(
            inspector_findings=inspector_findings,
            inspector_statuses=inspector_statuses,
            account_ids=all_account_ids,
        )
        write_inspector_to_s3(inspector_summaries, all_inspector_summary)

    inspector_accounts_processed = len(inspector_summaries)
    inspector_enabled_accounts   = sum(1 for s in inspector_statuses.values() if s.get('enabled'))
    inspector_disabled_accounts  = sum(1 for s in inspector_statuses.values() if s.get('enabled') is False)

    logger.info(
        'Inspector: accounts=%d enabled=%d disabled_or_failed=%d active_findings=%d',
        inspector_accounts_processed, inspector_enabled_accounts,
        inspector_disabled_accounts, len(inspector_findings),
    )

    total_elapsed = time.perf_counter() - handler_start
    logger.info('TIMING lambda_handler_total duration_s=%.2f', total_elapsed)

    return {
        'statusCode': 200,
        'body': json.dumps({
            'version':                    AGGREGATOR_VERSION,
            'accountsProcessed':          len(summaries),
            'totalFindings':              len(findings),
            'newFindings':                len(new_findings),
            'resolvedFindings':           len(resolved_findings),
            'taAccountsProcessed':        len(ta_by_account),
            'taAccountsSkipped':          ta_errors,
            'inspectorAccountsProcessed': inspector_accounts_processed,
            'inspectorEnabledAccounts':   inspector_enabled_accounts,
            'inspectorDisabledAccounts':  inspector_disabled_accounts,
            'inspectorTotalFindings':     len(inspector_findings),
            'totalDurationSeconds':       round(total_elapsed, 1),
        }),
    }
