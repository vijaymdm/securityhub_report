import React, { useState, useMemo, useEffect, useCallback, Component } from 'react';
import { AlertTriangle, ShieldCheck, ShieldAlert, Download, ChevronDown, Activity, Clock } from 'lucide-react';

// VERSION: 1.5.2   (bump this + add a CHANGELOG line every time you redeploy)
//
// CHANGELOG
//   1.5.2 - On-demand report generation. Download section replaced with
//           generate→poll→download flow:
//           · "Generate report" calls POST /generate-report (returns 202 immediately).
//           · Dashboard polls GET /report-status every 3 s until status === 'done'.
//           · On completion, automatically fetches GET /report-url and triggers download.
//           · reportPhase state machine: idle | generating | downloading | done | error.
//           · Progress bar with elapsed-time counter shown during generation.
//           · Reports are no longer pre-built by the aggregator.
//   1.5.1 - handleDownload extracts JSON error body from non-OK API responses.
//   1.5.0 - AWS Inspector tab added.
//           · ErrorBoundary wraps full dashboard — crash shows friendly message, not blank screen.
//           · All fetch() calls have a 10-second AbortController timeout.
//           · Report download uses programmatic <a> click instead of window.open()
//             so popup blockers can never silently swallow the download.
//           · TrustedAdvisorTab fetch also has 10s timeout.
//           · accountId prop to TrustedAdvisorTab was undefined variable — fixed to apiAccountId.
//   1.4.0 - Search + multi-select account picker. Aggregates severity
//           counts client-side across selected accounts with caching.
//   1.3.0 - Added compliance-score transparency line (passed/enabled controls),
//           Trusted Advisor tab, click-to-drill-down severity cards.
//   1.2.0 - Added CSV/PDF format radio selector for report download.
//   1.1.0 - Added click-to-drill-down: clicking a severity card shows matching findings.
//   1.0.0 - Initial: account selector, score dial, severity cards, top controls,
//           PDF download.
const DASHBOARD_VERSION = '1.5.2';

// ---- API base URL ----
// Set VITE_API_BASE in your .env file (e.g. VITE_API_BASE=https://xxx.execute-api.region.amazonaws.com)
// Falls back to the placeholder so the app still loads in dev without the env file.
const API_BASE = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_API_BASE)
  || 'https://REPLACE_WITH_YOUR_API_GATEWAY_URL';

// Default timeout for all API fetch calls (ms)
const FETCH_TIMEOUT_MS = 10_000;

/**
 * fetchWithTimeout — wraps fetch() with an AbortController timeout.
 * Throws a DOMException with name 'AbortError' if the request exceeds
 * FETCH_TIMEOUT_MS, which downstream .catch() handlers surface as a
 * user-friendly "Request timed out" message.
 */
function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();
  const timerId = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  return fetch(url, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(timerId));
}

function formatFetchError(err) {
  if (err?.name === 'AbortError') return 'Request timed out. Check your network or try again.';
  return err?.message || 'An unexpected error occurred.';
}

// ---------------------------------------------------------------------------
// ErrorBoundary — catches render-time exceptions anywhere in the tree and
// shows a friendly recovery UI instead of a blank screen.
// ---------------------------------------------------------------------------
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    // In production you'd send this to an error-tracking service (e.g. Sentry)
    console.error('[ErrorBoundary] Uncaught render error:', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0F1720] text-[#E8EBEF] flex items-center justify-center px-6">
          <div className="max-w-md text-center">
            <div className="w-12 h-12 rounded-full bg-[#E5484D]/10 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle size={24} className="text-[#E5484D]" />
            </div>
            <h2 className="text-lg font-semibold mb-2">Something went wrong</h2>
            <p className="text-sm text-[#8A96A3] mb-6">
              The dashboard encountered an unexpected error. Refresh the page to try again.
              If the problem persists, check the browser console for details.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="rounded-md bg-[#E8EBEF] text-[#0F1720] px-5 py-2 text-sm font-medium hover:bg-white transition-colors"
            >
              Reload dashboard
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ---------------------------------------------------------------------------
// Severity + TA style maps
// ---------------------------------------------------------------------------
const SEVERITY_STYLES = {
  CRITICAL: { text: 'text-[#E5484D]', bg: 'bg-[#E5484D]/10', ring: 'ring-[#E5484D]/30' },
  HIGH:     { text: 'text-[#F5A623]', bg: 'bg-[#F5A623]/10', ring: 'ring-[#F5A623]/30' },
  MEDIUM:   { text: 'text-[#5B9BD5]', bg: 'bg-[#5B9BD5]/10', ring: 'ring-[#5B9BD5]/30' },
  LOW:      { text: 'text-[#8A96A3]', bg: 'bg-[#8A96A3]/10', ring: 'ring-[#8A96A3]/30' },
};

const TA_STYLES = {
  error:   { text: 'text-[#E5484D]', bg: 'bg-[#E5484D]/10', ring: 'ring-[#E5484D]/30', label: 'Action Required' },
  warning: { text: 'text-[#F5A623]', bg: 'bg-[#F5A623]/10', ring: 'ring-[#F5A623]/30', label: 'Investigate' },
  ok:      { text: 'text-[#3DD68C]', bg: 'bg-[#3DD68C]/10', ring: 'ring-[#3DD68C]/30', label: 'No Problems' },
};

// ---------------------------------------------------------------------------
// ScoreDial
// ---------------------------------------------------------------------------
function ScoreDial({ score }) {
  const safeScore = typeof score === 'number' && !isNaN(score) ? score : 0;
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (safeScore / 100) * circumference;
  const color = safeScore >= 80 ? '#3DD68C' : safeScore >= 60 ? '#F5A623' : '#E5484D';

  return (
    <div className="relative w-36 h-36 flex items-center justify-center">
      <svg width="144" height="144" viewBox="0 0 144 144" className="-rotate-90">
        <circle cx="72" cy="72" r={radius} fill="none" stroke="#1B2430" strokeWidth="10" />
        <circle
          cx="72" cy="72" r={radius} fill="none"
          stroke={color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 700ms ease-out' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-mono text-3xl font-semibold text-[#E8EBEF] tabular-nums">{safeScore}</span>
        <span className="text-[10px] tracking-[0.15em] text-[#8A96A3] uppercase mt-0.5">Compliant</span>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// CountCard
// ---------------------------------------------------------------------------
function CountCard({ label, value, severity, Icon, onClick, active }) {
  const s = SEVERITY_STYLES[severity];
  return (
    <button
      onClick={onClick}
      className={`flex-1 min-w-[130px] text-left rounded-lg border ${active ? 'border-[#8A96A3]' : 'border-[#28323F]'} ${s.bg} px-4 py-3.5 transition-colors hover:border-[#5B6673] cursor-pointer`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className={`text-[10px] tracking-[0.12em] uppercase font-medium ${s.text}`}>{severity}</span>
        <Icon size={14} className={s.text} strokeWidth={2} />
      </div>
      <span className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums">{value ?? 0}</span>
      <p className="text-xs text-[#8A96A3] mt-0.5">{label}</p>
    </button>
  );
}

// ---------------------------------------------------------------------------
// TrustedAdvisorTab — with fetch timeout
// ---------------------------------------------------------------------------
function TrustedAdvisorTab({ apiBase, accountId }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    setSelectedStatus(null);
    fetchWithTimeout(`${apiBase}/trusted-advisor?account=${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error('No Trusted Advisor data available for this account yet.');
        return res.json();
      })
      .then(setSummary)
      .catch((err) => setError(formatFetchError(err)))
      .finally(() => setLoading(false));
  }, [apiBase, accountId]);

  const toggleStatus = (status) => setSelectedStatus((cur) => (cur === status ? null : status));

  const visibleChecks = useMemo(() => {
    if (!summary) return [];
    if (!selectedStatus) return summary.checks || [];
    return (summary.checks || []).filter((c) => c.status === selectedStatus);
  }, [summary, selectedStatus]);

  if (loading) {
    return <div className="text-sm text-[#8A96A3] py-10 text-center">Loading Trusted Advisor data…</div>;
  }
  if (error) {
    return (
      <div className="rounded-md border border-[#E5484D]/30 bg-[#E5484D]/10 px-4 py-3 text-sm text-[#E5484D]">
        {error}
      </div>
    );
  }
  if (!summary) return null;

  return (
    <div>
      <div className="flex flex-wrap gap-3 mb-6">
        {['error', 'warning', 'ok'].map((status) => {
          const s = TA_STYLES[status];
          const countKey = status === 'error' ? 'totalError' : status === 'warning' ? 'totalWarning' : 'totalOk';
          const active = selectedStatus === status;
          return (
            <button
              key={status}
              onClick={() => toggleStatus(status)}
              className={`flex-1 min-w-[150px] text-left rounded-lg border ${active ? 'border-[#8A96A3]' : 'border-[#28323F]'} ${s.bg} px-4 py-3.5 transition-colors hover:border-[#5B6673] cursor-pointer`}
            >
              <span className={`text-[10px] tracking-[0.12em] uppercase font-medium ${s.text}`}>{s.label}</span>
              <div className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums mt-1">{summary[countKey] ?? 0}</div>
              <p className="text-xs text-[#8A96A3] mt-0.5">checks</p>
            </button>
          );
        })}
      </div>

      <p className="text-[11px] text-[#5B6673] mb-3 font-mono">Last refreshed: {summary.lastRefresh}</p>

      <div className="rounded-xl border border-[#1F2933] bg-[#131B24]">
        <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
          <h2 className="text-sm font-medium">
            {selectedStatus ? `${TA_STYLES[selectedStatus].label} checks` : 'All checks'} ({visibleChecks.length})
          </h2>
          {selectedStatus && (
            <button onClick={() => setSelectedStatus(null)} className="text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors">
              Clear filter ✕
            </button>
          )}
        </div>
        <div className="max-h-[480px] overflow-y-auto">
          {visibleChecks.length === 0 && (
            <p className="px-5 py-6 text-sm text-[#5B6673]">No checks in this category.</p>
          )}
          {visibleChecks.map((c, i) => {
            const s = TA_STYLES[c.status] || TA_STYLES.ok;
            return (
              <div key={`${c.id}-${i}`} className={`px-5 py-3 ${i !== visibleChecks.length - 1 ? 'border-b border-[#1B2430]' : ''}`}>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-[#C7CED6]">{c.name}</p>
                  <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded ${s.bg} ${s.text} ring-1 ${s.ring} shrink-0 ml-3`}>
                    {c.status}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-[#5B6673] font-mono">
                  <span className="capitalize">{c.category?.replace('_', ' ')}</span>
                  {c.resourcesSummary?.resourcesFlagged != null && (
                    <span>{c.resourcesSummary.resourcesFlagged} resources flagged</span>
                  )}
                  {c.estimatedMonthlySavings != null && (
                    <span>${Number(c.estimatedMonthlySavings).toFixed(2)}/mo potential savings</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// InspectorTab — AWS Inspector v2 vulnerability findings
// ---------------------------------------------------------------------------
const INSPECTOR_SEV_ORDER = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];

function InspectorTab({ apiBase, accountId }) {
  const [summary, setSummary]                   = useState(null);
  const [loading, setLoading]                   = useState(true);
  const [error, setError]                       = useState(null);
  const [selectedSeverity, setSelectedSeverity] = useState(null);
  const [activeSection, setActiveSection]       = useState('findings'); // 'findings' | 'resources' | 'titles'

  useEffect(() => {
    setLoading(true);
    setError(null);
    setSelectedSeverity(null);
    setActiveSection('findings');
    fetchWithTimeout(`${apiBase}/inspector?account=${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error('No Inspector data available for this account yet. Ensure AWS Inspector v2 is enabled and the aggregator has run at least once.');
        return res.json();
      })
      .then(setSummary)
      .catch((err) => setError(formatFetchError(err)))
      .finally(() => setLoading(false));
  }, [apiBase, accountId]);

  const toggleSeverity = (sev) => setSelectedSeverity((cur) => (cur === sev ? null : sev));

  const visibleFindings = useMemo(() => {
    if (!summary) return [];
    const all = summary.findings || [];
    if (!selectedSeverity) return all;
    return all.filter((f) => f.severity === selectedSeverity);
  }, [summary, selectedSeverity]);

  if (loading) {
    return <div className="text-sm text-[#8A96A3] py-10 text-center">Loading Inspector data…</div>;
  }
  if (error) {
    return (
      <div className="rounded-md border border-[#E5484D]/30 bg-[#E5484D]/10 px-4 py-3 text-sm text-[#E5484D]">
        {error}
      </div>
    );
  }
  if (!summary) return null;

  const totalFindings = summary.total ?? 0;

  return (
    <div>
      {/* Severity summary cards */}
      <div className="flex flex-wrap gap-3 mb-6">
        {INSPECTOR_SEV_ORDER.map((sev) => {
          const s = SEVERITY_STYLES[sev];
          const count = summary[sev.toLowerCase()] ?? 0;
          const active = selectedSeverity === sev;
          return (
            <button
              key={sev}
              onClick={() => { toggleSeverity(sev); setActiveSection('findings'); }}
              className={`flex-1 min-w-[120px] text-left rounded-lg border ${active ? 'border-[#8A96A3]' : 'border-[#28323F]'} ${s.bg} px-4 py-3.5 transition-colors hover:border-[#5B6673] cursor-pointer`}
            >
              <span className={`text-[10px] tracking-[0.12em] uppercase font-medium ${s.text}`}>{sev}</span>
              <div className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums mt-1">{count}</div>
              <p className="text-xs text-[#8A96A3] mt-0.5">findings</p>
            </button>
          );
        })}
        {/* Total */}
        <div className="flex-1 min-w-[120px] text-left rounded-lg border border-[#28323F] bg-[#131B24] px-4 py-3.5">
          <span className="text-[10px] tracking-[0.12em] uppercase font-medium text-[#8A96A3]">Total</span>
          <div className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums mt-1">{totalFindings}</div>
          <p className="text-xs text-[#8A96A3] mt-0.5">all severities</p>
        </div>
      </div>

      <p className="text-[11px] text-[#5B6673] mb-4 font-mono">Last refreshed: {summary.lastScan}</p>

      {/* Finding type breakdown */}
      {summary.byType && Object.keys(summary.byType).length > 0 && (
        <div className="rounded-xl border border-[#1F2933] bg-[#131B24] mb-4">
          <div className="px-5 py-3 border-b border-[#1F2933]">
            <h2 className="text-sm font-medium">Finding types</h2>
          </div>
          <div className="px-5 py-3 flex flex-wrap gap-3">
            {Object.entries(summary.byType)
              .sort(([, a], [, b]) => b - a)
              .map(([ftype, count]) => (
                <div key={ftype} className="flex items-center gap-2 rounded-md border border-[#28323F] bg-[#0F1720] px-3 py-1.5">
                  <span className="text-xs text-[#C7CED6] font-mono">{ftype.replace(/_/g, ' ')}</span>
                  <span className="text-xs font-semibold text-[#E8EBEF] tabular-nums">{count}</span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Section sub-tabs: Findings / Top Resources / Top CVEs */}
      <div className="flex items-center gap-1 mb-4 border-b border-[#1F2933]">
        {[
          { id: 'findings',  label: `Findings${selectedSeverity ? ` · ${selectedSeverity}` : ''} (${visibleFindings.length})` },
          { id: 'resources', label: `Top Resources (${(summary.topResources || []).length})` },
          { id: 'titles',    label: `Top CVEs / Rules (${(summary.topFindings || []).length})` },
        ].map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveSection(s.id)}
            className={`px-3 py-2 text-xs font-medium border-b-2 -mb-px transition-colors ${
              activeSection === s.id
                ? 'border-[#E8EBEF] text-[#E8EBEF]'
                : 'border-transparent text-[#5B6673] hover:text-[#8A96A3]'
            }`}
          >
            {s.label}
          </button>
        ))}
        {selectedSeverity && (
          <button
            onClick={() => setSelectedSeverity(null)}
            className="ml-auto text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors pb-2"
          >
            Clear filter ✕
          </button>
        )}
      </div>

      {/* Findings list */}
      {activeSection === 'findings' && (
        <div className="rounded-xl border border-[#1F2933] bg-[#131B24]">
          <div className="max-h-[480px] overflow-y-auto">
            {visibleFindings.length === 0 && (
              <p className="px-5 py-6 text-sm text-[#5B6673]">
                No findings{selectedSeverity ? ` at ${selectedSeverity} severity` : ''} for this selection.
              </p>
            )}
            {visibleFindings.map((f, i) => {
              const s = SEVERITY_STYLES[f.severity] || SEVERITY_STYLES.LOW;
              return (
                <div
                  key={`${f.title}-${f.resourceId}-${i}`}
                  className={`px-5 py-3 ${i !== visibleFindings.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-1">
                    <p className="text-sm text-[#C7CED6] flex-1">{f.title}</p>
                    <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded shrink-0 ${s.bg} ${s.text} ring-1 ${s.ring}`}>
                      {f.severity}
                    </span>
                  </div>
                  <div className="flex items-center flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-[#5B6673] font-mono">
                    <span className="truncate max-w-[300px]">{f.resourceId}</span>
                    {f.resourceType && <span className="text-[#3D4A5C]">{f.resourceType}</span>}
                    {f.region && <span>{f.region}</span>}
                    {f.cveIds && f.cveIds.length > 0 && (
                      <span className="text-[#5B9BD5]">{f.cveIds.join(', ')}</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Top affected resources */}
      {activeSection === 'resources' && (
        <div className="rounded-xl border border-[#1F2933] bg-[#131B24]">
          <div className="max-h-[480px] overflow-y-auto">
            {(summary.topResources || []).length === 0 && (
              <p className="px-5 py-6 text-sm text-[#5B6673]">No resource data available.</p>
            )}
            {(summary.topResources || []).map((r, i) => (
              <div
                key={`${r.resourceId}-${i}`}
                className={`px-5 py-3 flex items-center justify-between gap-4 ${i !== summary.topResources.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
              >
                <span className="text-sm text-[#C7CED6] font-mono truncate flex-1">{r.resourceId}</span>
                <span className="font-mono text-sm font-semibold text-[#E8EBEF] shrink-0 tabular-nums">{r.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top CVEs / rule titles */}
      {activeSection === 'titles' && (
        <div className="rounded-xl border border-[#1F2933] bg-[#131B24]">
          <div className="max-h-[480px] overflow-y-auto">
            {(summary.topFindings || []).length === 0 && (
              <p className="px-5 py-6 text-sm text-[#5B6673]">No title data available.</p>
            )}
            {(summary.topFindings || []).map((f, i) => (
              <div
                key={`${f.title}-${i}`}
                className={`px-5 py-3 flex items-center justify-between gap-4 ${i !== summary.topFindings.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
              >
                <span className="text-sm text-[#C7CED6] flex-1">{f.title}</span>
                <span className="font-mono text-sm font-semibold text-[#E8EBEF] shrink-0 tabular-nums">{f.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main dashboard
// ---------------------------------------------------------------------------
export default function SecurityHubDashboard() {
  const [activeTab, setActiveTab] = useState('securityhub');
  const [accounts, setAccounts] = useState([{ id: 'all', name: 'All Accounts', accountId: '' }]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState(new Set(['all']));
  const [summaryCache, setSummaryCache] = useState({});
  const [reportFormat, setReportFormat] = useState('pdf');
  // reportPhase: 'idle' | 'generating' | 'downloading' | 'done' | 'error'
  const [reportPhase, setReportPhase]   = useState('idle');
  const [reportElapsed, setReportElapsed] = useState(0); // seconds since generation started
  const [data, setData] = useState(null);
  const [topControls, setTopControls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [versionInfo, setVersionInfo] = useState(null);
  const [selectedSeverity, setSelectedSeverity] = useState(null);
  const [severityFindings, setSeverityFindings] = useState([]);
  const [findingsLoading, setFindingsLoading] = useState(false);

  // Which account ID to use for API calls
  const apiAccountId = useMemo(() => {
    if (selectedIds.has('all') || selectedIds.size === 0) return 'all';
    if (selectedIds.size === 1) return [...selectedIds][0];
    return 'multi';
  }, [selectedIds]);

  // Selector button label
  const accountLabel = useMemo(() => {
    if (selectedIds.has('all') || selectedIds.size === 0) return 'All Accounts';
    if (selectedIds.size === 1) {
      const id = [...selectedIds][0];
      return accounts.find((a) => a.id === id)?.name ?? id;
    }
    return `${selectedIds.size} accounts selected`;
  }, [selectedIds, accounts]);

  // Search-filtered account list
  const filteredAccounts = useMemo(() => {
    if (!searchTerm.trim()) return accounts;
    const q = searchTerm.toLowerCase();
    return accounts.filter(
      (a) => a.name.toLowerCase().includes(q) || a.accountId.includes(q)
    );
  }, [accounts, searchTerm]);

  const toggleAccount = useCallback((id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (id === 'all') return new Set(['all']);
      next.delete('all');
      if (next.has(id)) {
        next.delete(id);
        if (next.size === 0) return new Set(['all']);
      } else {
        next.add(id);
      }
      return next;
    });
    setSelectedSeverity(null);
  }, []);

  // Load account list on mount
  useEffect(() => {
    fetchWithTimeout(`${API_BASE}/accounts`)
      .then((r) => r.json())
      .then(setAccounts)
      .catch((err) => setError(`Could not load account list. ${formatFetchError(err)}`));
  }, []);

  // Load version info on mount (best-effort — failure is non-fatal)
  useEffect(() => {
    fetchWithTimeout(`${API_BASE}/version`)
      .then((r) => r.json())
      .then(setVersionInfo)
      .catch(() => {}); // intentionally silent
  }, []);

  // Fetch summaries when selection changes
  useEffect(() => {
    setLoading(true);
    setError(null);
    setSelectedSeverity(null);

    if (apiAccountId !== 'multi') {
      fetchWithTimeout(`${API_BASE}/summary?account=${apiAccountId}`)
        .then((r) => {
          if (!r.ok) throw new Error('No summary available for this account yet.');
          return r.json();
        })
        .then((summary) => {
          setData(summary);
          setTopControls(summary.topControls || []);
          setSummaryCache((c) => ({ ...c, [apiAccountId]: summary }));
        })
        .catch((e) => setError(formatFetchError(e)))
        .finally(() => setLoading(false));
    } else {
      const ids = [...selectedIds];
      const toFetch = ids.filter((id) => !summaryCache[id]);
      const fetchPromises = toFetch.map((id) =>
        fetchWithTimeout(`${API_BASE}/summary?account=${id}`)
          .then((r) => r.ok ? r.json() : null)
          .then((s) => s ? { id, summary: s } : null)
          .catch(() => null)
      );
      Promise.all(fetchPromises).then((results) => {
        const newCache = { ...summaryCache };
        results.forEach((r) => { if (r) newCache[r.id] = r.summary; });
        setSummaryCache(newCache);
        const all = ids.map((id) => newCache[id]).filter(Boolean);
        if (all.length === 0) {
          setError('No summary data available for selected accounts.');
          setLoading(false);
          return;
        }
        setData({
          critical: all.reduce((s, x) => s + (x.critical || 0), 0),
          high:     all.reduce((s, x) => s + (x.high     || 0), 0),
          medium:   all.reduce((s, x) => s + (x.medium   || 0), 0),
          low:      all.reduce((s, x) => s + (x.low      || 0), 0),
          score:    Math.round(all.reduce((s, x) => s + (x.score || 0), 0) / all.length),
          passedControls:       all.reduce((s, x) => s + (x.passedControls       || 0), 0),
          totalEnabledControls: all.reduce((s, x) => s + (x.totalEnabledControls || 0), 0),
          lastScan: all[0]?.lastScan || '',
          topControls: [],
        });
        setTopControls([]);
        setLoading(false);
      });
    }
  }, [apiAccountId]);

  // Fetch findings on severity card click
  useEffect(() => {
    if (!selectedSeverity) { setSeverityFindings([]); return; }
    const id = apiAccountId === 'multi' ? 'all' : apiAccountId;
    setFindingsLoading(true);
    fetchWithTimeout(`${API_BASE}/findings?account=${id}&severity=${selectedSeverity}`)
      .then((r) => r.json())
      .then((r) => setSeverityFindings(r.findings || []))
      .catch((err) => setError(`Could not load findings. ${formatFetchError(err)}`))
      .finally(() => setFindingsLoading(false));
  }, [selectedSeverity, apiAccountId]);

  const toggleSeverity = useCallback(
    (sev) => setSelectedSeverity((c) => c === sev ? null : sev),
    []
  );

  /**
   * _triggerDownload — fetches a presigned S3 URL and triggers a file download
   * via a programmatic <a> click (never blocked by popup blockers).
   */
  const _triggerDownload = useCallback((accountId, fmt) => {
    setReportPhase('downloading');
    fetchWithTimeout(`${API_BASE}/report-url?account=${accountId}&format=${fmt}`)
      .then((r) => r.json().then((body) => ({ ok: r.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) throw new Error(body?.error || 'Could not fetch download URL.');
        const url = body?.url;
        if (!url) throw new Error('No download URL returned from API.');
        const a = document.createElement('a');
        a.href = url;
        a.download = `securityhub-report-${accountId}.${fmt}`;
        a.rel = 'noopener noreferrer';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setReportPhase('done');
      })
      .catch((err) => {
        setError(`Download failed: ${formatFetchError(err)}`);
        setReportPhase('error');
      });
  }, []);

  /**
   * handleGenerate — generate→poll→download flow:
   *   1. POST /generate-report  → returns 202 immediately (async Lambda invoke)
   *   2. Poll GET /report-status every 3 s until status === 'done' or 'failed'
   *   3. On done, call _triggerDownload to fetch presigned URL and save file
   *
   * A timer updates reportElapsed every second so the user sees how long
   * generation has been running.
   */
  const handleGenerate = useCallback(() => {
    const id = apiAccountId === 'multi' ? 'all' : apiAccountId;
    setReportPhase('generating');
    setReportElapsed(0);
    setError(null);

    // Elapsed-time counter
    const startTime  = Date.now();
    const timerRef   = { id: null };
    timerRef.id = setInterval(() => {
      setReportElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    const cleanup = () => clearInterval(timerRef.id);

    // Step 1 — trigger generation
    fetchWithTimeout(`${API_BASE}/generate-report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account: id, format: reportFormat }),
    })
      .then((r) => r.json().then((body) => ({ ok: r.ok, body })))
      .then(({ ok, body }) => {
        if (!ok) throw new Error(body?.error || 'Failed to start report generation.');

        // Step 2 — poll /report-status until done, failed, or 5-min timeout
        const MAX_POLLS   = 100; // 100 × 3 s = 5 minutes
        let   pollCount   = 0;

        const poll = () => {
          if (pollCount >= MAX_POLLS) {
            cleanup();
            setError('Report generation timed out after 5 minutes. Check CloudWatch logs.');
            setReportPhase('error');
            return;
          }
          pollCount++;

          fetchWithTimeout(`${API_BASE}/report-status?account=${id}`)
            .then((r) => r.json())
            .then((status) => {
              if (status.status === 'done') {
                cleanup();
                // Step 3 — download
                _triggerDownload(id, reportFormat);
              } else if (status.status === 'failed') {
                cleanup();
                setError(`Report generation failed: ${status.error || 'unknown error'}`);
                setReportPhase('error');
              } else {
                // pending or not_started — keep polling
                setTimeout(poll, 3000);
              }
            })
            .catch((err) => {
              cleanup();
              setError(`Could not check report status: ${formatFetchError(err)}`);
              setReportPhase('error');
            });
        };

        setTimeout(poll, 3000); // first poll after 3 s
      })
      .catch((err) => {
        cleanup();
        setError(`Could not start report generation: ${formatFetchError(err)}`);
        setReportPhase('error');
      });
  }, [apiAccountId, reportFormat, _triggerDownload]);

  if (loading && !data) {
    return (
      <div className="min-h-screen bg-[#0F1720] text-[#8A96A3] flex items-center justify-center">
        Loading…
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[#0F1720] text-[#E8EBEF] font-sans">
        <div className="max-w-5xl mx-auto px-6 py-10">

          {/* Header */}
          <div className="flex items-start justify-between mb-8 pb-6 border-b border-[#1F2933]">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-[#3DD68C]" />
                <span className="text-[11px] tracking-[0.15em] uppercase text-[#8A96A3] font-mono">
                  Security Hub · Compliance Report
                </span>
              </div>
              <h1 className="text-2xl font-semibold tracking-tight" style={{ fontFamily: 'Georgia, serif' }}>
                Cloud Security Posture
              </h1>
            </div>

            {/* Account selector — search + multi-select */}
            <div className="relative">
              <button
                onClick={() => { setDropdownOpen(!dropdownOpen); setSearchTerm(''); }}
                className="flex items-center gap-2 rounded-md border border-[#28323F] bg-[#151D27] px-3.5 py-2 text-sm hover:border-[#3D4A5C] transition-colors min-w-[220px] justify-between"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[#8A96A3] text-xs shrink-0">Account:</span>
                  <span className="font-medium truncate max-w-[140px]">{accountLabel}</span>
                </div>
                <ChevronDown size={14} className={`text-[#8A96A3] transition-transform shrink-0 ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {dropdownOpen && (
                <div className="absolute right-0 mt-1.5 w-72 rounded-md border border-[#28323F] bg-[#151D27] shadow-xl z-20 overflow-hidden">
                  {/* Search input */}
                  <div className="px-3 py-2 border-b border-[#28323F]">
                    <input
                      autoFocus
                      type="text"
                      placeholder="Search accounts…"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full bg-[#0F1720] border border-[#28323F] rounded px-2.5 py-1.5 text-xs text-[#E8EBEF] placeholder-[#5B6673] focus:outline-none focus:border-[#3D4A5C]"
                    />
                  </div>

                  {/* Selection count + clear */}
                  {!selectedIds.has('all') && selectedIds.size > 0 && (
                    <div className="px-3 py-1.5 border-b border-[#28323F] flex items-center justify-between">
                      <span className="text-[11px] text-[#8A96A3]">{selectedIds.size} selected</span>
                      <button
                        onClick={() => { setSelectedIds(new Set(['all'])); setSearchTerm(''); }}
                        className="text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors"
                      >
                        Clear all
                      </button>
                    </div>
                  )}

                  {/* Account list with checkboxes */}
                  <div className="max-h-64 overflow-y-auto">
                    {filteredAccounts.length === 0 && (
                      <p className="px-3.5 py-4 text-xs text-[#5B6673] text-center">No accounts match "{searchTerm}"</p>
                    )}
                    {filteredAccounts.map((a) => {
                      const isSelected = a.id === 'all' ? selectedIds.has('all') : selectedIds.has(a.id);
                      return (
                        <button
                          key={a.id}
                          onClick={() => toggleAccount(a.id)}
                          className={`w-full text-left px-3.5 py-2.5 text-sm hover:bg-[#1B2430] transition-colors flex items-center gap-2.5 ${isSelected ? 'bg-[#1B2430]' : ''}`}
                        >
                          <span className={`w-3.5 h-3.5 rounded border flex items-center justify-center shrink-0 transition-colors ${isSelected ? 'bg-[#3DD68C] border-[#3DD68C]' : 'border-[#3D4A5C]'}`}>
                            {isSelected && (
                              <svg width="8" height="6" viewBox="0 0 8 6" fill="none">
                                <path d="M1 3L3 5L7 1" stroke="#0F1720" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                              </svg>
                            )}
                          </span>
                          <span className="flex-1 truncate">{a.name}</span>
                          {a.accountId && (
                            <span className="font-mono text-[10px] text-[#5B6673] shrink-0">{a.accountId}</span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Apply / close */}
                  <div className="px-3 py-2 border-t border-[#28323F]">
                    <button
                      onClick={() => { setDropdownOpen(false); setSearchTerm(''); }}
                      className="w-full rounded bg-[#E8EBEF] text-[#0F1720] py-1.5 text-xs font-medium hover:bg-white transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Tab switcher */}
          <div className="flex items-center gap-1 mb-6 border-b border-[#1F2933]">
            {[
              { id: 'securityhub',  label: 'Security Hub' },
              { id: 'trustedadvisor', label: 'Trusted Advisor' },
              { id: 'inspector',    label: 'Inspector' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${
                  activeTab === tab.id
                    ? 'border-[#E8EBEF] text-[#E8EBEF]'
                    : 'border-transparent text-[#5B6673] hover:text-[#8A96A3]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Security Hub tab error banner */}
          {activeTab === 'securityhub' && error && (
            <div className="mb-6 rounded-md border border-[#E5484D]/30 bg-[#E5484D]/10 px-4 py-3 text-sm text-[#E5484D] flex items-center justify-between gap-4">
              <span>{error}</span>
              <button onClick={() => setError(null)} className="text-[#E5484D]/60 hover:text-[#E5484D] shrink-0 text-xs">✕</button>
            </div>
          )}

          {/* Security Hub tab content */}
          {activeTab === 'securityhub' && (
            <>
              {/* Score + severity counts */}
              {data && (
                <div className="flex flex-col md:flex-row gap-6 mb-6">
                  <div className="rounded-xl border border-[#1F2933] bg-[#131B24] px-6 py-5 flex items-center gap-6">
                    <ScoreDial score={data.score} />
                    <div>
                      <p className="text-sm text-[#8A96A3] mb-1">Overall compliance score</p>
                      <p className="text-xs text-[#5B6673] flex items-center gap-1.5 mb-1.5">
                        <Clock size={12} /> Last scan: <span className="font-mono">{data.lastScan}</span>
                      </p>
                      <p className="text-[11px] text-[#3D4A5C] font-mono">
                        {data.passedControls ?? 0} passed / {data.totalEnabledControls ?? 0} enabled controls
                        {' '}<span className="text-[#5B6673]">(matches AWS Security Hub console formula)</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex-1 flex flex-wrap gap-3">
                    <CountCard label="findings open" value={data.critical} severity="CRITICAL" Icon={AlertTriangle} onClick={() => toggleSeverity('CRITICAL')} active={selectedSeverity === 'CRITICAL'} />
                    <CountCard label="findings open" value={data.high}     severity="HIGH"     Icon={ShieldAlert}  onClick={() => toggleSeverity('HIGH')}     active={selectedSeverity === 'HIGH'} />
                    <CountCard label="findings open" value={data.medium}   severity="MEDIUM"   Icon={Activity}     onClick={() => toggleSeverity('MEDIUM')}   active={selectedSeverity === 'MEDIUM'} />
                    <CountCard label="findings open" value={data.low}      severity="LOW"      Icon={ShieldCheck}  onClick={() => toggleSeverity('LOW')}      active={selectedSeverity === 'LOW'} />
                  </div>
                </div>
              )}

              {/* Top failing controls */}
              <div className="rounded-xl border border-[#1F2933] bg-[#131B24] mb-6">
                <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
                  <h2 className="text-sm font-medium">Top failing controls</h2>
                  <span className="text-[11px] text-[#5B6673] font-mono">{accountLabel}</span>
                </div>
                <div>
                  {topControls.length === 0 && (
                    <p className="px-5 py-6 text-sm text-[#5B6673]">No control data for this selection.</p>
                  )}
                  {topControls.map((c, i) => {
                    const s = SEVERITY_STYLES[c.severity] || SEVERITY_STYLES.LOW;
                    return (
                      <div
                        key={c.id}
                        className={`flex items-start gap-3 px-5 py-3.5 ${i !== topControls.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
                      >
                        <span className="font-mono text-xs text-[#5B6673] w-16 shrink-0 pt-0.5">{c.id}</span>
                        <span className="text-sm text-[#C7CED6] flex-1 min-w-0 break-words leading-snug">{c.title}</span>
                        <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded shrink-0 mt-0.5 ${s.bg} ${s.text} ring-1 ${s.ring}`}>{c.severity}</span>
                        <span className="font-mono text-sm text-[#E8EBEF] w-8 text-right shrink-0 mt-0.5">{c.count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Severity drill-down panel */}
              {selectedSeverity && (
                <div className="rounded-xl border border-[#1F2933] bg-[#131B24] mb-6">
                  <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded ${SEVERITY_STYLES[selectedSeverity].bg} ${SEVERITY_STYLES[selectedSeverity].text} ring-1 ${SEVERITY_STYLES[selectedSeverity].ring}`}>
                        {selectedSeverity}
                      </span>
                      <h2 className="text-sm font-medium">
                        {findingsLoading ? 'Loading findings…' : `${severityFindings.length} finding${severityFindings.length === 1 ? '' : 's'}`}
                      </h2>
                    </div>
                    <button onClick={() => setSelectedSeverity(null)} className="text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors">
                      Close ✕
                    </button>
                  </div>
                  <div className="max-h-[420px] overflow-y-auto">
                    {!findingsLoading && severityFindings.length === 0 && (
                      <p className="px-5 py-6 text-sm text-[#5B6673]">No {selectedSeverity.toLowerCase()} findings for this selection.</p>
                    )}
                    {severityFindings.map((f, i) => (
                      <div
                        key={`${f.controlId}-${f.resourceId}-${i}`}
                        className={`px-5 py-3 ${i !== severityFindings.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
                      >
                        <p className="text-sm text-[#C7CED6] mb-1">{f.title}</p>
                        <div className="flex items-center gap-3 text-[11px] text-[#5B6673] font-mono">
                          <span>{f.controlId}</span>
                          <span className="truncate max-w-[320px]">{f.resourceId}</span>
                          {f.region && <span>{f.region}</span>}
                          <span>{f.workflowStatus}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Report generation */}
              <div className="rounded-xl border border-[#1F2933] bg-[#131B24] px-5 py-4">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="text-sm font-medium mb-2">Full compliance report</p>
                    <div className="flex items-center gap-4 flex-wrap">
                      {[
                        { value: 'pdf',  label: 'PDF',   hint: 'Formatted report · grouped by severity' },
                        { value: 'csv',  label: 'CSV',   hint: 'One row per finding · sortable in Excel' },
                        { value: 'xlsx', label: 'Excel', hint: '3 tabs: Failed · Passed · Previously Failed Now Passed' },
                      ].map(({ value, label }) => (
                        <label key={value} className="flex items-center gap-1.5 text-xs text-[#C7CED6] cursor-pointer">
                          <input
                            type="radio"
                            name="reportFormat"
                            value={value}
                            checked={reportFormat === value}
                            onChange={() => { setReportFormat(value); setReportPhase('idle'); }}
                            className="accent-[#E8EBEF]"
                            disabled={reportPhase === 'generating' || reportPhase === 'downloading'}
                          />
                          {label}
                        </label>
                      ))}
                      <span className="text-[11px] text-[#5B6673]">
                        {{ pdf: 'Formatted report · grouped by severity', csv: 'One row per finding · sortable in Excel', xlsx: '3 tabs: Failed · Passed · Previously Failed Now Passed' }[reportFormat]}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => { setReportPhase('idle'); handleGenerate(); }}
                    disabled={reportPhase === 'generating' || reportPhase === 'downloading'}
                    className="flex items-center gap-2 rounded-md bg-[#E8EBEF] text-[#0F1720] px-4 py-2 text-sm font-medium hover:bg-white transition-colors disabled:opacity-60 shrink-0"
                  >
                    <Download size={15} strokeWidth={2.2} />
                    {reportPhase === 'generating'  ? 'Generating…'  :
                     reportPhase === 'downloading' ? 'Downloading…' :
                     'Generate report'}
                  </button>
                </div>

                {/* Progress bar + status line */}
                {(reportPhase === 'generating' || reportPhase === 'downloading') && (
                  <div className="mt-3">
                    {/* Indeterminate animated bar */}
                    <div className="h-1 w-full rounded-full bg-[#1F2933] overflow-hidden">
                      <div className="h-full bg-[#3DD68C] rounded-full animate-pulse w-full" />
                    </div>
                    <p className="text-[11px] text-[#5B6673] font-mono mt-1.5">
                      {reportPhase === 'generating'
                        ? `Building ${reportFormat.toUpperCase()} report… ${reportElapsed}s elapsed — polling every 3 s`
                        : 'Report ready — starting download…'}
                    </p>
                  </div>
                )}
                {reportPhase === 'done' && (
                  <p className="text-[11px] text-[#3DD68C] font-mono mt-2">
                    ✓ Download started — check your browser downloads.{' '}
                    <button
                      onClick={() => setReportPhase('idle')}
                      className="underline hover:no-underline"
                    >
                      Generate again
                    </button>
                  </p>
                )}
              </div>
            </>
          )}

          {/* Trusted Advisor tab */}
          {activeTab === 'trustedadvisor' && (
            <TrustedAdvisorTab
              apiBase={API_BASE}
              accountId={apiAccountId === 'multi' ? 'all' : apiAccountId}
            />
          )}

          {/* Inspector tab */}
          {activeTab === 'inspector' && (
            <InspectorTab
              apiBase={API_BASE}
              accountId={apiAccountId === 'multi' ? 'all' : apiAccountId}
            />
          )}

          {/* Footer */}
          <p className="text-center text-[11px] text-[#3D4A5C] mt-8 font-mono">
            Data refreshed daily via AWS Security Hub, Trusted Advisor &amp; Inspector APIs · eu-west-1
          </p>
          <p className="text-center text-[10px] text-[#2A323C] mt-1.5 font-mono">
            dashboard v{DASHBOARD_VERSION}
            {versionInfo && (
              <>
                {' · api v'}{versionInfo.apiVersion}
                {versionInfo.aggregatorVersion && <> · aggregator v{versionInfo.aggregatorVersion}</>}
                {versionInfo.aggregatorLastRun && <> · last run {versionInfo.aggregatorLastRun}</>}
              </>
            )}
          </p>
        </div>
      </div>
    </ErrorBoundary>
  );
}
