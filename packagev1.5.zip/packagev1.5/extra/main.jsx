import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import SecurityHubDashboard from './securityhub-dashboard.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SecurityHubDashboard />
  </React.StrictMode>,
)
