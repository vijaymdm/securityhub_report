"""
Deploy in the same account as your API Gateway (delegated admin account is fine).
Routes (HTTP API, Lambda proxy integration):
  GET /accounts
  GET /summary?account={id}
  GET /findings?account={id}&severity=CRITICAL|HIGH|MEDIUM|LOW   (severity optional)
  GET /trusted-advisor?account={id}&status=error|warning|ok      (status optional)
  GET /report-url?account={id}&format=pdf|csv
"""

import boto3
import json

s3 = boto3.client('s3')
BUCKET = 'your-securityhub-reports-bucket'

CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': 'https://your-cloudfront-domain.cloudfront.net',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
}


def respond(status, body_dict):
    return {'statusCode': status, 'headers': CORS_HEADERS, 'body': json.dumps(body_dict)}


def lambda_handler(event, context):
    path = event.get('rawPath', '')
    params = event.get('queryStringParameters') or {}
    method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')

    if method == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS_HEADERS, 'body': ''}

    try:
        if path.endswith('/accounts'):
            obj = s3.get_object(Bucket=BUCKET, Key='summaries/accounts.json')
            return {'statusCode': 200, 'headers': CORS_HEADERS, 'body': obj['Body'].read().decode()}

        if path.endswith('/summary'):
            account = params.get('account', 'all')
            obj = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/latest.json')
            return {'statusCode': 200, 'headers': CORS_HEADERS, 'body': obj['Body'].read().decode()}

        if path.endswith('/findings'):
            account = params.get('account', 'all')
            severity = (params.get('severity') or '').upper()
            obj = s3.get_object(Bucket=BUCKET, Key=f'summaries/{account}/findings.json')
            findings = json.loads(obj['Body'].read().decode())
            if severity:
                findings = [f for f in findings if f.get('severity', '').upper() == severity]
            return respond(200, {'account': account, 'severity': severity or 'ALL', 'count': len(findings), 'findings': findings})

        if path.endswith('/trusted-advisor'):
            account = params.get('account', 'all')
            status = (params.get('status') or '').lower()
            obj = s3.get_object(Bucket=BUCKET, Key=f'trusted-advisor/{account}/latest.json')
            ta_summary = json.loads(obj['Body'].read().decode())
            if status:
                checks = [c for c in ta_summary.get('checks', []) if c.get('status', '').lower() == status]
                ta_summary = {**ta_summary, 'checks': checks}
            return respond(200, ta_summary)

        if path.endswith('/report-url'):
            account = params.get('account', 'all')
            fmt = params.get('format', 'pdf').lower()
            if fmt not in ('pdf', 'csv'):
                return respond(400, {'error': "format must be 'pdf' or 'csv'"})
            report_key = f'reports/{account}/latest.{fmt}'
            url = s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': BUCKET, 'Key': report_key},
                ExpiresIn=900,
            )
            return respond(200, {'url': url, 'format': fmt})

        return respond(404, {'error': 'unknown route'})

    except s3.exceptions.NoSuchKey:
        return respond(404, {'error': 'No data found for this account yet'})
    except Exception as e:
        return respond(500, {'error': str(e)})
