import React, { useState, useMemo, useEffect } from 'react';
import { AlertTriangle, ShieldCheck, ShieldAlert, Download, ChevronDown, Activity, Clock } from 'lucide-react';

// ---- API base URL (from API Gateway HTTP API invoke URL) ----
const API_BASE = 'https://abc123.execute-api.ap-south-1.amazonaws.com';

const SEVERITY_STYLES = {
  CRITICAL: { text: 'text-[#E5484D]', bg: 'bg-[#E5484D]/10', ring: 'ring-[#E5484D]/30' },
  HIGH:     { text: 'text-[#F5A623]', bg: 'bg-[#F5A623]/10', ring: 'ring-[#F5A623]/30' },
  MEDIUM:   { text: 'text-[#5B9BD5]', bg: 'bg-[#5B9BD5]/10', ring: 'ring-[#5B9BD5]/30' },
  LOW:      { text: 'text-[#8A96A3]', bg: 'bg-[#8A96A3]/10', ring: 'ring-[#8A96A3]/30' },
};

const TA_STYLES = {
  error:   { text: 'text-[#E5484D]', bg: 'bg-[#E5484D]/10', ring: 'ring-[#E5484D]/30', label: 'Action Required' },
  warning: { text: 'text-[#F5A623]', bg: 'bg-[#F5A623]/10', ring: 'ring-[#F5A623]/30', label: 'Investigate' },
  ok:      { text: 'text-[#3DD68C]', bg: 'bg-[#3DD68C]/10', ring: 'ring-[#3DD68C]/30', label: 'No Problems' },
};

function ScoreDial({ score }) {
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = score >= 80 ? '#3DD68C' : score >= 60 ? '#F5A623' : '#E5484D';

  return (
    <div className="relative w-36 h-36 flex items-center justify-center">
      <svg width="144" height="144" viewBox="0 0 144 144" className="-rotate-90">
        <circle cx="72" cy="72" r={radius} fill="none" stroke="#1B2430" strokeWidth="10" />
        <circle
          cx="72" cy="72" r={radius} fill="none"
          stroke={color} strokeWidth="10" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 700ms ease-out' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-mono text-3xl font-semibold text-[#E8EBEF] tabular-nums">{score}</span>
        <span className="text-[10px] tracking-[0.15em] text-[#8A96A3] uppercase mt-0.5">Compliant</span>
      </div>
    </div>
  );
}

function CountCard({ label, value, severity, Icon, onClick, active }) {
  const s = SEVERITY_STYLES[severity];
  return (
    <button
      onClick={onClick}
      className={`flex-1 min-w-[130px] text-left rounded-lg border ${active ? 'border-[#8A96A3]' : 'border-[#28323F]'} ${s.bg} px-4 py-3.5 transition-colors hover:border-[#5B6673] cursor-pointer`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className={`text-[10px] tracking-[0.12em] uppercase font-medium ${s.text}`}>{severity}</span>
        <Icon size={14} className={s.text} strokeWidth={2} />
      </div>
      <span className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums">{value}</span>
      <p className="text-xs text-[#8A96A3] mt-0.5">{label}</p>
    </button>
  );
}

function TrustedAdvisorTab({ apiBase, accountId }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState(null); // null | 'error' | 'warning' | 'ok'

  useEffect(() => {
    setLoading(true);
    setError(null);
    setSelectedStatus(null);
    fetch(`${apiBase}/trusted-advisor?account=${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error('No Trusted Advisor data available for this account yet.');
        return res.json();
      })
      .then(setSummary)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [apiBase, accountId]);

  const toggleStatus = (status) => setSelectedStatus((cur) => (cur === status ? null : status));

  const visibleChecks = useMemo(() => {
    if (!summary) return [];
    if (!selectedStatus) return summary.checks || [];
    return (summary.checks || []).filter((c) => c.status === selectedStatus);
  }, [summary, selectedStatus]);

  if (loading) {
    return <div className="text-sm text-[#8A96A3] py-10 text-center">Loading Trusted Advisor data…</div>;
  }
  if (error) {
    return (
      <div className="rounded-md border border-[#E5484D]/30 bg-[#E5484D]/10 px-4 py-3 text-sm text-[#E5484D]">
        {error}
      </div>
    );
  }
  if (!summary) return null;

  return (
    <div>
      <div className="flex flex-wrap gap-3 mb-6">
        {['error', 'warning', 'ok'].map((status) => {
          const s = TA_STYLES[status];
          const countKey = status === 'error' ? 'totalError' : status === 'warning' ? 'totalWarning' : 'totalOk';
          const active = selectedStatus === status;
          return (
            <button
              key={status}
              onClick={() => toggleStatus(status)}
              className={`flex-1 min-w-[150px] text-left rounded-lg border ${active ? 'border-[#8A96A3]' : 'border-[#28323F]'} ${s.bg} px-4 py-3.5 transition-colors hover:border-[#5B6673] cursor-pointer`}
            >
              <span className={`text-[10px] tracking-[0.12em] uppercase font-medium ${s.text}`}>{s.label}</span>
              <div className="font-mono text-2xl font-semibold text-[#E8EBEF] tabular-nums mt-1">{summary[countKey]}</div>
              <p className="text-xs text-[#8A96A3] mt-0.5">checks</p>
            </button>
          );
        })}
      </div>

      <p className="text-[11px] text-[#5B6673] mb-3 font-mono">Last refreshed: {summary.lastRefresh}</p>

      <div className="rounded-xl border border-[#1F2933] bg-[#131B24]">
        <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
          <h2 className="text-sm font-medium">
            {selectedStatus ? `${TA_STYLES[selectedStatus].label} checks` : 'All checks'} ({visibleChecks.length})
          </h2>
          {selectedStatus && (
            <button onClick={() => setSelectedStatus(null)} className="text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors">
              Clear filter ✕
            </button>
          )}
        </div>
        <div className="max-h-[480px] overflow-y-auto">
          {visibleChecks.length === 0 && (
            <p className="px-5 py-6 text-sm text-[#5B6673]">No checks in this category.</p>
          )}
          {visibleChecks.map((c, i) => {
            const s = TA_STYLES[c.status] || TA_STYLES.ok;
            return (
              <div key={`${c.id}-${i}`} className={`px-5 py-3 ${i !== visibleChecks.length - 1 ? 'border-b border-[#1B2430]' : ''}`}>
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-[#C7CED6]">{c.name}</p>
                  <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded ${s.bg} ${s.text} ring-1 ${s.ring} shrink-0 ml-3`}>
                    {c.status}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-[#5B6673] font-mono">
                  <span className="capitalize">{c.category?.replace('_', ' ')}</span>
                  {c.resourcesSummary?.resourcesFlagged != null && (
                    <span>{c.resourcesSummary.resourcesFlagged} resources flagged</span>
                  )}
                  {c.estimatedMonthlySavings != null && (
                    <span>${Number(c.estimatedMonthlySavings).toFixed(2)}/mo potential savings</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function SecurityHubDashboard() {
  const [activeTab, setActiveTab] = useState('securityhub'); // 'securityhub' | 'trustedadvisor'
  const [accounts, setAccounts] = useState([{ id: 'all', name: 'All Accounts', accountId: '' }]);
  const [accountId, setAccountId] = useState('all');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [reportFormat, setReportFormat] = useState('pdf');
  const [data, setData] = useState(null);
  const [topControls, setTopControls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Severity drill-down state
  const [selectedSeverity, setSelectedSeverity] = useState(null); // null | 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
  const [severityFindings, setSeverityFindings] = useState([]);
  const [findingsLoading, setFindingsLoading] = useState(false);

  // Fetch the account list once on load
  useEffect(() => {
    fetch(`${API_BASE}/accounts`)
      .then((res) => res.json())
      .then(setAccounts)
      .catch(() => setError('Could not load account list.'));
  }, []);

  // Fetch the summary whenever the selected account changes
  useEffect(() => {
    setLoading(true);
    setError(null);
    setSelectedSeverity(null); // reset drill-down when switching accounts
    fetch(`${API_BASE}/summary?account=${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error('No summary available for this account yet.');
        return res.json();
      })
      .then((summary) => {
        setData(summary);
        setTopControls(summary.topControls || []);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [accountId]);

  // Fetch findings whenever a severity card is selected (or account changes while one is selected)
  useEffect(() => {
    if (!selectedSeverity) {
      setSeverityFindings([]);
      return;
    }
    setFindingsLoading(true);
    fetch(`${API_BASE}/findings?account=${accountId}&severity=${selectedSeverity}`)
      .then((res) => res.json())
      .then((res) => setSeverityFindings(res.findings || []))
      .catch(() => setError('Could not load findings for this severity.'))
      .finally(() => setFindingsLoading(false));
  }, [selectedSeverity, accountId]);

  const toggleSeverity = (sev) => {
    setSelectedSeverity((current) => (current === sev ? null : sev));
  };

  const accountLabel = useMemo(
    () => accounts.find((a) => a.id === accountId)?.name ?? 'All Accounts',
    [accounts, accountId]
  );

  const handleDownload = () => {
    setDownloading(true);
    fetch(`${API_BASE}/report-url?account=${accountId}&format=${reportFormat}`)
      .then((res) => res.json())
      .then(({ url }) => window.open(url, '_blank'))
      .catch(() => setError('Could not generate download link.'))
      .finally(() => setDownloading(false));
  };

  if (loading && !data) {
    return <div className="min-h-screen bg-[#0F1720] text-[#8A96A3] flex items-center justify-center">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-[#0F1720] text-[#E8EBEF] font-sans">
      <div className="max-w-5xl mx-auto px-6 py-10">

        {/* Header */}
        <div className="flex items-start justify-between mb-8 pb-6 border-b border-[#1F2933]">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-[#3DD68C]" />
              <span className="text-[11px] tracking-[0.15em] uppercase text-[#8A96A3] font-mono">
                Security Hub · Compliance Report
              </span>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight" style={{ fontFamily: 'Georgia, serif' }}>
              Cloud Security Posture
            </h1>
          </div>

          {/* Account selector */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-2 rounded-md border border-[#28323F] bg-[#151D27] px-3.5 py-2 text-sm hover:border-[#3D4A5C] transition-colors"
            >
              <span className="text-[#8A96A3] text-xs">Account:</span>
              <span className="font-medium">{accountLabel}</span>
              <ChevronDown size={14} className={`text-[#8A96A3] transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>
            {dropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-64 rounded-md border border-[#28323F] bg-[#151D27] shadow-xl z-10 overflow-hidden">
                {accounts.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => { setAccountId(a.id); setDropdownOpen(false); }}
                    className={`w-full text-left px-3.5 py-2.5 text-sm hover:bg-[#1B2430] transition-colors flex items-center justify-between ${accountId === a.id ? 'bg-[#1B2430]' : ''}`}
                  >
                    <span>{a.name}</span>
                    {a.accountId && <span className="font-mono text-[11px] text-[#5B6673]">{a.accountId}</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 mb-6 border-b border-[#1F2933]">
          {[
            { id: 'securityhub', label: 'Security Hub' },
            { id: 'trustedadvisor', label: 'Trusted Advisor' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${
                activeTab === tab.id
                  ? 'border-[#E8EBEF] text-[#E8EBEF]'
                  : 'border-transparent text-[#5B6673] hover:text-[#8A96A3]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'securityhub' && error && (
          <div className="mb-6 rounded-md border border-[#E5484D]/30 bg-[#E5484D]/10 px-4 py-3 text-sm text-[#E5484D]">
            {error}
          </div>
        )}

        {activeTab === 'securityhub' && (
        <>
        {/* Top row: score + counts */}
        {data && (
        <div className="flex flex-col md:flex-row gap-6 mb-6">
          <div className="rounded-xl border border-[#1F2933] bg-[#131B24] px-6 py-5 flex items-center gap-6">
            <ScoreDial score={data.score} />
            <div>
              <p className="text-sm text-[#8A96A3] mb-1">Overall compliance score</p>
              <p className="text-xs text-[#5B6673] flex items-center gap-1.5">
                <Clock size={12} /> Last scan: <span className="font-mono">{data.lastScan}</span>
              </p>
            </div>
          </div>

          <div className="flex-1 flex flex-wrap gap-3">
            <CountCard label="findings open" value={data.critical} severity="CRITICAL" Icon={AlertTriangle} onClick={() => toggleSeverity('CRITICAL')} active={selectedSeverity === 'CRITICAL'} />
            <CountCard label="findings open" value={data.high} severity="HIGH" Icon={ShieldAlert} onClick={() => toggleSeverity('HIGH')} active={selectedSeverity === 'HIGH'} />
            <CountCard label="findings open" value={data.medium} severity="MEDIUM" Icon={Activity} onClick={() => toggleSeverity('MEDIUM')} active={selectedSeverity === 'MEDIUM'} />
            <CountCard label="findings open" value={data.low} severity="LOW" Icon={ShieldCheck} onClick={() => toggleSeverity('LOW')} active={selectedSeverity === 'LOW'} />
          </div>
        </div>
        )}

        {/* Top failing controls */}
        <div className="rounded-xl border border-[#1F2933] bg-[#131B24] mb-6">
          <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
            <h2 className="text-sm font-medium">Top failing controls</h2>
            <span className="text-[11px] text-[#5B6673] font-mono">{accountLabel}</span>
          </div>
          <div>
            {topControls.length === 0 && (
              <p className="px-5 py-6 text-sm text-[#5B6673]">No control data for this account yet.</p>
            )}
            {topControls.map((c, i) => {
              const s = SEVERITY_STYLES[c.severity] || SEVERITY_STYLES.LOW;
              return (
                <div
                  key={c.id}
                  className={`flex items-center gap-4 px-5 py-3.5 ${i !== topControls.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
                >
                  <span className="font-mono text-xs text-[#5B6673] w-16 shrink-0">{c.id}</span>
                  <span className="text-sm text-[#C7CED6] flex-1">{c.title}</span>
                  <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded ${s.bg} ${s.text} ring-1 ${s.ring} shrink-0`}>
                    {c.severity}
                  </span>
                  <span className="font-mono text-sm text-[#E8EBEF] w-8 text-right shrink-0">{c.count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Severity drill-down panel — shown when a severity card is clicked */}
        {selectedSeverity && (
          <div className="rounded-xl border border-[#1F2933] bg-[#131B24] mb-6">
            <div className="px-5 py-4 border-b border-[#1F2933] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] tracking-wide uppercase font-medium px-2 py-0.5 rounded ${SEVERITY_STYLES[selectedSeverity].bg} ${SEVERITY_STYLES[selectedSeverity].text} ring-1 ${SEVERITY_STYLES[selectedSeverity].ring}`}>
                  {selectedSeverity}
                </span>
                <h2 className="text-sm font-medium">
                  {findingsLoading ? 'Loading findings…' : `${severityFindings.length} finding${severityFindings.length === 1 ? '' : 's'}`}
                </h2>
              </div>
              <button
                onClick={() => setSelectedSeverity(null)}
                className="text-[11px] text-[#5B6673] hover:text-[#E8EBEF] transition-colors"
              >
                Close ✕
              </button>
            </div>
            <div className="max-h-[420px] overflow-y-auto">
              {!findingsLoading && severityFindings.length === 0 && (
                <p className="px-5 py-6 text-sm text-[#5B6673]">No {selectedSeverity.toLowerCase()} findings for this account.</p>
              )}
              {severityFindings.map((f, i) => (
                <div
                  key={`${f.controlId}-${f.resourceId}-${i}`}
                  className={`px-5 py-3 ${i !== severityFindings.length - 1 ? 'border-b border-[#1B2430]' : ''}`}
                >
                  <p className="text-sm text-[#C7CED6] mb-1">{f.title}</p>
                  <div className="flex items-center gap-3 text-[11px] text-[#5B6673] font-mono">
                    <span>{f.controlId}</span>
                    <span className="truncate max-w-[320px]">{f.resourceId}</span>
                    {f.region && <span>{f.region}</span>}
                    <span>{f.workflowStatus}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Download */}
        <div className="flex items-center justify-between rounded-xl border border-[#1F2933] bg-[#131B24] px-5 py-4">
          <div>
            <p className="text-sm font-medium mb-2">Full compliance report</p>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-1.5 text-xs text-[#C7CED6] cursor-pointer">
                <input
                  type="radio"
                  name="reportFormat"
                  value="pdf"
                  checked={reportFormat === 'pdf'}
                  onChange={() => setReportFormat('pdf')}
                  className="accent-[#E8EBEF]"
                />
                PDF
              </label>
              <label className="flex items-center gap-1.5 text-xs text-[#C7CED6] cursor-pointer">
                <input
                  type="radio"
                  name="reportFormat"
                  value="csv"
                  checked={reportFormat === 'csv'}
                  onChange={() => setReportFormat('csv')}
                  className="accent-[#E8EBEF]"
                />
                CSV
              </label>
              <span className="text-[11px] text-[#5B6673]">
                {reportFormat === 'csv'
                  ? 'One row per finding · sortable by severity in Excel'
                  : 'Formatted report · grouped by severity'}
              </span>
            </div>
          </div>
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="flex items-center gap-2 rounded-md bg-[#E8EBEF] text-[#0F1720] px-4 py-2 text-sm font-medium hover:bg-white transition-colors disabled:opacity-60"
          >
            <Download size={15} strokeWidth={2.2} />
            {downloading ? 'Preparing…' : 'Download report'}
          </button>
        </div>
        </>
        )}

        {activeTab === 'trustedadvisor' && (
          <TrustedAdvisorTab apiBase={API_BASE} accountId={accountId} />
        )}

        <p className="text-center text-[11px] text-[#3D4A5C] mt-8 font-mono">
          Data refreshed daily via AWS Security Hub &amp; Trusted Advisor APIs · ap-south-1
        </p>
      </div>
    </div>
  );
}
